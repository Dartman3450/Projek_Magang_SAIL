function _isEspAlive(key) {
  const t = _espLastSeen[key];
  if (!t) return false;
  return (Date.now() - new Date(t).getTime()) < ESP_TIMEOUT_MS;
}

function updateEspBadge() {
  const wrap = document.getElementById('esp-badge');
  if (!wrap) return;

  const states = _ESP_DEFS.map(e => ({ ...e, alive: _isEspAlive(e.key) }));
  const connCount = states.filter(e => e.alive).length;
  const total     = states.length;

  // Warna badge keseluruhan
  let badgeClass = 'esp-badge';
  if (connCount === total)      badgeClass += ' connected';
  else if (connCount === 0)     badgeClass += ' waiting';
  else                          badgeClass += ' partial';

  const summaryText = 'ESP Status';

  wrap.className = badgeClass;
  wrap.onclick   = toggleEspPopup;
  wrap.style.cursor = 'pointer';
  wrap.style.userSelect = 'none';

  wrap.innerHTML = `
    <div class="esp-dot"></div>
    <span id="esp-label">${summaryText}</span>
    <span style="font-size:9px;margin-left:3px;color:inherit;opacity:.7">▾</span>
  `;
}

function toggleEspPopup() {
  let popup = document.getElementById('esp-popup');
  if (popup) { popup.remove(); return; }

  const wrap  = document.getElementById('esp-badge');
  const rect  = wrap.getBoundingClientRect();
  const states = _ESP_DEFS.map(e => ({ ...e, alive: _isEspAlive(e.key) }));

  popup = document.createElement('div');
  popup.id = 'esp-popup';
  popup.style.cssText = `
    position:fixed;
    top:${rect.bottom + 8}px;
    right:${window.innerWidth - rect.right}px;
    background:#fff;
    border:1px solid #e2e8f0;
    border-radius:12px;
    box-shadow:0 8px 24px rgba(0,0,0,.12);
    padding:10px 4px;
    z-index:9999;
    min-width:210px;
    font-family:inherit;
  `;

  popup.innerHTML = `
    <div style="padding:4px 14px 8px;font-size:10px;font-weight:700;color:#94a3b8;letter-spacing:1px;text-transform:uppercase;">
      ESP Status
    </div>
    ${states.map(e => {
      const alive   = e.alive;
      const dotClr  = alive ? '#22c55e' : '#f59e0b';
      const dotShadow = alive ? '0 0 6px rgba(34,197,94,.6)' : 'none';
      const lastTs  = _espLastSeen[e.key];
      const lastStr = lastTs
        ? new Date(lastTs).toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit', second:'2-digit' })
        : '—';
      const statusTxt = alive ? 'Connected' : (lastTs ? 'Waiting / Off' : 'No Data');
      const statusClr = alive ? '#16a34a' : '#b45309';
      return `
        <div style="display:flex;align-items:center;gap:10px;padding:7px 14px;border-radius:8px;transition:.15s;"
          onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='transparent'">
          <div style="width:9px;height:9px;border-radius:50%;background:${dotClr};box-shadow:${dotShadow};flex-shrink:0;"></div>
          <div style="flex:1;min-width:0;">
            <div style="font-size:12px;font-weight:600;color:#1e293b;">${e.label}</div>
            <div style="font-size:10px;color:#94a3b8;">Last: ${lastStr}</div>
          </div>
          <div style="font-size:11px;font-weight:700;color:${statusClr};">${statusTxt}</div>
        </div>`;
    }).join('')}
  `;

  document.body.appendChild(popup);

  // Tutup kalau klik di luar
  setTimeout(() => {
    document.addEventListener('click', function _close(ev) {
      if (!popup.contains(ev.target) && ev.target.id !== 'esp-badge' && !document.getElementById('esp-badge')?.contains(ev.target)) {
        popup.remove();
        document.removeEventListener('click', _close);
      }
    });
  }, 50);
}
window.toggleEspPopup = toggleEspPopup;

// Legacy — masih dipanggil kalau ada kode lain
function setEspStatus(state) {
  updateEspBadge();
}

// ══ IOT RENDER ═════════════════════════════════════
function renderIoT(content) {
  content.innerHTML = getIoTHTML();
  initWidgets();
  renderTankCards();
  fetchSummary();
  setTimeout(updateDashWidgets, 200);
  // Clear any existing poll before setting new one
  if (window._poll) { clearInterval(window._poll); window._poll = null; }
  // Robust polling: setiap 5 detik, selalu fetch ulang
  window._poll = setInterval(() => {
    // Check if IoT page is still active (wl-tanks-container ada di DOM)
    if (!document.getElementById('wl-tanks-container')) {
      clearInterval(window._poll);
      window._poll = null;
      return;
    }
    fetchSummary();
  }, 5000);
}

function getIoTHTML() {
  const ov = `
    <div class="esp-waiting-overlay show" id="ov-ID">
      <div class="esp-wait-icon">🔌</div>
      <div class="esp-wait-txt">Waiting for ESP<span class="dots"></span></div>
      <div class="esp-wait-sub">Belum ada data masuk</div>
    </div>`;

  return `
  <div class="sensor-grid">

    <!-- TANGKI AIR — DYNAMIC MULTI SENSOR -->
    <div class="s-card" style="--acc:var(--blue);grid-column:1/-1">
      <div class="s-bar"></div>
      ${ov.replace('ov-ID','ov-wl')}
      <div class="s-label">Water Level</div>
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
        <div class="s-pill st-wait" id="wl-status" style="margin:0">—</div>
        <button class="s-detail-btn" style="position:static" onclick="openDetail('water-level')">Detail ↗</button>
      </div>
      <!-- tanks rendered dynamically by renderTankCards() -->
      <div id="wl-tanks-container"></div>
      <!-- volume summary -->
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:8px 10px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
          <span style="font-size:9px;font-weight:700;color:var(--txt3);letter-spacing:1px">TOTAL VOLUME</span>
          <span style="font-size:9px;color:var(--txt3)" id="wl-time">—</span>
        </div>
        <div id="wl-vol-rows" style="display:flex;flex-direction:column;gap:3px"></div>
        <div style="display:flex;justify-content:flex-end;margin-top:4px">
          <button onclick="loadPage('tank-dimension-setting')" style="font-size:9px;padding:2px 10px;background:#ebf2fd;border:1px solid #c3d9fa;border-radius:5px;color:var(--blue);font-weight:600;cursor:pointer;font-family:inherit">⚙ Kelola Sensor</button>
        </div>
      </div>
    </div>

    <!-- WATER FLOW -->
    <div class="s-card" style="--acc:var(--green)">
      <div class="s-bar"></div>
      ${ov.replace('ov-ID','ov-wf')}
      <div class="s-label">Water Flow</div>
      <div class="s-header">
        <div>
          <div class="s-num" id="wf-val">—</div>
          <div class="s-unit">L/min</div>
          <div class="s-pill st-wait" id="wf-status">—</div>
        <button class="s-detail-btn" onclick="openDetail('water-flow')">Detail ↗</button>
        </div>
      </div>
      <div class="s-viz pipe-wrap">
        <div class="pipe-row">
          <div class="pipe-cap l"></div>
          <div class="pipe-seg"><div id="pfl"></div></div>
          <div class="fan-hub">
            <svg class="fan-svg" id="fan-svg" width="32" height="32" viewBox="0 0 40 40">
              <g transform="translate(20,20)">
                <ellipse rx="3" ry="7" transform="rotate(0)"   fill="#18a96a" opacity=".9"/>
                <ellipse rx="3" ry="7" transform="rotate(60)"  fill="#18a96a" opacity=".6"/>
                <ellipse rx="3" ry="7" transform="rotate(120)" fill="#18a96a" opacity=".4"/>
                <ellipse rx="3" ry="7" transform="rotate(180)" fill="#18a96a" opacity=".9"/>
                <ellipse rx="3" ry="7" transform="rotate(240)" fill="#18a96a" opacity=".6"/>
                <ellipse rx="3" ry="7" transform="rotate(300)" fill="#18a96a" opacity=".4"/>
                <circle r="4" fill="white" stroke="#18a96a" stroke-width="1.5"/>
                <circle r="1.5" fill="#18a96a"/>
              </g>
            </svg>
          </div>
          <div class="pipe-seg"><div id="pfr"></div></div>
          <div class="pipe-cap r"></div>
        </div>
        <div class="pipe-stats">
          <div class="ps"><div class="psl">SPEED</div><div class="psv" id="wf-rpm">—</div></div>
          <div class="ps"><div class="psl">VOLUME</div><div class="psv" id="wf-vol">—</div></div>
          <div class="ps"><div class="psl">UPDATE</div><div class="psv" style="color:var(--txt3)" id="wf-time">—</div></div>
        </div>
      </div>
    </div>

    <!-- TEMPERATURE -->
    <div class="s-card" style="--acc:var(--orange)">
      <div class="s-bar"></div>
      ${ov.replace('ov-ID','ov-suhu')}
      <div class="s-label">Temperature</div>
      <div class="s-header">
        <div>
          <div class="s-num" id="suhu-val">—</div>
          <div class="s-unit">°C</div>
          <div class="s-pill st-wait" id="suhu-status">—</div>
        <button class="s-detail-btn" onclick="openDetail('lingkungan')">Detail ↗</button>
        </div>
      </div>
      <div class="s-viz thermo-wrap">
        <div class="thermo-col">
          <div class="thermo-tube"><div class="thermo-merc" id="thermo-merc" style="height:0%"></div></div>
          <div class="thermo-neck"></div>
          <div class="thermo-bulb" id="thermo-bulb"></div>
        </div>
        <div class="thermo-scale"><span>50°</span><span>40°</span><span>30°</span><span>20°</span><span>10°</span><span>0°</span></div>
        <div class="s-rows">
          <div class="irow"><span class="ik">TEMP</span><span class="iv" id="suhu-v2">—</span></div>
          <div class="irow"><span class="ik">CONDITION</span><span class="iv" id="suhu-cond">—</span></div>
          <div class="irow"><span class="ik">UPDATE</span><span class="iv" id="suhu-time">—</span></div>
        </div>
      </div>
    </div>

    <!-- HUMIDITY -->
    <div class="s-card" style="--acc:var(--yellow)">
      <div class="s-bar"></div>
      ${ov.replace('ov-ID','ov-kel')}
      <div class="s-label">Humidity</div>
      <div class="s-header">
        <div>
          <div class="s-num" id="kel-val">—</div>
          <div class="s-unit">%RH</div>
          <div class="s-pill st-wait" id="kel-status">—</div>
        <button class="s-detail-btn" onclick="openDetail('lingkungan')">Detail ↗</button>
        </div>
      </div>
      <div class="s-viz hum-wrap">
        <div class="gauge-outer">
          <svg width="144" height="78" viewBox="0 0 156 86" style="overflow:visible">
            <defs>
              <linearGradient id="gGrd" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%"   stop-color="#2b7de9"/>
                <stop offset="50%"  stop-color="#c99a0a"/>
                <stop offset="100%" stop-color="#dc3545"/>
              </linearGradient>
            </defs>
            <path d="M13 83 A65 65 0 0 1 143 83" stroke="#e4e8ed" stroke-width="11" fill="none" stroke-linecap="round"/>
            <path id="g-arc" d="M13 83 A65 65 0 0 1 143 83" stroke="url(#gGrd)" stroke-width="11" fill="none" stroke-linecap="round"
              stroke-dasharray="204" stroke-dashoffset="204" style="transition:stroke-dashoffset 1.6s ease"/>
            <text x="7"   y="84" font-family="DM Mono,monospace" font-size="8" fill="#a0aec0">0</text>
            <text x="70"  y="16" font-family="DM Mono,monospace" font-size="8" fill="#a0aec0">50</text>
            <text x="138" y="84" font-family="DM Mono,monospace" font-size="8" fill="#a0aec0">100</text>
            <g id="g-needle" transform="rotate(-90,78,83)">
              <line x1="78" y1="83" x2="78" y2="24" stroke="#c99a0a" stroke-width="2" stroke-linecap="round"/>
              <circle cx="78" cy="83" r="4.5" fill="#c99a0a" stroke="white" stroke-width="2"/>
            </g>
          </svg>
          <div class="gauge-ct"><div class="g-num" id="g-num">—</div><div class="g-unit">%RH</div></div>
        </div>
        <div class="drops-row" id="drops-row"></div>
      </div>
    </div>

    <!-- GAS -->
    <div class="s-card" style="--acc:var(--purple)">
      <div class="s-bar"></div>
      ${ov.replace('ov-ID','ov-gas')}
      <div class="s-label">Gas Level</div>
      <div class="s-header">
        <div>
          <div class="s-num" id="gas-val">—</div>
          <div class="s-unit">ppm</div>
          <div class="s-pill st-wait" id="gas-status">—</div>
        <button class="s-detail-btn" onclick="openDetail('lingkungan')">Detail ↗</button>
        </div>
      </div>
      <div class="s-viz gas-wrap">
        <div class="gas-icon-row">
          <div class="gas-emoji">☁️</div>
          <div class="gas-bars">
            <div class="gbrow">
              <span class="gbl">VALUE</span>
              <div class="gbt"><div class="gbf" id="gbar-main" style="width:0%;background:linear-gradient(90deg,#18a96a,#6f52d9)"></div></div>
              <span class="gbv" id="gas-pct-lbl" style="color:var(--purple)">—</span>
            </div>
            <div class="gbrow">
              <span class="gbl" style="color:var(--green)">SAFE</span>
              <div class="gbt"><div class="gbf" style="width:50%;background:linear-gradient(90deg,rgba(24,169,106,.55),rgba(24,169,106,.1))"></div></div>
              <span class="gbv" style="color:var(--green)">300</span>
            </div>
            <div class="gbrow">
              <span class="gbl" style="color:var(--red)">MAX</span>
              <div class="gbt"><div class="gbf" style="width:100%;background:linear-gradient(90deg,rgba(220,53,69,.55),rgba(220,53,69,.1))"></div></div>
              <span class="gbv" style="color:var(--red)">600</span>
            </div>
          </div>
        </div>
        <div class="gas-ptcl" id="gas-ptcl"></div>
      </div>
    </div>

  <!-- TABLE -->
  <!-- 3 NEW DASHBOARD WIDGETS -->
  <div class="dash-new-grid" id="dash-new-widgets">

    <!-- Air baku -->
    <div class="d-widget" style="--wacc:var(--blue)">
      <div class="d-widget-bar"></div>
      <div class="d-widget-label">Air Baku</div>
      <p> Flow air</p>
      <div style="display:flex;justify-content:center;align-items:center;height:120px">
        <div style="position:relative;width:100px;height:100px">
          <svg viewBox="0 0 100 100" width="100" height="100">
            <circle cx="50" cy="50" r="38" fill="none" stroke="var(--border)" stroke-width="10"/>
            <circle cx="50" cy="50" r="38" fill="none" stroke="var(--blue)" stroke-width="10"
              stroke-dasharray="238.8" stroke-dashoffset="238.8" transform="rotate(-90,50,50)"
              style="transition:stroke-dashoffset 1s ease;stroke-linecap:round" id="gauge1-arc"/>
          </svg>
          <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
            <div style="font-family:'DM Mono',monospace;font-size:18px;font-weight:700;color:var(--blue)" id="gauge1-val">—</div>
            <div style="font-size:8px;color:var(--txt3)">unit</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Widget Filter water -->
    <div class="d-widget" style="--wacc:var(--blue)">
      <div class="d-widget-bar"></div>
      <div class="d-widget-label">Air Feed Slurry</div>
      <div style="display:flex;justify-content:center;align-items:center;height:120px">
        <div style="position:relative;width:100px;height:100px">
          <svg viewBox="0 0 100 100" width="100" height="100">
            <circle cx="50" cy="50" r="38" fill="none" stroke="var(--border)" stroke-width="10"/>
            <circle cx="50" cy="50" r="38" fill="none" stroke="var(--blue)" stroke-width="10"
              stroke-dasharray="238.8" stroke-dashoffset="238.8" transform="rotate(-90,50,50)"
              style="transition:stroke-dashoffset 1s ease;stroke-linecap:round" id="gauge1-arc"/>
          </svg>
          <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
            <div style="font-family:'DM Mono',monospace;font-size:18px;font-weight:700;color:var(--blue)" id="gauge1-val">—</div>
            <div style="font-size:8px;color:var(--txt3)">unit</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Widget Slurry Water -->
    <div class="d-widget" style="--wacc:var(--purple)">\
      <div class="d-widget-bar"></div>
      <div class="d-widget-label">Air EDI</div>
      <div style="display:flex;justify-content:center;align-items:center;height:120px">
        <div style="position:relative;width:100px;height:100px">
          <svg viewBox="0 0 100 100" width="100" height="100">
            <circle cx="50" cy="50" r="38" fill="none" stroke="var(--border)" stroke-width="10"/>
            <circle cx="50" cy="50" r="38" fill="none" stroke="var(--purple)" stroke-width="10"
              stroke-dasharray="238.8" stroke-dashoffset="238.8" transform="rotate(-90,50,50)"
              style="transition:stroke-dashoffset 1s ease;stroke-linecap:round" id="gauge2-arc"/>
          </svg>
          <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
            <div style="font-family:'DM Mono',monospace;font-size:18px;font-weight:700;color:var(--purple)" id="gauge2-val">—</div>
            <div style="font-size:8px;color:var(--txt3)">unit</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Widget Air Steam Generator -->
    <div class="d-widget" style="--wacc:var(--green)">
      <div class="d-widget-bar"></div>
      <div class="d-widget-label">Air Steam Generator</div>
      <div style="display:flex;justify-content:center;align-items:center;height:120px">
        <div style="position:relative;width:100px;height:100px">
          <svg viewBox="0 0 100 100" width="100" height="100">
            <circle cx="50" cy="50" r="38" fill="none" stroke="var(--border)" stroke-width="10"/>
            <circle cx="50" cy="50" r="38" fill="none" stroke="var(--green)" stroke-width="10"
              stroke-dasharray="238.8" stroke-dashoffset="238.8" transform="rotate(-90,50,50)"
              style="transition:stroke-dashoffset 1s ease;stroke-linecap:round" id="gauge3-arc"/>
          </svg>
          <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
            <div style="font-family:'DM Mono',monospace;font-size:18px;font-weight:700;color:var(--green)" id="gauge3-val">—</div>
            <div style="font-size:8px;color:var(--txt3)">unit</div>
          </div>
        </div>
      </div>
    </div>

  </div>
  </div>
`;
}

// ══ INIT WIDGETS ═══════════════════════════════════
