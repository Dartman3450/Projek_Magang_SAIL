// ── openCIP_enh / closeCIP_enh / saveCIP_enh ─────────────────
function openCIP_enh(type, idx) {
  _cipPJIdx = idx;
  const sel = document.getElementById('dep-proj-sel-' + type);
  if (sel) sel.value = idx;
  openCIPModal(type);
}
function closeCIP_enh(type) { closeCIPModal(); }
async function saveCIP_enh(type, isFinish) { await saveCIPModal(type, isFinish); }

window.openCIP_enh = openCIP_enh;
window.closeCIP_enh= closeCIP_enh;
window.saveCIP_enh = saveCIP_enh;
window.openFP      = openFP;
window.closeFP     = closeFP;
window.addFPItem   = addFPItem;
window.saveFP      = saveFP;
window.endProd     = endProd;
window.loadDEProjForm = loadDEProjForm;

function showTDSSt(type, msg) {
  const b = document.getElementById('tds-sb'), m = document.getElementById('tds-sm');
  if (!b || !m) return;
  b.style.display = 'flex'; b.className = 'de-status-bar de-status-' + type; m.textContent = msg;
  if (type !== 'error') setTimeout(() => { if (b) b.style.display = 'none'; }, 4000);
}


// ═══════════════════════════════════════════════════════════
// VACUUM / TEMPERATURE NOTE
// ═══════════════════════════════════════════════════════════
function checkVacuum(key) {
  const inp  = document.getElementById('dep-temp-prod-' + key);
  const note = document.getElementById('dep-vacuum-note-' + key);
  if (!inp || !note) return;
  const val = parseFloat(inp.value);
  if (isNaN(val) || inp.value === '') { note.style.display = 'none'; return; }
  note.style.display = 'block';
  if (val <= 97) {
    note.style.background = '#eff6ff';
    note.style.border = '1px solid #bfdbfe';
    note.style.color = '#1d4ed8';
    note.innerHTML = '💧 <strong>VACUUM</strong> — Suhu ≤97°C, sistem berada dalam kondisi vakum.';
  } else {
    note.style.background = '#fff7ed';
    note.style.border = '1px solid #fed7aa';
    note.style.color = '#c2410c';
    note.innerHTML = '🌡️ <strong>NOT VACUUM</strong> — Suhu >97°C, sistem tidak dalam kondisi vakum.';
  }
}

// ═══════════════════════════════════════════════════════════
// PHOTO UPLOAD + CLIENT-SIDE COMPRESSION
// ═══════════════════════════════════════════════════════════
function handlePhotoUpload(key, input) {
  const preview = document.getElementById(key + '-photo-preview');
  if (!preview) return;
  const files = Array.from(input.files);
  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = e => {
      const img = new Image();
      img.onload = () => {
        // Compress via canvas
        const MAX = 1200;
        let w = img.width, h = img.height;
        if (w > MAX || h > MAX) {
          if (w > h) { h = Math.round(h * MAX / w); w = MAX; }
          else       { w = Math.round(w * MAX / h); h = MAX; }
        }
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        canvas.getContext('2d').drawImage(img, 0, 0, w, h);
        const compressed = canvas.toDataURL('image/jpeg', 0.75);
        const sizeKB = Math.round(compressed.length * 0.75 / 1024);
        // Render thumbnail
        const uid = Date.now() + Math.random();
        const wrap = document.createElement('div');
        wrap.className = 'de-photo-thumb';
        wrap.id = 'photo-' + uid;
        wrap.innerHTML = `
          <img src="${compressed}" alt="${file.name}" style="width:100%;height:100%;object-fit:cover;border-radius:6px;display:block">
          <button class="de-photo-remove" onclick="document.getElementById('photo-${uid}').remove()" title="Hapus foto">✕</button>
          <div class="de-photo-size">${sizeKB} KB</div>`;
        preview.appendChild(wrap);
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
  // Reset input so same file can be re-selected
  input.value = '';
}

// ═══════════════════════════════════════════════════════════
// KARTU STOK
// ═══════════════════════════════════════════════════════════
function getKartuStokHTML() {
  return `
  <div class="de-wrap">
    <div class="de-header">
      <div>
        <div class="de-title">Stock Card</div>
        <div class="de-sub">SAIL / Gudang / Stock Card — 1 Produk = 1 Kartu Stok</div>
      </div>
      <button type="button" class="de-btn de-btn-primary" style="padding:8px 18px;cursor:pointer;" onclick="openSCProductForm()">＋ Tambah Produk</button>
    </div>

    <div class="de-card" style="padding:12px 16px;margin-bottom:0;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <input class="de-input" id="sc-search" placeholder="🔍 Cari nama atau kode produk..." style="flex:1;min-width:200px" oninput="renderStockCards()">
    </div>

    <div id="sc-cards-container" style="display:flex;flex-direction:column;gap:16px;margin-top:4px"></div>
    <div id="sc-empty" style="display:none;padding:56px;text-align:center;color:var(--txt3)">
      <div style="font-size:44px;margin-bottom:10px">📦</div>
      <div style="font-size:13px;font-weight:600">Belum ada produk — klik <strong>＋ Tambah Produk</strong> untuk memulai.</div>
    </div>

    <!-- PRODUCT FORM MODAL -->
    <div class="proj-modal-overlay" id="sc-prod-modal" style="display:none;">
      <div class="proj-modal" style="max-width:540px">
        <div class="proj-modal-head">
          <div class="proj-modal-title" id="sc-prod-modal-title">📦 Tambah Produk</div>
          <button type="button" class="proj-modal-close" onclick="closeSCProductForm()">✕</button>
        </div>
        <div class="proj-modal-body">
          <div style="font-size:10px;font-weight:700;color:var(--txt3);letter-spacing:1px;margin-bottom:10px;text-transform:uppercase;">Informasi Produk (Header Kartu Stok)</div>
          <!-- KODE BARU UNTUK MODAL TAMBAH PRODUK -->
          <div class="de-grid">
              <div class="de-field de-full">
                  <label class="de-label">NAMA BARANG *</label>
                  <input class="de-input" id="sc-p-name" type="text" placeholder="Contoh: Teh Hijau, Golden Oolong Extract...">
              </div>
              <div class="de-field">
                  <label class="de-label">SATUAN BARANG</label>
                  <input class="de-input" id="sc-p-unit" type="text" placeholder="kg, L, pcs...">
              </div>
              
              <!-- MIN & MAX STOK DIHAPUS DARI SINI -->

              <div class="de-field">
                <label class="de-label">LOKASI / GUDANG</label>
                <div id="loc-dropdown-container"></div>
              </div>
              <div class="de-field">
                  <label class="de-label">PENANGGUNG JAWAB (PIC)</label>
                  <input class="de-input" id="sc-p-pic" type="text" placeholder="Nama PIC produk ini...">
              </div>
          </div>
          <div class="de-status-bar" id="sc-p-sb" style="display:none"><span id="sc-p-sm"></span></div>
          <div class="de-actions" style="margin-top:16px">
            <button type="button" class="de-btn de-btn-ghost" onclick="closeSCProductForm()">Batal</button>
            <button type="button" class="de-btn de-btn-primary" onclick="submitSCProduct()">💾 Simpan Produk</button>
          </div>
        </div>
      </div>
    </div>

    <!-- TRANSACTION FORM MODAL -->
    <div class="proj-modal-overlay" id="sc-txn-modal" style="display:none;">
      <div class="proj-modal" style="max-width:520px">
        <div class="proj-modal-head">
          <div class="proj-modal-title" id="sc-txn-modal-title">➕ Tambah Transaksi</div>
          <button type="button" class="proj-modal-close" onclick="closeSCTxnForm()">✕</button>
        </div>
        <div class="proj-modal-body">
          <div style="font-size:11px;font-weight:700;color:var(--blue);margin-bottom:12px;padding:8px 12px;background:#eff6ff;border-radius:6px;border:1px solid #bfdbfe" id="sc-txn-prod-label">📦 Produk: —</div>
          <div class="de-grid">
            <div class="de-field">
              <label class="de-label">TANGGAL *</label>
              <input class="de-input" id="sc-t-date" type="date">
            </div>
            <div class="de-field">
              <label class="de-label">NO. SEAL / BATCH</label>
              <input class="de-input" id="sc-t-seal" placeholder="No. seal, kode batch...">
            </div>
            <div class="de-field">
              <label class="de-label" style="color:#b91c1c">DEBIT — Barang Keluar (OUT)</label>
              <input class="de-input" id="sc-t-debit" type="number" min="0" step="0.001" placeholder="0  (kosongkan jika Masuk)">
            </div>
            <div class="de-field">
              <label class="de-label" style="color:#15803d">CREDIT — Barang Masuk (IN)</label>
              <input class="de-input" id="sc-t-credit" type="number" min="0" step="0.001" placeholder="0  (kosongkan jika Keluar)">
            </div>
            <div class="de-field">
              <label class="de-label">PENANGGUNG JAWAB</label>
              <input class="de-input" id="sc-t-pic" placeholder="Nama PIC transaksi ini...">
            </div>
            <div class="de-field de-full">
              <label class="de-label">DESKRIPSI</label>
              <input class="de-input" id="sc-t-desc" placeholder="Contoh: Pembelian Supplier, Penjualan ke Gudang B...">
            </div>
            <div class="de-field de-full">
              <label class="de-label">KETERANGAN / CATATAN</label>
              <textarea class="de-input de-textarea" id="sc-t-notes" placeholder="Catatan tambahan jika ada..." style="min-height:52px"></textarea>
            </div>
          </div>
          <div class="de-status-bar" id="sc-t-sb" style="display:none"><span id="sc-t-sm"></span></div>
          <div class="de-actions" style="margin-top:16px">
            <button type="button" class="de-btn de-btn-ghost" onclick="closeSCTxnForm()">Batal</button>
            <button type="button" class="de-btn de-btn-primary" onclick="submitSCTxn()">💾 Simpan Transaksi</button>
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

// ── Storage helpers ──────────────────────────────────────────
function gKS()         { try { return JSON.parse(localStorage.getItem('sail_kartu_stok') || '[]'); } catch { return []; } }
function sKS(list)     { localStorage.setItem('sail_kartu_stok', JSON.stringify(list)); }
function gSCProducts() { try { return JSON.parse(localStorage.getItem('sail_sc_products') || '[]'); } catch { return []; } }
function sSCProducts(d){ localStorage.setItem('sail_sc_products', JSON.stringify(d)); }
function gSCTxn()      { try { return JSON.parse(localStorage.getItem('sail_sc_txn') || '[]'); } catch { return []; } }
function sSCTxn(d)     { localStorage.setItem('sail_sc_txn', JSON.stringify(d)); }

let _ksEditIdx    = -1;
let _scProdEditId = null;
let _scTxnProdId  = null;
let _scTxnEditId  = null;

function initKartuStok() {
  renderStockCards();
}

// Pastikan fungsi ini menempel ke window agar bisa dipanggil oleh HTML
window.renderStockCards = function() {
  const q         = (document.getElementById('sc-search')?.value || '').toLowerCase();
  
  // Mengambil data dengan aman
  const products  = typeof gSCProducts === 'function' ? gSCProducts() : [];
  const txnAll    = typeof gSCTxn === 'function' ? gSCTxn() : [];
  
  const container = document.getElementById('sc-cards-container');
  const emptyEl   = document.getElementById('sc-empty');
  if (!container) return;

  const filtered = q
    ? products.filter(p => (p.name||'').toLowerCase().includes(q) || (p.code||'').toLowerCase().includes(q))
    : products;

  if (!filtered.length) {
    container.innerHTML = '';
    if (emptyEl) emptyEl.style.display = 'block';
    return;
  }
  if (emptyEl) emptyEl.style.display = 'none';

  container.innerHTML = filtered.map((p, prodIdx) => {
    const txns = txnAll
      .filter(t => t.productId === p.id)
      .sort((a, b) => (a.date||'').localeCompare(b.date||''));

    let runBal = 0;
    const fmt = v => v ? parseFloat(v).toLocaleString('id-ID',{minimumFractionDigits:0,maximumFractionDigits:3}) : '';
    
    const txnRows = txns.map((t, ti) => {
      const keluar = parseFloat(t.debit)  || 0; 
      const masuk  = parseFloat(t.credit) || 0; 
      runBal += masuk - keluar; 
      
      const balClr = runBal < 0 ? '#dc2626' : '#15803d';
      const rowBg  = ti % 2 === 0 ? '#fff' : '#f8fafc';

      const txtKeluar = keluar ? `<span style="color:#dc2626;font-weight:700;">${fmt(keluar)}</span>` : '';
      const txtMasuk  = masuk ? `<span style="color:#15803d;font-weight:700;">${fmt(masuk)}</span>` : '';

      // No. Seal / Batch dari transaksi
      const sealBatch = t.seal || '—';

      // PERBAIKAN 2: Menambahkan type="button" agar tombol tidak error karena form submit
      return `<tr style="background:${rowBg}">
        <td style="font-family:'DM Mono',monospace;font-size:11px;text-align:center;color:#94a3b8;border:1px solid #e2e8f0;padding:5px 6px">${ti+1}</td>
        <td style="font-size:11px;white-space:nowrap;border:1px solid #e2e8f0;padding:5px 8px;text-align:center;">${t.date||'—'}</td>
        <td style="font-family:'DM Mono',monospace;font-size:11px;border:1px solid #e2e8f0;padding:5px 8px;color:var(--blue);font-weight:600;text-align:center;">${sealBatch}</td>
        <td style="font-family:'DM Mono',monospace;font-size:12px;text-align:center;border:1px solid #e2e8f0;padding:5px 8px">${txtKeluar}</td>
        <td style="font-family:'DM Mono',monospace;font-size:12px;text-align:center;border:1px solid #e2e8f0;padding:5px 8px">${txtMasuk}</td>
        <td style="font-family:'DM Mono',monospace;font-size:13px;font-weight:800;text-align:center;border:1px solid #e2e8f0;padding:5px 8px;color:${balClr}">${runBal.toLocaleString('id-ID',{minimumFractionDigits:0,maximumFractionDigits:3})}</td>
        <td style="font-size:11px;border:1px solid #e2e8f0;padding:5px 8px;text-align:center">${t.pic || '—'}</td>
        <td style="font-size:11px;border:1px solid #e2e8f0;padding:5px 8px;max-width:160px">${t.desc||'—'}</td>
        <td style="border:1px solid #e2e8f0;padding:4px 6px;text-align:center;white-space:nowrap">
          <button type="button" class="pj-btn pj-btn-edit" style="padding:3px 7px;font-size:11px;cursor:pointer;" onclick="editSCTxn('${p.id}','${t.id}')">✏️</button>
          <button type="button" class="pj-btn pj-btn-end"  style="padding:3px 7px;font-size:11px;cursor:pointer;" onclick="deleteSCTxn('${t.id}')">🗑️</button>
        </td>
      </tr>`;
    }).join('');

    const finalBal   = txns.reduce((acc, t) => acc + (parseFloat(t.credit)||0) - (parseFloat(t.debit)||0), 0);
    const balChipBg  = finalBal < 0 ? '#fee2e2' : '#dcfce7';
    const balChipClr = finalBal < 0 ? '#b91c1c' : '#15803d';
    const balChipBdr = finalBal < 0 ? '#fca5a5' : '#86efac';

    // PERBAIKAN 3: Memastikan string HTML aman dari syntax error yang membuat tombol unclickable
    return `
    <div style="border:2px solid #22c55e;border-radius:10px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.07);margin-bottom:20px;">
      <div style="background:#22c55e;padding:10px 18px;display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
        <div style="font-size:15px;font-weight:800;color:#fff;letter-spacing:.3px">📋 LAPORAN KARTU STOK BARANG</div>
        <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
          <div style="background:${balChipBg};border:1px solid ${balChipBdr};color:${balChipClr};padding:3px 12px;border-radius:100px;font-size:11px;font-weight:800;white-space:nowrap">
            Saldo: ${finalBal.toLocaleString('id-ID')} ${p.unit||''}
          </div>
          <button type="button" class="pj-btn" style="background:rgba(255,255,255,.2);border-color:rgba(255,255,255,.4);color:#fff;font-size:11px;padding:4px 10px;cursor:pointer;" onclick="openSCProductForm(${prodIdx})">✏️ Edit</button>
          <button type="button" class="pj-btn" style="background:rgba(220,38,38,.2);border-color:rgba(220,38,38,.5);color:#fca5a5;font-size:11px;padding:4px 10px;cursor:pointer;" onclick="deleteSCProduct('${p.id}')">🗑️</button>
          <button type="button" style="background:#15803d;color:#fff;border:none;border-radius:6px;padding:5px 13px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit" onclick="openSCTxnForm('${p.id}')">➕ Tambah Transaksi</button>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;background:#fff;border-bottom:2px solid #22c55e">
        <div style="padding:10px 18px;border-right:1px solid #e2e8f0">
          <table style="width:100%;border-collapse:collapse;font-size:12px">
            <tr><td style="color:#64748b;padding:2px 0;width:120px;font-weight:600">Nama Barang</td><td style="padding:2px 0">: <strong>${p.name}</strong></td></tr>
            <tr><td style="color:#64748b;padding:2px 0;font-weight:600">Satuan Barang</td><td style="padding:2px 0">: ${p.unit||'—'}</td></tr>
          </table>
        </div>
        <div style="padding:10px 18px">
          <table style="width:100%;border-collapse:collapse;font-size:12px">
            <tr><td style="color:#64748b;padding:2px 0;width:120px;font-weight:600">Lokasi / Gudang</td><td style="padding:2px 0">: ${p.loc||'—'}</td></tr>
            <tr><td style="color:#64748b;padding:2px 0;font-weight:600">Penanggung Jawab</td><td style="padding:2px 0">: ${p.pic||'—'}</td></tr>
          </table>
        </div>
      </div>

      <div style="overflow-x:auto;background:#fff">
        <table style="width:100%;border-collapse:collapse;min-width:900px">
          <thead>
            <tr style="background:#22c55e;color:#fff">
              <th style="border:1px solid #16a34a;padding:7px 6px;font-size:11px;text-align:center;width:36px">NO.</th>
              <th style="border:1px solid #16a34a;padding:7px 8px;font-size:11px;text-align:center;white-space:nowrap">TANGGAL</th>
              <th style="border:1px solid #16a34a;padding:7px 8px;font-size:11px;text-align:center">NO. SEAL / BATCH</th>
              <th style="border:1px solid #16a34a;padding:7px 8px;font-size:11px;text-align:center;white-space:nowrap">BARANG KELUAR (DEBIT)</th>
              <th style="border:1px solid #16a34a;padding:7px 8px;font-size:11px;text-align:center;white-space:nowrap">BARANG MASUK (KREDIT)</th>
              <th style="border:1px solid #16a34a;padding:7px 8px;font-size:11px;text-align:center">SISA</th>
              <th style="border:1px solid #16a34a;padding:7px 8px;font-size:11px;text-align:center;white-space:nowrap">PENANGGUNG JAWAB</th>
              <th style="border:1px solid #16a34a;padding:7px 8px;font-size:11px;text-align:center">DESKRIPSI</th>
              <th style="border:1px solid #16a34a;padding:7px 8px;font-size:11px;text-align:center;width:68px">AKSI</th>
            </tr>
          </thead>
          <tbody>
            ${txnRows || `<tr><td colspan="9" style="text-align:center;padding:32px;color:#94a3b8;font-size:12px;border:1px solid #e2e8f0">Belum ada transaksi — klik <strong>➕ Tambah Transaksi</strong></td></tr>`}
          </tbody>
        </table>
      </div>
    </div>`;
  }).join('');
};

function openSCProductForm(idx = -1) {
  _scProdEditId = null;
  const products = gSCProducts();
  if (idx >= 0 && idx < products.length) {
    const p = products[idx];
    _scProdEditId = p.id;
    document.getElementById('sc-prod-modal-title').textContent = '✏️ Edit Produk';
    document.getElementById('sc-p-name').value = p.name || '';
    document.getElementById('sc-p-unit').value = p.unit || '';
    document.getElementById('sc-p-pic').value  = p.pic  || '';
    
    // Injeksi dropdown dengan value lama
    document.getElementById('loc-dropdown-container').innerHTML = buildLocationDropdown('sc-p-loc', p.loc || '');
  } else {
    document.getElementById('sc-prod-modal-title').textContent = '📦 Tambah Produk';
    ['sc-p-name','sc-p-unit','sc-p-pic'].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = '';
    });
    // Injeksi dropdown kosong
    document.getElementById('loc-dropdown-container').innerHTML = buildLocationDropdown('sc-p-loc', '');
  }
  const sb = document.getElementById('sc-p-sb'); if (sb) sb.style.display = 'none';
  const m  = document.getElementById('sc-prod-modal');
  if (m) { m.style.display = 'flex'; m.classList.add('show'); }
}

function submitSCProduct() {
  const name = document.getElementById('sc-p-name')?.value.trim();
  if (!name) { showSCProdSt('error', '❌ Nama barang wajib diisi!'); return; }
  const products = gSCProducts();
  
  // Mengambil value dari ID dropdown
  const locVal = document.getElementById('sc-p-loc')?.value.trim();

  const entry = {
    id:   _scProdEditId || Date.now().toString(),
    name,
    unit: document.getElementById('sc-p-unit')?.value.trim() || '',
    loc:  locVal === '__ADD_NEW__' ? '' : locVal,
    pic:  document.getElementById('sc-p-pic')?.value.trim() || '',
  };
  
  if (_scProdEditId) {
    const idx = products.findIndex(p => p.id === _scProdEditId);
    if (idx >= 0) products[idx] = entry; else products.push(entry);
  } else {
    products.push(entry);
  }
  sSCProducts(products);
  showSCProdSt('success', _scProdEditId ? '✅ Produk diperbarui!' : '✅ Produk ditambahkan!');
  setTimeout(() => { closeSCProductForm(); renderStockCards(); }, 700);
}

function closeSCProductForm() {
  const m = document.getElementById('sc-prod-modal');
  if (m) { m.style.display = 'none'; m.classList.remove('show'); }
  _scProdEditId = null;
}

function deleteSCProduct(id) {
  const p = gSCProducts().find(x => x.id === id);
  if (!confirm(`Delete product "${p?.name||id}" and ALL its transactions?`)) return;
  sSCProducts(gSCProducts().filter(x => x.id !== id));
  sSCTxn(gSCTxn().filter(t => t.productId !== id));
  renderStockCards();
  showQuickToast('🗑️ Product deleted.');
}

// ── TRANSACTION FORM ─────────────────────────────────────────
function openSCTxnForm(productId, txnId = null) {
  _scTxnProdId = productId;
  _scTxnEditId = txnId;
  const today = new Date().toISOString().split('T')[0];

  const p   = gSCProducts().find(x => x.id === productId);
  const lbl = document.getElementById('sc-txn-prod-label');
  if (lbl) lbl.textContent = p ? `📦 Product: ${p.name}` : '';

  if (txnId) {
    const t = gSCTxn().find(x => x.id === txnId);
    if (t) {
      document.getElementById('sc-txn-modal-title').textContent = '✏️ Edit Transaksi';
      document.getElementById('sc-t-date').value   = t.date   || today;
      document.getElementById('sc-t-debit').value  = t.debit  || '';
      document.getElementById('sc-t-credit').value = t.credit || '';
      document.getElementById('sc-t-seal').value   = t.seal   || '';
      document.getElementById('sc-t-pic').value    = t.pic    || '';
      document.getElementById('sc-t-desc').value   = t.desc   || '';
      document.getElementById('sc-t-notes').value  = t.notes  || '';
    }
  } else {
    document.getElementById('sc-txn-modal-title').textContent = '➕ Tambah Transaksi';
    document.getElementById('sc-t-date').value = today;
    ['sc-t-debit','sc-t-credit','sc-t-seal','sc-t-pic','sc-t-desc','sc-t-notes'].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = '';
    });
  }
  const sb = document.getElementById('sc-t-sb'); if (sb) sb.style.display = 'none';
  const m  = document.getElementById('sc-txn-modal');
  if (m) { m.style.display = 'flex'; m.classList.add('show'); }
}

function closeSCTxnForm() {
  const m = document.getElementById('sc-txn-modal');
  if (m) { m.style.display = 'none'; m.classList.remove('show'); }
  _scTxnProdId = null; _scTxnEditId = null;
}

function submitSCTxn() {
  const date   = document.getElementById('sc-t-date')?.value;
  if (!date)   { showSCTxnSt('error', '❌ Date is required!'); return; }
  const debit  = document.getElementById('sc-t-debit')?.value  || '';
  const credit = document.getElementById('sc-t-credit')?.value || '';
  if (!debit && !credit) { showSCTxnSt('error', '❌ Fill in Debit (In) or Credit (Out)!'); return; }
  const txns  = gSCTxn();
  const entry = {
    id:        _scTxnEditId || Date.now().toString(),
    productId: _scTxnProdId,
    date, debit, credit,
    seal:  document.getElementById('sc-t-seal')?.value.trim()  || '',
    pic:   document.getElementById('sc-t-pic')?.value.trim()   || '',
    desc:  document.getElementById('sc-t-desc')?.value.trim()  || '',
    notes: document.getElementById('sc-t-notes')?.value.trim() || '',
  };
  if (_scTxnEditId) {
    const idx = txns.findIndex(t => t.id === _scTxnEditId);
    if (idx >= 0) txns[idx] = entry; else txns.push(entry);
  } else {
    txns.push(entry);
  }
  sSCTxn(txns);
  showSCTxnSt('success', '✅ Transaction saved!');
  setTimeout(() => { closeSCTxnForm(); renderStockCards(); }, 700);
}

function editSCTxn(productId, txnId) {
  openSCTxnForm(productId, txnId);
}

function deleteSCTxn(txnId) {
  if (!confirm('Delete this transaction?')) return;
  sSCTxn(gSCTxn().filter(t => t.id !== txnId));
  renderStockCards();
  showQuickToast('🗑️ Transaction deleted.');
}

function showSCProdSt(type, msg) {
  const b = document.getElementById('sc-p-sb'), m = document.getElementById('sc-p-sm');
  if (!b || !m) return;
  b.style.display = 'flex'; b.className = 'de-status-bar de-status-' + type; m.textContent = msg;
  if (type === 'success') setTimeout(() => { if (b) b.style.display = 'none'; }, 3000);
}

function showSCTxnSt(type, msg) {
  const b = document.getElementById('sc-t-sb'), m = document.getElementById('sc-t-sm');
  if (!b || !m) return;
  b.style.display = 'flex'; b.className = 'de-status-bar de-status-' + type; m.textContent = msg;
  if (type === 'success') setTimeout(() => { if (b) b.style.display = 'none'; }, 3000);
}

// ── HELPER: DROPDOWN LOKASI DINAMIS ──
window.buildLocationDropdown = function(id, value) {
    const locations = JSON.parse(localStorage.getItem('custom_stock_locations') || '["Gudang A, Rak 1", "Gudang B"]');
    let opts = '<option value="">-- Pilih Lokasi --</option>';
    opts += '<option value="__ADD_NEW__" style="font-weight:bold;color:var(--blue);">＋ Tambah Lokasi Baru...</option>';
    
    locations.forEach(loc => {
        const sel = (loc === value) ? 'selected' : '';
        opts += `<option value="${loc}" ${sel}>${loc}</option>`;
    });

    if (value && !locations.includes(value) && value !== '__ADD_NEW__') {
        opts += `<option value="${value}" selected>${value}</option>`;
    }

    const showDel = locations.includes(value) ? 'block' : 'none';

    return `
    <div style="display:flex;flex-direction:column;gap:6px;width:100%;">
        <div style="display:flex;gap:6px;align-items:center;width:100%;">
            <select class="de-input de-select loc-dropdown" id="${id}" style="flex:1" onchange="handleLocChange('${id}')" data-prev-value="${value || ''}">
                ${opts}
            </select>
            <button type="button" id="${id}-del" onclick="deleteLocation('${id}')" style="display:${showDel};background:none;border:none;color:var(--red);font-size:18px;font-weight:bold;cursor:pointer;padding:0 5px;" title="Hapus Lokasi Ini">✕</button>
        </div>
        <div id="${id}-custom-wrap" style="display:none; gap:6px; align-items:center;">
            <input class="de-input exclude-save" id="${id}-new" type="text" placeholder="Nama lokasi baru..." style="flex:1;">
            <button type="button" class="de-btn de-btn-primary exclude-save" style="padding:7px 14px;font-size:11px" onclick="saveNewLocation('${id}')">Simpan</button>
            <button type="button" class="exclude-save" onclick="cancelAddLocation('${id}')" style="background:none;border:none;color:var(--red);font-size:18px;font-weight:bold;cursor:pointer;padding:0 5px;" title="Batal">✕</button>
        </div>
    </div>`;
};

window.handleLocChange = function(id) {
    const sel = document.getElementById(id);
    const delBtn = document.getElementById(id + '-del');
    const customWrap = document.getElementById(id + '-custom-wrap');
    if (!sel) return;

    if (sel.value === '__ADD_NEW__') {
        customWrap.style.display = 'flex';
        delBtn.style.display = 'none';
    } else {
        customWrap.style.display = 'none';
        const locations = JSON.parse(localStorage.getItem('custom_stock_locations') || '[]');
        delBtn.style.display = locations.includes(sel.value) ? 'block' : 'none';
    }
};

window.saveNewLocation = function(id) {
    const input = document.getElementById(id + '-new');
    const newVal = input.value.trim();
    if (!newVal) return alert('Lokasi tidak boleh kosong!');

    let locations = JSON.parse(localStorage.getItem('custom_stock_locations') || '[]');
    if (!locations.includes(newVal)) {
        locations.push(newVal);
        localStorage.setItem('custom_stock_locations', JSON.stringify(locations));
    }

    document.getElementById(id + '-custom-wrap').style.display = 'none';
    document.querySelectorAll('.loc-dropdown').forEach(dropdown => {
        const currentVal = dropdown.id === id ? newVal : dropdown.value;
        dropdown.outerHTML = buildLocationDropdown(dropdown.id, currentVal);
    });
};

window.cancelAddLocation = function(id) {
    const sel = document.getElementById(id);
    document.getElementById(id + '-custom-wrap').style.display = 'none';
    sel.value = sel.getAttribute('data-prev-value') || '';
    if(sel.value === '__ADD_NEW__') sel.value = '';
    handleLocChange(id);
};

window.deleteLocation = function(id) {
    const sel = document.getElementById(id);
    const val = sel.value;
    if (!val || val === '__ADD_NEW__') return;

    if (confirm(`Hapus lokasi "${val}" dari daftar?`)) {
        let locations = JSON.parse(localStorage.getItem('custom_stock_locations') || '[]');
        locations = locations.filter(l => l !== val);
        localStorage.setItem('custom_stock_locations', JSON.stringify(locations));
        
        document.querySelectorAll('.loc-dropdown').forEach(dropdown => {
            const currentVal = dropdown.value === val ? '' : dropdown.value;
            dropdown.outerHTML = buildLocationDropdown(dropdown.id, currentVal);
        });
    }
};

// ── Backward compat stubs ─────────────────────────────────────
function openKartuStokForm()  { openSCProductForm(); }
function closeKartuStokForm() { closeSCProductForm(); }
function submitKartuStok()    { submitSCProduct(); }
function renderKartuStok()    { renderStockCards(); }
function editKartuStok()  {}
function deleteKartuStok() {}
function showKsSt(type, msg) {}
window.editKartuStok    = editKartuStok;
window.deleteKartuStok  = deleteKartuStok;
window.openSCProductForm  = openSCProductForm;
window.closeSCProductForm = closeSCProductForm;
window.submitSCProduct    = submitSCProduct;
window.deleteSCProduct    = deleteSCProduct;
window.openSCTxnForm  = openSCTxnForm;
window.closeSCTxnForm = closeSCTxnForm;
window.submitSCTxn    = submitSCTxn;
window.editSCTxn      = editSCTxn;
window.deleteSCTxn    = deleteSCTxn;
window.renderStockCards = renderStockCards;

// ═══════════════════════════════════════════════════════════
// SURAT JALAN
// ═══════════════════════════════════════════════════════════