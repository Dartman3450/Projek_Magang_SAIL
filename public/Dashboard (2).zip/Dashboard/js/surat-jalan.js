function gSJ()       { try { return JSON.parse(localStorage.getItem('sail_surat_jalan') || '[]'); } catch { return []; } }
function sSJ(list)   { localStorage.setItem('sail_surat_jalan', JSON.stringify(list)); }
window.gSJ = gSJ;
window.sSJ = sSJ;

function getSuratJalanHTML() {
  return `<div class="de-wrap">
  <div class="de-header">
    <div><div class="de-title">Surat Jalan</div><div class="de-sub">SAIL / Reporting / Surat Jalan</div></div>
    <button type="button" class="de-btn de-btn-primary" onclick="openSuratJalanForm()">＋ Buat Surat Jalan</button>
  </div>

  <div id="sj-list" style="display:flex;flex-direction:column;gap:12px"></div>
  <div id="sj-empty" style="display:none">
    <div class="de-card" style="text-align:center;padding:48px">
      <div style="font-size:32px;margin-bottom:8px">📋</div>
      <div style="font-size:13px;color:var(--txt3)">Belum ada surat jalan — klik <strong>＋ Buat Surat Jalan</strong>.</div>
    </div>
  </div>

  <div class="proj-modal-overlay" id="sj-modal-overlay" style="display:none;">
    <div class="proj-modal" style="max-width:680px">
      <div class="proj-modal-head">
        <div class="proj-modal-title" id="sj-modal-title">📋 Buat Surat Jalan</div>
        <button type="button" class="proj-modal-close" onclick="closeSuratJalanForm()">✕</button>
      </div>
      <div class="proj-modal-body">
        <div class="de-grid">
          <div class="de-field"><label class="de-label">TANGGAL</label><input class="de-input" id="sj-f-date" type="date"></div>
          <div class="de-field"><label class="de-label">NO. SURAT JALAN</label><input class="de-input" id="sj-f-no" type="text" placeholder="Otomatis atau isi manual"></div>
          <div class="de-field"><label class="de-label">NOPOL / KENDARAAN</label><input class="de-input" id="sj-f-kendaraan" type="text" placeholder="B 1234 XY / Nama ekspedisi..."></div>
          <div class="de-field"><label class="de-label">DRIVER</label><input class="de-input" id="sj-f-driver" type="text" placeholder="Nama driver..."></div>
          <div class="de-field de-full"><label class="de-label">TUJUAN *</label><input class="de-input" id="sj-f-penerima" type="text" placeholder="Nama perusahaan atau orang..."></div>
          <div class="de-field de-full"><label class="de-label">PENGIRIM (Gudang)</label><input class="de-input" id="sj-f-pengirim" type="text" placeholder="Nama pengirim dari gudang..."></div>
        </div>

        <!-- PILIH DARI KARTU STOK -->
        <div style="margin:14px 0 8px;font-size:11px;font-weight:700;color:var(--txt3);letter-spacing:1px;text-transform:uppercase">Daftar Barang</div>
        <div style="display:flex;gap:8px;align-items:flex-end;padding:10px 12px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;margin-bottom:8px;flex-wrap:wrap">
          <div style="flex:1;min-width:150px">
            <div style="font-size:9px;font-weight:700;color:var(--blue);letter-spacing:.8px;margin-bottom:4px">📦 PILIH KARTU STOK</div>
            <select class="de-input de-select" id="sj-kartu-picker" style="margin:0;font-size:11px" onchange="onSjKartuChange()">
              <option value="">-- Pilih produk --</option>
            </select>
          </div>
          <div style="flex:1;min-width:150px">
            <div style="font-size:9px;font-weight:700;color:var(--blue);letter-spacing:.8px;margin-bottom:4px">🔖 NO. BATCH / SEAL</div>
            <select class="de-input de-select" id="sj-batch-picker" style="margin:0;font-size:11px" onchange="onSjBatchChange()">
              <option value="">-- Pilih batch --</option>
            </select>
          </div>
          <div style="width:80px">
            <div style="font-size:9px;font-weight:700;color:var(--blue);letter-spacing:.8px;margin-bottom:4px">BERAT</div>
            <input class="de-input" id="sj-batch-qty" type="number" step="any" placeholder="0" style="margin:0;font-size:11px;text-align:center">
          </div>
          <button type="button" class="de-btn de-btn-primary" style="height:34px;font-size:11px;white-space:nowrap;flex-shrink:0" onclick="addSjItemFromKartu()">＋ Tambah</button>
        </div>

        <!-- HEADER TABEL ITEM -->
        <div style="display:grid;grid-template-columns:1.6fr 1.6fr 70px 1.4fr 30px;gap:4px;padding:6px 10px;background:#f1f5f9;border-radius:6px 6px 0 0;border:1px solid var(--border);border-bottom:none;align-items:center;">
          <div style="font-size:9px;font-weight:700;color:var(--txt3);letter-spacing:.8px">KARTU STOK / PRODUK</div>
          <div style="font-size:9px;font-weight:700;color:var(--txt3);letter-spacing:.8px">NO. BATCH / SEAL</div>
          <div style="font-size:9px;font-weight:700;color:var(--txt3);letter-spacing:.8px;text-align:center">BERAT</div>
          <div style="font-size:9px;font-weight:700;color:var(--txt3);letter-spacing:.8px">KETERANGAN</div>
          <div></div>
        </div>
        <div id="sj-items"></div>
        <button type="button" class="de-btn de-btn-ghost" style="width:100%;margin-bottom:14px;border-radius:0 0 6px 6px;border-top:none;font-size:12px;background:#f9fafb;" onclick="addSuratJalanItem()">＋ Tambah Manual</button>

        <div style="padding:8px 12px;background:#fefce8;border:1px solid #fde68a;border-radius:6px;font-size:10px;color:#92400e;margin-bottom:12px">
          ⚡ Saat disimpan, barang yang diambil dari Kartu Stok akan otomatis tercatat sebagai <strong>Barang Keluar (Debit)</strong> di kartu stok terkait.
        </div>

        <div class="de-field de-full"><label class="de-label">CATATAN</label><textarea class="de-input de-textarea" id="sj-f-notes" style="min-height:56px" placeholder="Catatan tambahan..."></textarea></div>
        <div class="de-status-bar" id="sj-sb" style="display:none"><span id="sj-sm"></span></div>
        <div class="de-actions" style="margin-top:16px">
          <button type="button" class="de-btn de-btn-ghost" onclick="closeSuratJalanForm()">Batal</button>
          <button type="button" class="de-btn de-btn-primary" onclick="submitSuratJalan()">💾 Simpan Surat Jalan</button>
        </div>
      </div>
    </div>
  </div>
</div>`;
}
function openSuratJalanForm(idx=-1) {
  _sjEditIdx = idx; _sjItemCount = 0;
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('sj-items').innerHTML = '';
  const sb = document.getElementById('sj-sb'); if(sb) sb.style.display='none';
  populateSjKartuPicker();
  // Reset picker
  const kp = document.getElementById('sj-kartu-picker');
  const bp = document.getElementById('sj-batch-picker');
  const qp = document.getElementById('sj-batch-qty');
  if(kp) kp.value=''; if(qp) qp.value='';
  if(bp) bp.innerHTML='<option value="">-- Pilih batch --</option>';

  if (idx >= 0) {
    const sj = gSJ()[idx];
    document.getElementById('sj-modal-title').textContent = '✏️ Edit Surat Jalan';
    document.getElementById('sj-f-no').value        = sj.no || '';
    document.getElementById('sj-f-date').value      = sj.date || today;
    document.getElementById('sj-f-penerima').value  = sj.penerima || '';
    document.getElementById('sj-f-kendaraan').value = sj.kendaraan || '';
    document.getElementById('sj-f-driver').value    = sj.driver || '';
    document.getElementById('sj-f-pengirim').value  = sj.pengirim || '';
    document.getElementById('sj-f-notes').value     = sj.notes || '';
    (sj.items||[]).forEach(it => addSuratJalanItem(it));
  } else {
    document.getElementById('sj-modal-title').textContent = '📋 Buat Surat Jalan';
    document.getElementById('sj-f-no').value = genSJNo();
    document.getElementById('sj-f-date').value = today;
    ['sj-f-penerima','sj-f-kendaraan','sj-f-driver','sj-f-pengirim','sj-f-notes'].forEach(id => {
      const el = document.getElementById(id); if(el) el.value = '';
    });
    addSuratJalanItem();
  }
  const modal = document.getElementById('sj-modal-overlay');
  if (modal) { modal.style.display = 'flex'; modal.classList.add('show'); }
}

function closeSuratJalanForm() {
  // 💡 FIX: Sembunyikan total dengan display none
  const modal = document.getElementById('sj-modal-overlay');
  if (modal) {
      modal.style.display = 'none';
      modal.classList.remove('show');
  }
  _sjEditIdx = -1;
}

function genSJNo() {
  const today = new Date();
  const dd = String(today.getDate()).padStart(2, '0');
  const mm = String(today.getMonth() + 1).padStart(2, '0');
  const yyyy = today.getFullYear();
  const dateStr = `${dd}${mm}${yyyy}`;

  // Kunci sequence harian
  const key = 'sj_seq_' + dateStr;
  const seq = (parseInt(localStorage.getItem(key) || '0')) + 1;
  localStorage.setItem(key, seq);

  return `SJ${String(seq).padStart(3, '0')}-${dateStr}`;
}

function initSuratJalan() {
  renderSuratJalan();
}
function renderSuratJalan() {
  const list  = document.getElementById('sj-list');
  const empty = document.getElementById('sj-empty');
  if (!list) return;
  const data = gSJ();
  if (!data.length) { list.innerHTML=''; empty.style.display='block'; return; }
  empty.style.display = 'none';
  list.innerHTML = data.map((sj, idx) => `
    <div class="de-card" style="padding:16px 20px">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap">
        <div>
          <div style="font-family:'DM Mono',monospace;font-size:12px;font-weight:700;color:var(--blue);margin-bottom:4px">${sj.no}</div>
          <div style="font-size:14px;font-weight:700;color:var(--txt)">→ ${sj.penerima}</div>
          <div style="font-size:11px;color:var(--txt3);margin-top:2px">📅 ${sj.date} &nbsp;•&nbsp; 🚚 ${sj.kendaraan||'—'} &nbsp;•&nbsp; 🧑 ${sj.driver||sj.pengirim||'—'}</div>
        </div>
        <div style="display:flex;gap:6px;flex-shrink:0">
          <button class="pj-btn" style="border-color:#dc2626;color:#dc2626;background:#fff5f5;" onclick="downloadSuratJalanPDF(${idx})">📄 PDF</button>
          <button class="pj-btn pj-btn-edit" onclick="editSuratJalan(${idx})">✏️ Edit</button>
          <button class="pj-btn pj-btn-end" onclick="deleteSuratJalan(${idx})">🗑️</button>
        </div>
      </div>
      ${sj.items?.length ? `
      <div style="margin-top:12px;overflow-x:auto;border:1px solid var(--border);border-radius:8px">
        <table style="width:100%;border-collapse:collapse;font-size:11px">
          <thead><tr style="background:var(--bg)">
            <th style="padding:7px 10px;text-align:left;color:var(--txt3);font-size:9px;text-transform:uppercase;letter-spacing:.8px">No</th>
            <th style="padding:7px 10px;text-align:left;color:var(--txt3);font-size:9px;text-transform:uppercase;letter-spacing:.8px">Nama Barang</th>
            <th style="padding:7px 10px;text-align:left;color:var(--txt3);font-size:9px;text-transform:uppercase;letter-spacing:.8px">No. Batch/Seal</th>
            <th style="padding:7px 10px;text-align:center;color:var(--txt3);font-size:9px;text-transform:uppercase;letter-spacing:.8px">QTY</th>
            <th style="padding:7px 10px;text-align:left;color:var(--txt3);font-size:9px;text-transform:uppercase;letter-spacing:.8px">Keterangan</th>
          </tr></thead>
          <tbody>${sj.items.map((it,i) => `
            <tr style="background:${i%2===0?'white':'#f9fafb'}">
              <td style="padding:7px 10px;color:var(--txt3)">${i+1}</td>
              <td style="padding:7px 10px;color:var(--txt);font-weight:600">${it.name||'—'}</td>
              <td style="padding:7px 10px;font-size:10px;color:var(--txt3)">${it.seal||it.kode||'—'}</td>
              <td style="padding:7px 10px;text-align:center;font-family:'DM Mono',monospace;font-weight:600;color:var(--blue)">${it.qty||'—'}</td>
              <td style="padding:7px 10px;color:var(--txt2)">${it.desc||'—'}</td>
            </tr>`).join('')}</tbody>
        </table>
      </div>` : ''}
      ${sj.notes ? `<div style="margin-top:10px;font-size:11px;color:var(--txt3);padding:8px 12px;background:var(--bg);border-radius:6px;border:1px solid var(--border)">📝 ${sj.notes}</div>` : ''}
    </div>`).join('');
}
function downloadSuratJalanPDF(idx) {
  const sj = gSJ()[idx];
  if (!sj) return;

  // Format tanggal: dd MMMM yyyy (Indonesia)
  const fmtDate = (d) => {
    if (!d) return '—';
    const dt = new Date(d);
    return dt.toLocaleDateString('id-ID', { day:'2-digit', month:'long', year:'numeric' });
  };

  // Format No. SJ → SJ/dd/mm/yyyy dari tanggal dokumen
  const fmtNoSJ = (d) => {
    if (!d) return sj.no || '—';
    const dt = new Date(d);
    const dd = String(dt.getDate()).padStart(2,'0');
    const mm = String(dt.getMonth()+1).padStart(2,'0');
    const yyyy = dt.getFullYear();
    return `SJ/${dd}/${mm}/${yyyy}`;
  };

  // Baris barang — hanya sebanyak produk yang diisi (tidak ada padding kosong)
  const items = sj.items?.filter(it => it.name?.trim()) || [];
  const rowsHTML = items.length
    ? items.map((it, i) => `
        <tr>
          <td style="border:1px solid #555;padding:4px 7px;text-align:center;">${i+1}</td>
          <td style="border:1px solid #555;padding:4px 7px;">${it.name||''}</td>
          <td style="border:1px solid #555;padding:4px 7px;font-size:9px;color:#555">${it.seal||it.kode||''}</td>
          <td style="border:1px solid #555;padding:4px 7px;text-align:center;">${it.qty||''}</td>
          <td style="border:1px solid #555;padding:4px 7px;">${it.desc||''}</td>
        </tr>`).join('')
    : `<tr>
        <td style="border:1px solid #555;padding:4px 7px;text-align:center;">1</td>
        <td style="border:1px solid #555;padding:4px 7px;">&nbsp;</td>
        <td style="border:1px solid #555;padding:4px 7px;">&nbsp;</td>
        <td style="border:1px solid #555;padding:4px 7px;">&nbsp;</td>
        <td style="border:1px solid #555;padding:4px 7px;">&nbsp;</td>
       </tr>`;

  // Satu blok form (dipakai 2x)
  const formBlock = `
    <div class="sj-form">
      <div class="header">
        <div class="logo-box">PT SILIWANGI<br>AGRO<br>INDO LESTARI</div>
        <div class="doc-title">SURAT JALAN</div>
      </div>
      <table class="info-table">
        <tr>
          <td class="lbl">Tanggal</td><td class="sep">:</td>
          <td class="val">${fmtDate(sj.date)}</td>
          <td style="width:30px"></td>
          <td class="lbl" style="text-align:right">Tujuan</td><td class="sep">:</td>
          <td class="val" style="min-width:160px;">${sj.penerima||''}</td>
        </tr>
        <tr>
          <td class="lbl">No. SJ</td><td class="sep">:</td>
          <td class="val">${fmtNoSJ(sj.date)}</td>
          <td></td><td></td><td></td><td></td>
        </tr>
        <tr>
          <td class="lbl">Nopol / Kendaraan</td><td class="sep">:</td>
          <td class="val">${sj.kendaraan||''}</td>
          <td></td><td></td><td></td><td></td>
        </tr>
        <tr>
          <td class="lbl">Driver</td><td class="sep">:</td>
          <td class="val">${sj.driver||''}</td>
          <td></td><td></td><td></td><td></td>
        </tr>
      </table>
      <div style="font-size:11px;margin-bottom:6px;">Dikirimkan barang-barang sebagai berikut :</div>
      <table class="items-table">
        <thead>
          <tr>
            <th style="width:32px;">No</th>
            <th>Nama Barang</th>
            <th style="width:90px;">No. Batch/Seal</th>
            <th style="width:60px;">QTY</th>
            <th style="width:180px;">Keterangan</th>
          </tr>
        </thead>
        <tbody>${rowsHTML}</tbody>
      </table>
      ${sj.notes ? `<div style="font-size:10px;margin-bottom:7px;">Catatan: ${sj.notes}</div>` : ''}
      <div class="sig-row">
        <div class="sig-box"><div class="sig-title">Gudang</div><div class="sig-name">${sj.pengirim||''}</div></div>
        <div class="sig-box"><div class="sig-title">Driver</div><div class="sig-name">${sj.driver||''}</div></div>
        <div class="sig-box"><div class="sig-title">Diterima Oleh</div><div class="sig-name"></div></div>
      </div>
    </div>`;

  const html = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Surat Jalan ${fmtNoSJ(sj.date)}</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family: Arial, sans-serif; font-size:11px; color:#000; background:#fff; }

    .page {
      width: 210mm;
      min-height: 297mm;
      margin: 0 auto;
      padding: 8mm 12mm;
      display: flex;
      flex-direction: column;
      gap: 0;
    }

    .sj-form {
      flex: 1;
      padding: 8px 0 6px 0;
      border-bottom: 2px dashed #aaa;
    }
    .sj-form:last-child { border-bottom: none; }

    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 2.5px solid #333;
      padding-bottom: 7px;
      margin-bottom: 10px;
    }
    .logo-box {
      width: 62px; height: 52px;
      border: 1px solid #aaa;
      display: flex; align-items: center; justify-content: center;
      font-size: 8px; color: #555; text-align: center; border-radius: 3px;
    }
    .doc-title { font-size: 20px; font-weight: 700; letter-spacing: 2px; }

    .info-table { width: 100%; margin-bottom: 10px; }
    .info-table td { padding: 2px 5px; vertical-align: top; font-size: 11px; }
    .info-table td.lbl { width: 120px; font-weight: 600; }
    .info-table td.sep { width: 12px; text-align: center; }
    .info-table td.val { border-bottom: 1px solid #999; min-width: 140px; }

    .items-table { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
    .items-table thead tr { background: #3a4a5c; color: #fff; }
    .items-table th { border: 1px solid #555; padding: 5px 7px; text-align: center; font-size: 10px; }
    .items-table td { border: 1px solid #555; padding: 4px 7px; font-size: 10px; }

    .sig-row { display: flex; border: 1px solid #555; }
    .sig-box { flex: 1; padding: 8px 12px; min-height: 60px; border-right: 1px solid #555; }
    .sig-box:last-child { border-right: none; }
    .sig-title { font-size: 10px; font-weight: 700; margin-bottom: 4px; }
    .sig-name  { font-size: 10px; margin-top: 3px; min-height: 36px; }

    @media print {
      body { margin: 0; }
      .page { padding: 8mm 12mm; }
      @page { size: A4; margin: 0; }
    }
  </style>
</head>
<body>
<div class="page">
  ${formBlock}
  ${formBlock}
</div>
<script>window.onload = () => { window.print(); }<\/script>
</body>
</html>`;

  const blob = new Blob([html], { type:'text/html' });
  const url  = URL.createObjectURL(blob);
  const win  = window.open(url, '_blank');
  if (!win) {
    // Fallback: download langsung sebagai file
    const a = document.createElement('a');
    a.href = url; a.download = `Surat_Jalan_${sj.no.replace(/\//g,'-')}.html`;
    a.click();
  }
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
window.downloadSuratJalanPDF = downloadSuratJalanPDF;

// ── Helpers: produk & batch dari Kartu Stok ─────────────────────────────────
function _sjProducts() {
  return typeof gSCProducts === 'function' ? gSCProducts() : [];
}
function _sjTxns() {
  return typeof gSCTxn === 'function' ? gSCTxn() : [];
}

// Isi dropdown kartu stok di picker
function populateSjKartuPicker() {
  const sel = document.getElementById('sj-kartu-picker');
  if (!sel) return;
  const products = _sjProducts();
  sel.innerHTML = '<option value="">-- Pilih produk --</option>' +
    products.map(p => `<option value="${p.id}">${p.name}${p.code ? ' (' + p.code + ')' : ''}</option>`).join('');
}

// Saat produk dipilih → isi batch picker
window.onSjKartuChange = function() {
  const prodId = document.getElementById('sj-kartu-picker')?.value;
  const batchSel = document.getElementById('sj-batch-picker');
  const qtyEl = document.getElementById('sj-batch-qty');
  if (!batchSel) return;
  if (qtyEl) qtyEl.value = '';

  if (!prodId) {
    batchSel.innerHTML = '<option value="">-- Pilih batch --</option>';
    return;
  }
  const txns = _sjTxns().filter(t => t.productId === prodId && (t.seal || t.kode));
  const p    = _sjProducts().find(x => x.id === prodId);
  const unit = p?.unit || '';

  // Buat list batch unik (by seal/kode), kalkulasi kredit tiap batch
  const batchMap = {};
  txns.forEach(t => {
    const bKey = t.seal || t.kode || '';
    if (!bKey) return;
    if (!batchMap[bKey]) batchMap[bKey] = { seal: bKey, qty: 0, txnId: t.id, desc: t.desc || '' };
    batchMap[bKey].qty += parseFloat(t.credit) || 0;
  });

  const batches = Object.values(batchMap).filter(b => b.qty > 0);
  if (!batches.length) {
    batchSel.innerHTML = '<option value="">-- Tidak ada batch --</option>';
    return;
  }
  batchSel.innerHTML = '<option value="">-- Pilih batch --</option>' +
    batches.map(b => `<option value="${b.seal}" data-qty="${b.qty}" data-desc="${b.desc}">${b.seal} (${b.qty.toLocaleString('id-ID')} ${unit})</option>`).join('');
};

// Saat batch dipilih → isi qty
window.onSjBatchChange = function() {
  const opt = document.getElementById('sj-batch-picker')?.selectedOptions[0];
  const qtyEl = document.getElementById('sj-batch-qty');
  if (!qtyEl) return;
  qtyEl.value = opt && opt.value ? (opt.getAttribute('data-qty') || '') : '';
};

// Tambah item dari kartu stok picker
window.addSjItemFromKartu = function() {
  const prodId  = document.getElementById('sj-kartu-picker')?.value;
  const batchSel = document.getElementById('sj-batch-picker');
  const batch   = batchSel?.value;
  const qty     = document.getElementById('sj-batch-qty')?.value;

  if (!prodId) { alert('Pilih kartu stok terlebih dahulu.'); return; }

  const p = _sjProducts().find(x => x.id === prodId);
  const opt = batchSel?.selectedOptions[0];
  const desc = opt?.getAttribute('data-desc') || '';

  addSuratJalanItem({
    productId: prodId,
    name: p?.name || '',
    seal: batch || '',
    qty:  qty   || '',
    desc: desc,
    fromKartu: true,
  });

  // Reset picker
  document.getElementById('sj-batch-picker').innerHTML = '<option value="">-- Pilih batch --</option>';
  document.getElementById('sj-batch-qty').value = '';
  document.getElementById('sj-kartu-picker').value = '';
};

// ── Item row ─────────────────────────────────────────────────────────────────
function addSuratJalanItem(data = null) {
  const uid = ++_sjItemCount;
  const container = document.getElementById('sj-items');
  if (!container) return;
  const row = document.createElement('div');
  row.id = 'sj-item-' + uid;
  row.style.cssText = 'display:grid;grid-template-columns:1.6fr 1.6fr 70px 1.4fr 30px;gap:4px;align-items:center;padding:5px 10px;background:var(--bg);border:1px solid var(--border);border-top:none;';

  const prodId    = data?.productId || '';
  const prodName  = data?.name || '';
  const sealVal   = data?.seal || '';
  const qtyVal    = data?.qty  || '';
  const descVal   = data?.desc || '';
  const fromKartu = data?.fromKartu || false;
  const kartuBadge = fromKartu
    ? `<span style="font-size:8px;background:#dcfce7;color:#15803d;border:1px solid #86efac;border-radius:4px;padding:0 4px;font-weight:700">⚡KS</span>`
    : '';

  row.innerHTML = `
    <input type="hidden" id="sj-i-prodId-${uid}" value="${prodId}">
    <input type="hidden" id="sj-i-fromKartu-${uid}" value="${fromKartu?'1':'0'}">
    <div style="display:flex;align-items:center;gap:4px">
      ${kartuBadge}
      <input class="de-input" id="sj-i-name-${uid}" value="${prodName}" placeholder="Nama produk / barang..." style="margin:0;font-size:11px;flex:1;${fromKartu?'background:#f0fdf4;color:#15803d;font-weight:600':''}" ${fromKartu?'readonly':''}>
    </div>
    <input class="de-input" id="sj-i-seal-${uid}" value="${sealVal}" placeholder="No. batch / seal / manual..." style="margin:0;font-size:11px;${fromKartu?'font-weight:600':''}" ${fromKartu?'readonly':''}>
    <input class="de-input" id="sj-i-qty-${uid}" type="number" step="any" value="${qtyVal}" placeholder="0" min="0" style="margin:0;text-align:center;font-size:11px;color:var(--blue);font-weight:700">
    <input class="de-input" id="sj-i-desc-${uid}" value="${descVal}" placeholder="Keterangan..." style="margin:0;font-size:11px">
    <button class="fp-item-remove" onclick="document.getElementById('sj-item-${uid}').remove();" title="Hapus" style="margin:0;display:flex;align-items:center;justify-content:center;height:100%;width:100%">✕</button>`;

  container.appendChild(row);
}

// ── Submit: simpan SJ + auto-debit kartu stok ─────────────────────────────────
function submitSuratJalan() {
  const penerima = document.getElementById('sj-f-penerima')?.value.trim();
  if (!penerima) { showSjSt('error', '❌ Tujuan wajib diisi!'); return; }

  const sjDate = document.getElementById('sj-f-date')?.value || new Date().toISOString().split('T')[0];
  const sjNo   = document.getElementById('sj-f-no')?.value.trim() || genSJNo();

  const items = [];
  document.querySelectorAll('#sj-items > div[id^="sj-item-"]').forEach(row => {
    const uid = row.id.replace('sj-item-', '');
    items.push({
      productId:  document.getElementById('sj-i-prodId-' + uid)?.value || '',
      fromKartu:  document.getElementById('sj-i-fromKartu-' + uid)?.value === '1',
      name:       document.getElementById('sj-i-name-' + uid)?.value.trim()  || '',
      seal:       document.getElementById('sj-i-seal-' + uid)?.value.trim()  || '',
      qty:        document.getElementById('sj-i-qty-' + uid)?.value  || '',
      desc:       document.getElementById('sj-i-desc-' + uid)?.value.trim()  || '',
    });
  });

  const entry = {
    id:         _sjEditIdx >= 0 ? gSJ()[_sjEditIdx].id : Date.now(),
    no:         sjNo,
    date:       sjDate,
    penerima,
    kendaraan:  document.getElementById('sj-f-kendaraan')?.value.trim() || '',
    driver:     document.getElementById('sj-f-driver')?.value.trim()    || '',
    pengirim:   document.getElementById('sj-f-pengirim')?.value.trim()  || '',
    notes:      document.getElementById('sj-f-notes')?.value.trim()     || '',
    items,
    created_at: new Date().toISOString(),
  };

  // ── Auto-debit kartu stok untuk item dari Kartu Stok ──────────────────────
  if (typeof gSCTxn === 'function' && typeof sSCTxn === 'function') {
    const txns = gSCTxn();

    // Hapus auto-debit lama jika ini edit
    if (_sjEditIdx >= 0) {
      const oldSJ = gSJ()[_sjEditIdx];
      const oldAutoIds = oldSJ._autoDebitIds || [];
      const filtered = txns.filter(t => !oldAutoIds.includes(t.id));
      txns.length = 0; filtered.forEach(t => txns.push(t));
    }

    const autoDebitIds = [];
    items.forEach(it => {
      if (!it.fromKartu || !it.productId || !it.qty) return;
      const tid = 'sj-auto-' + Date.now() + '-' + Math.random().toString(36).slice(2,6);
      txns.push({
        id:        tid,
        productId: it.productId,
        date:      sjDate,
        debit:     it.qty,   // barang keluar
        credit:    '',
        kode:      it.seal || '',
        seal:      it.seal || '',
        pic:       entry.pengirim || '',
        desc:      'Auto: Surat Jalan ' + sjNo + (it.desc ? ' – ' + it.desc : ''),
        notes:     'Tujuan: ' + penerima,
        _autoSJ:   entry.id,
      });
      autoDebitIds.push(tid);
    });

    entry._autoDebitIds = autoDebitIds;
    sSCTxn(txns);
  }

  const data = gSJ();
  if (_sjEditIdx >= 0) data[_sjEditIdx] = entry; else data.unshift(entry);
  sSJ(data);
  showSjSt('success','✅ Surat jalan tersimpan' + (entry._autoDebitIds?.length ? ` + ${entry._autoDebitIds.length} auto-debit kartu stok` : '') + '!');
  setTimeout(() => { closeSuratJalanForm(); renderSuratJalan(); }, 900);
}

// ── Helpers lama (dipertahankan untuk kompatibilitas) ─────────────────────────
function getAvailableStockOptions(selectedKode = '') {
  const products = _sjProducts();
  const txns     = _sjTxns();
  let html = '<option value="" data-nama="" data-sisa="" data-masuk="">-- Pilih --</option>';
  products.forEach(p => {
    let totalMasuk = 0, balance = 0;
    txns.filter(t => t.productId === p.id).forEach(t => {
      const m = parseFloat(t.credit) || 0, k = parseFloat(t.debit) || 0;
      balance += m - k; totalMasuk += m;
    });
    const itemCode = p.code || p.id;
    const isSelected = itemCode === selectedKode ? 'selected' : '';
    const masukText = totalMasuk.toLocaleString('id-ID', {maximumFractionDigits:2});
    html += `<option value="${itemCode}" data-nama="${p.name}" data-sisa="${balance}" data-masuk="${totalMasuk}" ${isSelected}>${itemCode} (${masukText} ${p.unit||''})</option>`;
  });
  return html;
}

window.updateSjDropdownState = function() {};  // no-op, kept for compat

window.editSuratJalan   = editSuratJalan;
window.deleteSuratJalan = deleteSuratJalan;
window.addSuratJalanItem = addSuratJalanItem;
window.checkVacuum = checkVacuum;
window.handlePhotoUpload = handlePhotoUpload;
window.switchReportTab = switchReportTab;
window.changeReportSort = changeReportSort;
window.clearDateFilters = clearDateFilters;