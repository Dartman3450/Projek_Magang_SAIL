function swTab(tab, el) {
  _activeTab = tab;
  document.querySelectorAll('.iot-tab').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  loadTable(tab);
}

async function loadTable(tab) {
  const c=$('tbl-cont'); if(!c) return;
  if(!espConnected){c.innerHTML='<div class="tbl-empty">Waiting for ESP…</div>';return;}
  c.innerHTML='<div class="tbl-empty" style="color:var(--txt3)">Memuat data…</div>';
  try {
    const j = await (await fetch(tabApi[tab])).json();
    if(!j.success||!j.data.length){c.innerHTML='<div class="tbl-empty">Belum ada data tersedia</div>';return;}
    const rows=j.data, keys=Object.keys(rows[0]);
    let h=`<table><thead><tr>${keys.map(k=>`<th>${k.replace(/_/g,' ')}</th>`).join('')}</tr></thead><tbody>`;
    rows.forEach(r=>{
      h+=`<tr>${keys.map(k=>{
        const v=r[k];
        if(k==='id') return `<td><span class="td-id">#${v}</span></td>`;
        if(k.includes('_at')) return `<td style="color:var(--txt3);font-size:11px">${fmtDT(v)}</td>`;
        return `<td>${v??'—'}</td>`;
      }).join('')}</tr>`;
    });
    c.innerHTML=h+'</tbody></table>';
  } catch(e){
    c.innerHTML=`<div class="tbl-empty">Gagal memuat data</div>`;
  }
}

// ══ LOGOUT ══════════════════════════════════════════
function confirmLogout() {
  // Show our styled modal instead of the ugly browser confirm()
  const overlay = document.getElementById('logout-overlay');
  const modal   = document.getElementById('logout-modal');
  overlay.style.display = 'flex';
  modal.style.display   = 'block';
}
function closeLogout() {
  // Hide the modal when user clicks Cancel or the dark overlay
  document.getElementById('logout-overlay').style.display = 'none';
  document.getElementById('logout-modal').style.display   = 'none';
}
function doLogout() {
  localStorage.removeItem('isLoggedin');
  localStorage.removeItem('user_id');
  localStorage.removeItem('email');
  localStorage.removeItem('role');
  window.location.href = '../Dashboard/Logout_Success.html';
}

// ── Hide nav items the current role cannot access ──
function filterNav() {
  const role  = localStorage.getItem('role') || 'admin';
  const allow = ROLE_ACCESS[role]; // null = admin, sees everything
  if (!allow) return;              // admin — nothing to hide

  // Hide individual nav items (sub-items and top-level items)
  document.querySelectorAll('[data-page]').forEach(el => {
    const page = el.getAttribute('data-page');
    if (!allow.includes(page)) {
      el.style.display = 'none';
    }
  });

  // If ALL sub-items in a nav-group are hidden, hide the whole group + its section label
  document.querySelectorAll('.nav-group').forEach(group => {
    const visibleItems = group.querySelectorAll('.nav-sub-item:not([style*="display: none"])');
    if (visibleItems.length === 0) {
      group.style.display = 'none';
      // Also hide the section label before this group
      const prev = group.previousElementSibling;
      if (prev && prev.classList.contains('nav-section-label')) {
        prev.style.display = 'none';
      }
    }
  });
}

// ═══════════════════════════════════════════════════════════
// 3 NEW DASHBOARD WIDGETS
// ═══════════════════════════════════════════════════════════
function updateDashWidgets() {
  /* gauges are empty/untitled — reserved for future use */
}
function updateHealthWidget() {
  // reserved
}

// Refresh widgets every 30s
setInterval(updateDashWidgets, 30000);

// ═══════════════════════════════════════════════════════════
// WATER LEVEL ALERT SYSTEM
// ═══════════════════════════════════════════════════════════
let _wlAlertState = { warn: false, danger: false };
let _wlDangerInterval = null;

function _playDangerSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const play = (freq, start, dur) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = 'square';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.15, ctx.currentTime + start);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + dur);
      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + dur + 0.05);
    };
    play(880, 0, 0.18); play(660, 0.22, 0.18);
    play(880, 0.44, 0.18); play(660, 0.66, 0.18);
  } catch(e) {}
}

function _stopDangerSound() {
  if (_wlDangerInterval) { clearInterval(_wlDangerInterval); _wlDangerInterval = null; }
}

function checkWLAlerts(avgPct) {
  const sensors = getSensors();
  // Ambil last WL data dari cache jika ada
  const cached = window._lastWLData;
  if (cached && sensors.length) {
    sensors.forEach((s, i) => {
      let rawCm = cached[s.key + '_cm'] ?? cached[s.key] ?? cached['s'+(i+1)+'_cm'] ?? cached['s'+(i+1)] ?? null;
      if (rawCm === null) return;
      rawCm = Math.max(0, parseFloat(rawCm));
      const pct     = cmToPct(s, rawCm);
      const warnAt  = +(s.warnPct ?? 40);
      const critAt  = +(s.critPct ?? 15);
      const stateKey = 'w_' + s.id;
      const critKey  = 'c_' + s.id;
      const isDanger = pct <= critAt;
      const isWarn   = pct <= warnAt && pct > critAt;
      if (isDanger && !_wlAlertState[critKey]) {
        _wlAlertState[critKey] = true;
        _wlAlertState[stateKey] = true;
        showWLDangerAlert(pct, s.name);
      } else if (isWarn && !_wlAlertState[stateKey]) {
        _wlAlertState[stateKey] = true;
        showWLWarnAlert(pct, s.name);
      }
      if (pct > warnAt) { _wlAlertState[stateKey] = false; _wlAlertState[critKey] = false; }
      if (pct > critAt) { _wlAlertState[critKey] = false; }
    });
  } else {
    // fallback rata-rata
    const cfg    = JSON.parse(localStorage.getItem('wls_settings') || '{}');
    const warnAt = cfg.warn ?? 40;
    const critAt = cfg.crit ?? 15;
    const isWarn   = avgPct <= warnAt && avgPct > critAt;
    const isDanger = avgPct <= critAt;
    if (isDanger && !_wlAlertState.danger) {
      _wlAlertState.danger = true; _wlAlertState.warn = true;
      showWLDangerAlert(avgPct);
    } else if (isWarn && !_wlAlertState.warn) {
      _wlAlertState.warn = true;
      showWLWarnAlert(avgPct);
    }
    if (avgPct > warnAt) { _wlAlertState.warn = false; _wlAlertState.danger = false; }
    if (avgPct > critAt) { _wlAlertState.danger = false; }
  }
}

function showWLWarnAlert(pct, sensorName) {
  const el = document.getElementById('wl-warn-pct');
  const ov = document.getElementById('wl-warn-overlay');
  if (el) el.textContent = (sensorName ? sensorName + ' — ' : '') + Math.round(pct) + '% — Batas Warning';
  if (ov) ov.classList.add('show');
}

function showWLDangerAlert(pct, sensorName) {
  const el  = document.getElementById('wl-danger-pct');
  const ov  = document.getElementById('wl-danger-overlay');
  const box = document.getElementById('wl-danger-box');
  if (el) el.textContent = (sensorName ? sensorName + ' — ' : '') + Math.round(pct) + '% — BAHAYA!';
  if (ov) ov.classList.add('show');
  if (box) { box.classList.add('wl-danger-pulse'); setTimeout(()=>box.classList.remove('wl-danger-pulse'),400); }
  _playDangerSound();
  _stopDangerSound();
  _wlDangerInterval = setInterval(() => {
    const overlay = document.getElementById('wl-danger-overlay');
    if (overlay && overlay.classList.contains('show')) _playDangerSound();
    else _stopDangerSound();
  }, 3000);
}

function dismissWLAlert(type) {
  const ov = document.getElementById('wl-' + type + '-overlay');
  if (ov) ov.classList.remove('show');
  if (type === 'danger') _stopDangerSound();
}
window.dismissWLAlert = dismissWLAlert;

// Hook into applyWL to trigger alerts
const _origApplyWL = applyWL;
applyWL = function(wl) {
  _origApplyWL(wl);
  if (!wl) return;
  const sensors = getSensors();
  let sum = 0;
  sensors.forEach((s, i) => {
    let rawCm = wl[s.key + '_cm'] ?? wl[s.key] ?? wl['s'+(i+1)+'_cm'] ?? wl['s'+(i+1)] ?? 0;
    rawCm = Math.max(0, parseFloat(rawCm));
    sum += cmToPct(s, rawCm);
  });
  const avg = sensors.length ? sum / sensors.length : 0;
  checkWLAlerts(avg);
};

// ═══════════════════════════════════════════════════════════
// SIDEBAR TOGGLE
// ═══════════════════════════════════════════════════════════
let _sidebarOpen = true;
let _sidebarHoverTimer = null;

function toggleSidebar() {
  _sidebarOpen = !_sidebarOpen;
  _applySidebar();
}

function openSidebar() {
  if (_sidebarOpen) return;
  _sidebarOpen = true;
  _applySidebar();
}

function _applySidebar() {
  const sidebar = document.getElementById('sidebar');
  const btn     = document.getElementById('sidebar-toggle-btn');
  if (!sidebar || !btn) return;

  if (_sidebarOpen) {
    sidebar.classList.remove('collapsed');
    document.body.classList.remove('sidebar-collapsed');
    btn.textContent = '◀';
    btn.title = 'Tutup sidebar';
  } else {
    sidebar.classList.add('collapsed');
    document.body.classList.add('sidebar-collapsed');
    btn.textContent = '▶';
    btn.title = 'Buka sidebar';
  }
}

// When sidebar is open, hovering off the left edge keeps it open — nothing special needed.
// When collapsed, mouseleave on the ghost zone after a short delay closes it again.
document.addEventListener('DOMContentLoaded', () => {
  const ghost = document.getElementById('sidebar-ghost');
  if (!ghost) return;
  ghost.addEventListener('mouseleave', () => {
    // user moved mouse away from ghost zone — if sidebar re-opened via hover, close again
    _sidebarHoverTimer = setTimeout(() => {
      if (_sidebarOpen && document.body.classList.contains('sidebar-collapsed')) {
        // shouldn't happen, but guard
      }
    }, 300);
  });
});

// Also close sidebar when clicking the ghost zone (alternative open)
// Already handled via onmouseenter="openSidebar()" in HTML

// ══ BOOT ════════════════════════════════════════════
filterNav();
loadPage('iot');
// Trigger new widgets after short delay (DOM ready)
setTimeout(updateDashWidgets, 500);

// ═══════════════════════════════════════════════════════════
// DATA ENTRY
// ═══════════════════════════════════════════════════════════
