function _isEspAlive(key) {
  const t = _espLastSeen[key];
  if (!t) return false;
  return (Date.now() - new Date(t).getTime()) < ESP_TIMEOUT_MS;
}

function updateEspBadge() {
  const wrap = document.getElementById('esp-badge');
  if (!wrap) return;

  // Check MQTT status
  const isMqttOffline = typeof mqttConnected !== 'undefined' && !mqttConnected;
  if (isMqttOffline) {
    wrap.className = 'esp-badge offline';
    wrap.innerHTML = `
      <div class="esp-dot"></div>
      <span id="esp-label">MQTT OFFLINE</span>
      <span style="font-size:9px;margin-left:3px;color:inherit;opacity:.7">▾</span>
    `;
    wrap.onclick = toggleEspPopup;
    wrap.style.cursor = 'pointer';
    wrap.style.userSelect = 'none';
    return;
  }

  const states = _ESP_DEFS.map(e => ({ ...e, alive: _isEspAlive(e.key) }));
  const connCount = states.filter(e => e.alive).length;
  const total     = states.length;

  // Warna badge keseluruhan
  let badgeClass = 'esp-badge';
  if (connCount === total)      badgeClass += ' connected';
  else if (connCount === 0)     badgeClass += ' waiting';
  else                          badgeClass += ' partial';

  const summaryText = 'ESP Status';

  wrap.className = badgeClass;
  wrap.onclick   = toggleEspPopup;
  wrap.style.cursor = 'pointer';
  wrap.style.userSelect = 'none';

  wrap.innerHTML = `
    <div class="esp-dot"></div>
    <span id="esp-label">${summaryText}</span>
    <span style="font-size:9px;margin-left:3px;color:inherit;opacity:.7">▾</span>
  `;
}

function toggleEspPopup() {
  let popup = document.getElementById('esp-popup');
  if (popup) { popup.remove(); return; }

  // Refresh MQTT status sebelum render popup
  if (typeof checkMQTTStatus === 'function') {
    checkMQTTStatus();
  }

  const wrap  = document.getElementById('esp-badge');
  const rect  = wrap.getBoundingClientRect();
  const states = _ESP_DEFS.map(e => ({ ...e, alive: _isEspAlive(e.key) }));

  popup = document.createElement('div');
  popup.id = 'esp-popup';
  popup.style.cssText = `
    position:fixed;
    top:${rect.bottom + 8}px;
    right:${window.innerWidth - rect.right}px;
    background:#fff;
    border:1px solid #e2e8f0;
    border-radius:12px;
    box-shadow:0 8px 24px rgba(0,0,0,.12);
    padding:10px 4px;
    z-index:9999;
    min-width:240px;max-height:80vh;overflow-y:auto;
    font-family:inherit;
  `;

  // Kumpulkan status tangki aktif dari sensors.js
  const tankRows = (() => {
    if (typeof getSensors !== 'function') return '';
    const sensors = getSensors().filter(s => s.active !== false);
    if (!sensors.length) return '';

    const tankItems = sensors.map(s => {
      // Cek apakah sensor punya data terbaru (ada di DOM)
      const pctEl = document.getElementById('tank-pct-' + s.id);
      const offEl = document.getElementById('tank-offline-' + s.id);
      const hasOfflineBadge = offEl && offEl.style.display !== 'none';
      const pctTxt = pctEl ? pctEl.textContent.replace(/<[^>]+>/g,'').trim() : '—%';
      // Tank offline jika: tidak ada data (—%) ATAU offline badge terlihat ATAU MQTT disconnected
      const isOffline = pctTxt === '—%' || hasOfflineBadge || (typeof mqttConnected !== 'undefined' && !mqttConnected);
      const dotClr = isOffline ? '#f59e0b' : '#22c55e';
      const shadow = isOffline ? 'none' : '0 0 5px rgba(34,197,94,.5)';
      const statusTxt = isOffline ? 'Offline' : 'Online';
      const statusClr = isOffline ? '#b45309' : '#16a34a';
      return `
        <div style="display:flex;align-items:center;gap:8px;padding:5px 14px;border-radius:6px;transition:.15s"
          onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='transparent'">
          <div style="width:7px;height:7px;border-radius:50%;background:${dotClr};box-shadow:${shadow};flex-shrink:0"></div>
          <div style="flex:1;min-width:0">
            <div style="font-size:11px;font-weight:600;color:#1e293b">${s.name}</div>
            <div style="font-size:9px;color:#94a3b8">Key: ${s.key} · ${pctTxt}</div>
          </div>
          <div style="font-size:10px;font-weight:700;color:${statusClr}">${statusTxt}</div>
        </div>`;
    }).join('');

    return `
      <div style="border-top:1px solid #f1f5f9;margin:4px 0 2px"></div>
      <div style="padding:6px 14px 4px;font-size:10px;font-weight:700;color:#94a3b8;letter-spacing:1px;text-transform:uppercase">
        Water Level Tanks
      </div>
      ${tankItems}`;
  })();

  popup.innerHTML = `
    <div style="padding:4px 14px 8px;font-size:10px;font-weight:700;color:#94a3b8;letter-spacing:1px;text-transform:uppercase;">
      ESP Status
    </div>
    ${states.map(e => {
      const alive   = e.alive;
      const dotClr  = alive ? '#22c55e' : '#f59e0b';
      const dotShadow = alive ? '0 0 6px rgba(34,197,94,.6)' : 'none';
      const lastTs  = _espLastSeen[e.key];
      const lastStr = lastTs
        ? new Date(lastTs).toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit', second:'2-digit' })
        : '—';
      const statusTxt = alive ? 'Connected' : (lastTs ? 'Waiting / Off' : 'No Data');
      const statusClr = alive ? '#16a34a' : '#b45309';
      return `
        <div style="display:flex;align-items:center;gap:10px;padding:7px 14px;border-radius:8px;transition:.15s;"
          onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='transparent'">
          <div style="width:9px;height:9px;border-radius:50%;background:${dotClr};box-shadow:${dotShadow};flex-shrink:0;"></div>
          <div style="flex:1;min-width:0;">
            <div style="font-size:12px;font-weight:600;color:#1e293b;">${e.label}</div>
            <div style="font-size:10px;color:#94a3b8;">Last: ${lastStr}</div>
          </div>
          <div style="font-size:11px;font-weight:700;color:${statusClr};">${statusTxt}</div>
        </div>`;
    }).join('')}
    ${tankRows}
  `;

  document.body.appendChild(popup);

  // Tutup kalau klik di luar
  setTimeout(() => {
    document.addEventListener('click', function _close(ev) {
      if (!popup.contains(ev.target) && ev.target.id !== 'esp-badge' && !document.getElementById('esp-badge')?.contains(ev.target)) {
        popup.remove();
        document.removeEventListener('click', _close);
      }
    });
  }, 50);
}
window.toggleEspPopup = toggleEspPopup;

// Legacy — masih dipanggil kalau ada kode lain
function setEspStatus(state) {
  updateEspBadge();
}

// ══ IOT RENDER ═════════════════════════════════════
function renderIoT(content) {
  content.innerHTML = getIoTHTML();
  initWidgets();
  renderTankCards();
  fetchSummary();
  setTimeout(updateDashWidgets, 200);
  
  // Start MQTT status polling
  if (typeof startMQTTStatusPolling === 'function') {
    startMQTTStatusPolling();
  }
  
  // Clear any existing poll before setting new one
  if (window._poll) { clearInterval(window._poll); window._poll = null; }
  // Robust polling: setiap 5 detik, selalu fetch ulang
  window._poll = setInterval(() => {
    // Check if IoT page is still active (wl-tanks-container ada di DOM)
    if (!document.getElementById('wl-tanks-container')) {
      clearInterval(window._poll);
      window._poll = null;
      return;
    }
    fetchSummary();
  }, 5000);
}

function getIoTHTML() {
  const ov = `
    <div class="esp-waiting-overlay show" id="ov-ID">
      <div class="esp-wait-icon">🔌</div>
      <div class="esp-wait-txt">Waiting for ESP<span class="dots"></span></div>
      <div class="esp-wait-sub">Belum ada data masuk</div>
    </div>`;

  return `
  <div class="sensor-grid">

  <!-- ══ TREAT WATER 2 — full width ══ -->
  <div class="s-card" style="--acc:#8b5cf6;grid-column:1/-1">
    <div class="s-bar"></div>
    <div class="s-label" style="font-size:11px;letter-spacing:1.5px;font-weight:700;color:#8b5cf6">TREAT WATER 2</div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-top:12px;align-items:stretch">

      <!-- TANU EDI -->
      <div style="background:#f5f3ff;border:1px solid #ddd6fe;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#7c3aed">TANU EDI</div>
        <div style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #c4b5fd;border-radius:10px;overflow:hidden;background:#ede9fe">
          <div style="position:absolute;bottom:0;left:0;right:0;height:72%;background:linear-gradient(180deg,#a78bfa,#7c3aed);border-radius:0 0 8px 8px"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4)">72%</span>
          </div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#c4b5fd;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#c4b5fd;border-radius:0 0 4px 4px"></div>
        </div>
        <div style="font-size:9px;color:#5b21b6;font-weight:600;text-align:center">7.200lt / 10.000lt</div>
        <div style="width:100%;background:#ddd6fe;border-radius:99px;height:5px">
          <div style="width:72%;background:#8b5cf6;border-radius:99px;height:5px"></div>
        </div>
      </div>

      <!-- FEED EDI -->
      <div style="background:#eef2ff;border:1px solid #c7d2fe;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#4f46e5">FEED EDI</div>
        <div style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #a5b4fc;border-radius:10px;overflow:hidden;background:#e0e7ff">
          <div style="position:absolute;bottom:0;left:0;right:0;height:58%;background:linear-gradient(180deg,#818cf8,#4f46e5);border-radius:0 0 8px 8px"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4)">58%</span>
          </div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#a5b4fc;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#a5b4fc;border-radius:0 0 4px 4px"></div>
        </div>
        <div style="font-size:9px;color:#3730a3;font-weight:600;text-align:center">5.800lt / 10.000lt</div>
        <div style="width:100%;background:#c7d2fe;border-radius:99px;height:5px">
          <div style="width:58%;background:#6366f1;border-radius:99px;height:5px"></div>
        </div>
      </div>

      <!-- GRID 2x2: TDS + Hardness + PH + Alkaline -->
      <div style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;gap:8px">
        <div style="background:#f5f3ff;border:1px solid #ddd6fe;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#7c3aed">TDS</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#5b21b6;font-family:'Cascadia Code','Consolas',monospace">48</span>
            <span style="font-size:9px;color:#c4b5fd;font-weight:600">ppm</span>
          </div>
          <div style="margin-top:8px;background:#ddd6fe;border-radius:99px;height:3px">
            <div style="width:16%;background:#8b5cf6;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#eef2ff;border:1px solid #c7d2fe;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#4f46e5">HARDNESS</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#3730a3;font-family:'Cascadia Code','Consolas',monospace">18</span>
            <span style="font-size:9px;color:#a5b4fc;font-weight:600">mg/L</span>
          </div>
          <div style="margin-top:8px;background:#c7d2fe;border-radius:99px;height:3px">
            <div style="width:18%;background:#6366f1;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#fefce8;border:1px solid #fde68a;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#ca8a04">PH</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#a16207;font-family:'Cascadia Code','Consolas',monospace">7.0</span>
          </div>
          <div style="margin-top:8px;background:#fef9c3;border-radius:99px;height:3px">
            <div style="width:50%;background:#eab308;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#059669">ALKALINE</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#065f46;font-family:'Cascadia Code','Consolas',monospace">95</span>
            <span style="font-size:9px;color:#6ee7b7;font-weight:600">mg/L</span>
          </div>
          <div style="margin-top:8px;background:#a7f3d0;border-radius:99px;height:3px">
            <div style="width:48%;background:#10b981;border-radius:99px;height:3px"></div>
          </div>
        </div>
      </div>

    </div>
    <div style="margin-top:12px;display:flex;align-items:center;gap:6px">
      <div style="width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px rgba(34,197,94,.6)"></div>
      <span style="font-size:10px;font-weight:600;color:#16a34a">Normal</span>
      <span style="margin-left:auto;font-size:10px;color:#94a3b8">Data statis</span>
    </div>
  </div>

  <!-- ══ TREAT WATER 1 — full width ══ -->
  <div class="s-card" style="--acc:#6366f1;grid-column:1/-1">
    <div class="s-bar"></div>
    <div class="s-label" style="font-size:11px;letter-spacing:1.5px;font-weight:700;color:#6366f1">TREAT WATER 1</div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:14px;margin-top:12px;align-items:stretch">

      <!-- SLURY 1 -->
      <div style="background:#eef2ff;border:1px solid #c7d2fe;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#4f46e5">SLURY 1</div>
        <div style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #a5b4fc;border-radius:10px;overflow:hidden;background:#e0e7ff">
          <div style="position:absolute;bottom:0;left:0;right:0;height:60%;background:linear-gradient(180deg,#818cf8,#4f46e5);border-radius:0 0 8px 8px"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4)">60%</span>
          </div>
        </div>
        <div style="display:flex;gap:24px">
          <div style="width:6px;height:14px;background:#a5b4fc;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#a5b4fc;border-radius:0 0 4px 4px"></div>
        </div>
        <div style="font-size:9px;color:#3730a3;font-weight:600;text-align:center">6.000lt / 10.000lt</div>
        <div style="width:100%;background:#c7d2fe;border-radius:99px;height:5px">
          <div style="width:60%;background:#6366f1;border-radius:99px;height:5px"></div>
        </div>
      </div>

      <!-- SLURY 2 -->
      <div style="background:#f5f3ff;border:1px solid #ddd6fe;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#7c3aed">SLURY 2</div>
        <div style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #c4b5fd;border-radius:10px;overflow:hidden;background:#ede9fe">
          <div style="position:absolute;bottom:0;left:0;right:0;height:55%;background:linear-gradient(180deg,#a78bfa,#7c3aed);border-radius:0 0 8px 8px"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4)">55%</span>
          </div>
        </div>
        <div style="display:flex;gap:24px">
          <div style="width:6px;height:14px;background:#c4b5fd;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#c4b5fd;border-radius:0 0 4px 4px"></div>
        </div>
        <div style="font-size:9px;color:#5b21b6;font-weight:600;text-align:center">5.500lt / 10.000lt</div>
        <div style="width:100%;background:#ddd6fe;border-radius:99px;height:5px">
          <div style="width:55%;background:#8b5cf6;border-radius:99px;height:5px"></div>
        </div>
      </div>

      <!-- FEED SLURY -->
      <div style="background:#fdf4ff;border:1px solid #f0abfc;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#a21caf">FEED SLURY</div>
        <div style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #f0abfc;border-radius:10px;overflow:hidden;background:#fae8ff">
          <div style="position:absolute;bottom:0;left:0;right:0;height:70%;background:linear-gradient(180deg,#e879f9,#a21caf);border-radius:0 0 8px 8px"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4)">70%</span>
          </div>
        </div>
        <div style="display:flex;gap:24px">
          <div style="width:6px;height:14px;background:#f0abfc;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#f0abfc;border-radius:0 0 4px 4px"></div>
        </div>
        <div style="font-size:9px;color:#86198f;font-weight:600;text-align:center">7.000lt / 10.000lt</div>
        <div style="width:100%;background:#f0abfc;border-radius:99px;height:5px">
          <div style="width:70%;background:#d946ef;border-radius:99px;height:5px"></div>
        </div>
      </div>

      <!-- GRID 2x2: TDS + Hardness + PH + Alkaline -->
      <div style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;gap:8px">
        <div style="background:#eef2ff;border:1px solid #c7d2fe;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#4f46e5">TDS</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#3730a3;font-family:'Cascadia Code','Consolas',monospace">85</span>
            <span style="font-size:9px;color:#a5b4fc;font-weight:600">ppm</span>
          </div>
          <div style="margin-top:8px;background:#c7d2fe;border-radius:99px;height:3px">
            <div style="width:28%;background:#6366f1;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#f5f3ff;border:1px solid #ddd6fe;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#7c3aed">HARDNESS</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#5b21b6;font-family:'Cascadia Code','Consolas',monospace">42</span>
            <span style="font-size:9px;color:#c4b5fd;font-weight:600">mg/L</span>
          </div>
          <div style="margin-top:8px;background:#ddd6fe;border-radius:99px;height:3px">
            <div style="width:42%;background:#8b5cf6;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#fefce8;border:1px solid #fde68a;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#ca8a04">PH</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#a16207;font-family:'Cascadia Code','Consolas',monospace">7.4</span>
          </div>
          <div style="margin-top:8px;background:#fef9c3;border-radius:99px;height:3px">
            <div style="width:53%;background:#eab308;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#059669">ALKALINE</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#065f46;font-family:'Cascadia Code','Consolas',monospace">120</span>
            <span style="font-size:9px;color:#6ee7b7;font-weight:600">mg/L</span>
          </div>
          <div style="margin-top:8px;background:#a7f3d0;border-radius:99px;height:3px">
            <div style="width:60%;background:#10b981;border-radius:99px;height:3px"></div>
          </div>
        </div>
      </div>

    </div>
    <div style="margin-top:12px;display:flex;align-items:center;gap:6px">
      <div style="width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px rgba(34,197,94,.6)"></div>
      <span style="font-size:10px;font-weight:600;color:#16a34a">Normal</span>
      <span style="margin-left:auto;font-size:10px;color:#94a3b8">Data statis</span>
    </div>
  </div>

  <!-- ══ FILTER WATER — full width ══ -->
  <div class="s-card" style="--acc:#0ea5e9;grid-column:1/-1">
    <div class="s-bar"></div>
    <div class="s-label" style="font-size:11px;letter-spacing:1.5px;font-weight:700;color:#0ea5e9">FILTER WATER</div>
    <div style="display:grid;grid-template-columns:1fr auto 1fr 1fr;gap:14px;margin-top:12px;align-items:stretch">

      <!-- AIR PROSES -->
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#16a34a">AIR PROSES</div>
        <div style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #86efac;border-radius:10px;overflow:hidden;background:#dcfce7">
          <div style="position:absolute;bottom:0;left:0;right:0;height:75%;background:linear-gradient(180deg,#4ade80,#16a34a);border-radius:0 0 8px 8px"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4)">75%</span>
          </div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
        </div>
        <div style="font-size:9px;color:#15803d;font-weight:600;text-align:center">7.500lt / 10.000lt</div>
        <div style="width:100%;background:#bbf7d0;border-radius:99px;height:5px">
          <div style="width:75%;background:#22c55e;border-radius:99px;height:5px"></div>
        </div>
      </div>

      <!-- FLOW vertikal -->
      <div style="display:flex;align-items:center;justify-content:center">
        <div style="writing-mode:vertical-rl;text-orientation:mixed;font-size:8px;font-weight:800;letter-spacing:2px;color:#0369a1;background:#e0f2fe;border:1px solid #7dd3fc;border-radius:6px;padding:10px 6px;transform:rotate(180deg)">FLOW</div>
      </div>

      <!-- GROUND TANK A -->
      <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#0284c7">GROUND TANK A</div>
        <div style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #7dd3fc;border-radius:10px;overflow:hidden;background:#e0f2fe">
          <div style="position:absolute;bottom:0;left:0;right:0;height:65%;background:linear-gradient(180deg,#38bdf8,#0284c7);border-radius:0 0 8px 8px"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4)">65%</span>
          </div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#7dd3fc;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#7dd3fc;border-radius:0 0 4px 4px"></div>
        </div>
        <div style="font-size:9px;color:#0369a1;font-weight:600;text-align:center">6.500lt / 10.000lt</div>
        <div style="width:100%;background:#bae6fd;border-radius:99px;height:5px">
          <div style="width:65%;background:#0ea5e9;border-radius:99px;height:5px"></div>
        </div>
      </div>

      <!-- GRID 2x2: TDS + Hardness + PH + Alkaline -->
      <div style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;gap:8px">
        <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#0284c7">TDS</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#0369a1;font-family:'Cascadia Code','Consolas',monospace">72</span>
            <span style="font-size:9px;color:#7dd3fc;font-weight:600">ppm</span>
          </div>
          <div style="margin-top:8px;background:#e0f2fe;border-radius:99px;height:3px">
            <div style="width:24%;background:#0ea5e9;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#16a34a">HARDNESS</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#15803d;font-family:'Cascadia Code','Consolas',monospace">38</span>
            <span style="font-size:9px;color:#86efac;font-weight:600">mg/L</span>
          </div>
          <div style="margin-top:8px;background:#dcfce7;border-radius:99px;height:3px">
            <div style="width:38%;background:#22c55e;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#fefce8;border:1px solid #fde68a;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#ca8a04">PH</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#a16207;font-family:'Cascadia Code','Consolas',monospace">7.2</span>
          </div>
          <div style="margin-top:8px;background:#fef9c3;border-radius:99px;height:3px">
            <div style="width:51%;background:#eab308;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#059669">ALKALINE</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#065f46;font-family:'Cascadia Code','Consolas',monospace">115</span>
            <span style="font-size:9px;color:#6ee7b7;font-weight:600">mg/L</span>
          </div>
          <div style="margin-top:8px;background:#a7f3d0;border-radius:99px;height:3px">
            <div style="width:58%;background:#10b981;border-radius:99px;height:3px"></div>
          </div>
        </div>
      </div>

    </div>
    <div style="margin-top:12px;display:flex;align-items:center;gap:6px">
      <div style="width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px rgba(34,197,94,.6)"></div>
      <span style="font-size:10px;font-weight:600;color:#16a34a">Normal</span>
      <span style="margin-left:auto;font-size:10px;color:#94a3b8">Data statis</span>
    </div>
  </div>

  <!-- ══ WWTP / LIMBAH — full width ══ -->
  <div class="s-card" style="--acc:#f97316;grid-column:1/-1">
    <div class="s-bar"></div>
    <div class="s-label" style="font-size:11px;letter-spacing:1.5px;font-weight:700;color:#f97316">WWTP / LIMBAH</div>
    <div style="display:grid;grid-template-columns:1fr auto 180px 180px;grid-template-rows:1fr 1fr;gap:8px;margin-top:12px;align-items:stretch">

      <!-- GROUND TANK B — span 2 baris di kolom 1 -->
      <div style="grid-row:span 2;background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#ea580c">GROUND TANK B</div>
        <div style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #fdba74;border-radius:10px;overflow:hidden;background:#ffedd5">
          <div style="position:absolute;bottom:0;left:0;right:0;height:89%;background:linear-gradient(180deg,#fb923c,#ea580c);border-radius:0 0 8px 8px"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4)">89%</span>
          </div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#fdba74;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#fdba74;border-radius:0 0 4px 4px"></div>
        </div>
        <div style="font-size:9px;color:#9a3412;font-weight:600;text-align:center">65.000lt / 73.000lt</div>
        <div style="width:100%;background:#fde8c8;border-radius:99px;height:5px">
          <div style="width:89%;background:linear-gradient(90deg,#fb923c,#dc2626);border-radius:99px;height:5px"></div>
        </div>
      </div>

      <!-- SEPARATOR — span 2 baris di kolom 2 -->
      <div style="grid-row:span 2;display:flex;align-items:center;justify-content:center">
        <div style="writing-mode:vertical-rl;text-orientation:mixed;font-size:8px;font-weight:800;letter-spacing:2px;color:#ea580c;background:#fff7ed;border:1px solid #fdba74;border-radius:6px;padding:10px 6px;transform:rotate(180deg)">WWTP</div>
      </div>

      <!-- COD -->
      <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
        <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#dc2626">COD</div>
        <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
          <span style="font-size:22px;font-weight:800;color:#b91c1c;font-family:'Cascadia Code','Consolas',monospace">472</span>
          <span style="font-size:9px;color:#fca5a5;font-weight:600">ppm</span>
        </div>
        <div style="margin-top:8px;background:#fee2e2;border-radius:99px;height:3px">
          <div style="width:79%;background:#ef4444;border-radius:99px;height:3px"></div>
        </div>
      </div>

      <!-- BOD -->
      <div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
        <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#ea580c">BOD</div>
        <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
          <span style="font-size:22px;font-weight:800;color:#c2410c;font-family:'Cascadia Code','Consolas',monospace">236</span>
          <span style="font-size:9px;color:#fdba74;font-weight:600">ppm</span>
        </div>
        <div style="margin-top:8px;background:#fde8c8;border-radius:99px;height:3px">
          <div style="width:39%;background:#f97316;border-radius:99px;height:3px"></div>
        </div>
      </div>

      <!-- PH -->
      <div style="background:#fefce8;border:1px solid #fde68a;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
        <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#ca8a04">PH</div>
        <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
          <span style="font-size:22px;font-weight:800;color:#a16207;font-family:'Cascadia Code','Consolas',monospace">8.1</span>
        </div>
        <div style="margin-top:8px;background:#fef9c3;border-radius:99px;height:3px">
          <div style="width:58%;background:#eab308;border-radius:99px;height:3px"></div>
        </div>
      </div>

      <!-- TDS -->
      <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
        <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#0284c7">TDS</div>
        <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
          <span style="font-size:22px;font-weight:800;color:#0369a1;font-family:'Cascadia Code','Consolas',monospace">310</span>
          <span style="font-size:9px;color:#7dd3fc;font-weight:600">ppm</span>
        </div>
        <div style="margin-top:8px;background:#e0f2fe;border-radius:99px;height:3px">
          <div style="width:52%;background:#0ea5e9;border-radius:99px;height:3px"></div>
        </div>
      </div>

    </div>
    <div style="margin-top:12px;display:flex;align-items:center;gap:6px">
      <div style="width:7px;height:7px;border-radius:50%;background:#f97316;box-shadow:0 0 6px rgba(249,115,22,.6)"></div>
      <span style="font-size:10px;font-weight:600;color:#ea580c">Monitoring</span>
      <span style="margin-left:auto;font-size:10px;color:#94a3b8">Data statis</span>
    </div>
  </div>

  <!-- ══ DIESEL OIL — full width ══ -->
  <div class="s-card" style="--acc:#92400e;grid-column:1/-1">
    <div class="s-bar"></div>
    <div class="s-label" style="font-size:11px;letter-spacing:1.5px;font-weight:700;color:#92400e">DIESEL OIL</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:12px;align-items:stretch">

      <!-- TANK -->
      <div style="background:#fef3c7;border:1px solid #fde68a;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#92400e">TANK</div>
        <div style="position:relative;width:100%;height:120px;border:2px solid #fbbf24;border-radius:10px;overflow:hidden;background:#fef9c3">
          <div style="position:absolute;bottom:0;left:0;right:0;height:78%;background:linear-gradient(180deg,#fbbf24,#d97706);border-radius:0 0 8px 8px"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4)">78%</span>
          </div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#fbbf24;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#fbbf24;border-radius:0 0 4px 4px"></div>
        </div>
        <div style="font-size:9px;color:#78350f;font-weight:600;text-align:center">3.900lt / 5.000lt</div>
        <div style="width:100%;background:#fde68a;border-radius:99px;height:5px">
          <div style="width:78%;background:#d97706;border-radius:99px;height:5px"></div>
        </div>
      </div>

      <!-- GENSET + TANK GENSET -->
      <div style="background:#fef3c7;border:1px solid #fde68a;border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:10px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#92400e">GENSET</div>
        <div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:8px;padding:10px 14px;display:flex;align-items:center;gap:10px">
          <div style="font-size:28px">⚡</div>
          <div>
            <div style="font-size:10px;font-weight:700;color:#78350f">STATUS</div>
            <div style="font-size:14px;font-weight:800;color:#d97706">STANDBY</div>
          </div>
        </div>
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#92400e;margin-top:4px">TANK GENSET</div>
        <div style="position:relative;width:100%;height:70px;border:2px solid #fbbf24;border-radius:10px;overflow:hidden;background:#fef9c3">
          <div style="position:absolute;bottom:0;left:0;right:0;height:62%;background:linear-gradient(180deg,#fbbf24,#d97706);border-radius:0 0 8px 8px"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span style="font-size:18px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4)">62%</span>
          </div>
        </div>
        <div style="font-size:9px;color:#78350f;font-weight:600;text-align:center">310lt / 500lt</div>
        <div style="width:100%;background:#fde68a;border-radius:99px;height:4px">
          <div style="width:62%;background:#d97706;border-radius:99px;height:4px"></div>
        </div>
      </div>

    </div>
    <div style="margin-top:12px;display:flex;align-items:center;gap:6px">
      <div style="width:7px;height:7px;border-radius:50%;background:#d97706;box-shadow:0 0 6px rgba(217,119,6,.6)"></div>
      <span style="font-size:10px;font-weight:600;color:#92400e">Monitoring</span>
      <span style="margin-left:auto;font-size:10px;color:#94a3b8">Data statis</span>
    </div>
  </div>


  </div>
`;
}