// ═══════════════════════════════════════════════════════════
// MQTT CONNECTION STATE - Indicate MQTT/ESP connection status
// ═══════════════════════════════════════════════════════════
window.mqttConnected = true;  // Default: assume connected, set to false on error

function _isEspAlive(key) {
  const t = _espLastSeen[key];
  if (!t) return false;
  return (Date.now() - new Date(t).getTime()) < ESP_TIMEOUT_MS;
}

function updateEspBadge() {
  const wrap = document.getElementById('esp-badge');
  if (!wrap) return;

  // Check MQTT status
  const isMqttOffline = typeof mqttConnected !== 'undefined' && !mqttConnected;
  if (isMqttOffline) {
    wrap.className = 'esp-badge offline';
    wrap.innerHTML = `
      <div class="esp-dot"></div>
      <span id="esp-label">MQTT OFFLINE</span>
      <span style="font-size:9px;margin-left:3px;color:inherit;opacity:.7">▾</span>
    `;
    wrap.onclick = toggleEspPopup;
    wrap.style.cursor = 'pointer';
    wrap.style.userSelect = 'none';
    return;
  }

  // Build sensor states dari FIXED_TANK_SLOTS (s1-s8 only)
  let connCount = 0, total = 0;
  if (typeof FIXED_TANK_SLOTS !== 'undefined') {
    const sensorKeys = new Set();
    FIXED_TANK_SLOTS.forEach(slot => {
      if (!sensorKeys.has(slot.key) && slot.key.match(/^s[1-8]$/)) {
        sensorKeys.add(slot.key);
        total++;
        if (_isEspAlive(slot.key)) connCount++;
      }
    });
  }

  // Warna badge keseluruhan
  let badgeClass = 'esp-badge';
  if (total > 0) {
    if (connCount === total)      badgeClass += ' connected';
    else if (connCount === 0)     badgeClass += ' waiting';
    else                          badgeClass += ' partial';
  }

  const summaryText = connCount + '/' + total + ' Online';

  wrap.className = badgeClass;
  wrap.onclick   = toggleEspPopup;
  wrap.style.cursor = 'pointer';
  wrap.style.userSelect = 'none';

  wrap.innerHTML = `
    <div class="esp-dot"></div>
    <span id="esp-label">${summaryText}</span>
    <span style="font-size:9px;margin-left:3px;color:inherit;opacity:.7">▾</span>
  `;
}

function toggleEspPopup() {
  let popup = document.getElementById('esp-popup');
  if (popup) { popup.remove(); return; }

  // Refresh MQTT status sebelum render popup
  if (typeof checkMQTTStatus === 'function') {
    checkMQTTStatus();
  }

  const wrap  = document.getElementById('esp-badge');
  const rect  = wrap.getBoundingClientRect();

  popup = document.createElement('div');
  popup.id = 'esp-popup';
  popup.style.cssText = `
    position:fixed;
    top:${rect.bottom + 8}px;
    right:${window.innerWidth - rect.right}px;
    background:#fff;
    border:1px solid #e2e8f0;
    border-radius:12px;
    box-shadow:0 8px 24px rgba(0,0,0,.12);
    padding:10px 4px;
    z-index:9999;
    min-width:240px;max-height:80vh;overflow-y:auto;
    font-family:inherit;
  `;

  // Kumpulkan status tangki aktif dari sensors.js
  const tankRows = (() => {
    if (typeof getSensors !== 'function') return '';
    const sensors = getSensors().filter(s => s.active !== false);
    if (!sensors.length) return '';

    const tankItems = sensors.map(s => {
      // Cek apakah sensor punya data terbaru (ada di DOM)
      const pctEl = document.getElementById('tank-pct-' + s.id);
      const offEl = document.getElementById('tank-offline-' + s.id);
      const hasOfflineBadge = offEl && offEl.style.display !== 'none';
      const pctTxt = pctEl ? pctEl.textContent.replace(/<[^>]+>/g,'').trim() : '—%';
      // Tank offline jika: tidak ada data (—%) ATAU offline badge terlihat ATAU MQTT disconnected
      const isOffline = pctTxt === '—%' || hasOfflineBadge || (typeof mqttConnected !== 'undefined' && !mqttConnected);
      const dotClr = isOffline ? '#f59e0b' : '#22c55e';
      const shadow = isOffline ? 'none' : '0 0 5px rgba(34,197,94,.5)';
      const statusTxt = isOffline ? 'Offline' : 'Online';
      const statusClr = isOffline ? '#b45309' : '#16a34a';
      return `
        <div style="display:flex;align-items:center;gap:8px;padding:5px 14px;border-radius:6px;transition:.15s"
          onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='transparent'">
          <div style="width:7px;height:7px;border-radius:50%;background:${dotClr};box-shadow:${shadow};flex-shrink:0"></div>
          <div style="flex:1;min-width:0">
            <div style="font-size:11px;font-weight:600;color:#1e293b">${s.name}</div>
            <div style="font-size:9px;color:#94a3b8">${s.key} · ${pctTxt}</div>
          </div>
          <div style="font-size:10px;font-weight:700;color:${statusClr}">${statusTxt}</div>
        </div>`;
    }).join('');

    return `
      <div style="padding:6px 14px 4px;font-size:10px;font-weight:700;color:#94a3b8;letter-spacing:1px;text-transform:uppercase">
        Water Level
      </div>
      ${tankItems}`;
  })();

  popup.innerHTML = tankRows || '<div style="padding:10px 14px;color:#94a3b8;text-align:center">No active tanks</div>';

  document.body.appendChild(popup);

  // Tutup kalau klik di luar
  setTimeout(() => {
    document.addEventListener('click', function _close(ev) {
      if (!popup.contains(ev.target) && ev.target.id !== 'esp-badge' && !document.getElementById('esp-badge')?.contains(ev.target)) {
        popup.remove();
        document.removeEventListener('click', _close);
      }
    });
  }, 50);
}
window.toggleEspPopup = toggleEspPopup;

// Legacy — masih dipanggil kalau ada kode lain
function setEspStatus(state) {
  updateEspBadge();
}

// ══ IOT RENDER ═════════════════════════════════════
function renderIoT(content) {
  content.innerHTML = getIoTHTML();
  initWidgets();
  renderTankCards();
  
  // Add CSS animation for refresh pulse
  if (!document.getElementById('refresh-pulse-style')) {
    const style = document.createElement('style');
    style.id = 'refresh-pulse-style';
    style.textContent = `
      @keyframes refreshPulse {
        0% { background: #e0f2fe; }
        50% { background: #bfdbfe; }
        100% { background: #e0f2fe; }
      }
      .refresh-pulse {
        animation: refreshPulse 0.5s ease-in-out;
      }
    `;
    document.head.appendChild(style);
  }
  
  // Auto refresh runs silently in background - no visual indicator shown
  
  fetchSummary();
  setTimeout(updateDashWidgets, 200);
  
  // Start MQTT status polling
  if (typeof startMQTTStatusPolling === 'function') {
    startMQTTStatusPolling();
  }
  
  // ══ Start sensor settings sync (cross-device) ══════════════════
  // Load settings dari API pertama kali, kemudian periodic sync setiap 30 detik
  if (typeof startSensorSettingsSync === 'function') {
    startSensorSettingsSync();
    console.log('✅ Sensor settings sync started (30s interval)');
  }
  
  // Clear any existing poll before setting new one
  if (window._poll) { clearInterval(window._poll); window._poll = null; }
  if (window._pollCounter) { clearInterval(window._pollCounter); window._pollCounter = null; }
  
  // Robust polling: setiap 5 detik, selalu fetch ulang secara otomatis
  window._poll = setInterval(() => {
    // Check if IoT page is still active (wl-tanks-container ada di DOM)
    if (!document.getElementById('wl-tanks-container')) {
      clearInterval(window._poll);
      window._poll = null;
      return;
    }
    console.log('⏰ Auto-refresh: ' + new Date().toLocaleTimeString());
    fetchSummary();
  }, 5000);
  
  // Initial fetch
  fetchSummary();
}

function getIoTHTML() {
  const ov = `
    <div class="esp-waiting-overlay show" id="ov-ID">
      <div class="esp-wait-icon">🔌</div>
      <div class="esp-wait-txt">Waiting for ESP<span class="dots"></span></div>
      <div class="esp-wait-sub">Belum ada data masuk</div>
    </div>`;

  return `
  <div class="sensor-grid">

   <!-- ══ TREAT WATER 2 — full width ══ -->
  <div class="s-card" style="--acc:#8b5cf6;grid-column:1/-1;position:relative">
    <div class="s-bar"></div>
    <button class="s-detail-btn" onclick="openSensorDetailModal('treatwater2')">Detail</button>
    <div class="s-label" style="font-size:11px;letter-spacing:1.5px;font-weight:700;color:#8b5cf6">TREAT WATER 2</div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-top:12px;align-items:stretch">


      <!-- TANU EDI -->
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#16a34a">TANU EDI</div>
        <div id="tank-body-tanu_edi" style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #86efac;border-radius:10px;overflow:hidden;background:#dcfce7">
          <div id="tank-water-tanu_edi" style="position:absolute;bottom:0;left:0;right:0;height:0%;background:linear-gradient(180deg,#4ade80,#16a34a);border-radius:0 0 8px 8px;transition:height 1.8s cubic-bezier(.34,1.2,.64,1)"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span id="tank-pct-tanu_edi" style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4);filter:none;backface-visibility:hidden;-webkit-font-smoothing:antialiased">—%</span>
          </div>
          <div style="position:absolute;left:0;right:0;bottom:40%;height:1.5px;background:#eab308;opacity:.75;pointer-events:none"></div>
          <div style="position:absolute;left:0;right:0;bottom:15%;height:1.5px;background:#ef4444;opacity:.75;pointer-events:none"></div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
        </div>
        <div id="tank-vol-tanu_edi" style="font-size:9px;color:#15803d;font-weight:600;text-align:center">7.200lt / 10.000lt</div>
        <div id="tank-cm-tanu_edi" style="font-size:8px;color:#94a3b8;text-align:center">— cm air</div>
        <div id="tank-offline-tanu_edi" style="display:none;align-items:center;gap:3px;padding:2px 7px;border-radius:20px;background:#f1f5f9;border:1px solid #e2e8f0;font-size:8px;font-weight:700;color:#94a3b8;letter-spacing:.5px">
          <span style="width:5px;height:5px;border-radius:50%;background:#94a3b8;display:inline-block"></span>OFFLINE
        </div>
        <div style="width:100%;background:#bbf7d0;border-radius:99px;height:5px">
          <div id="tank-bar-tanu_edi" style="width:0%;background:#22c55e;border-radius:99px;height:5px;transition:width 1.8s ease"></div>
        </div>
      </div>


      <!-- FEED EDI -->
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#16a34a">FEED EDI</div>
        <div id="tank-body-feed_edi" style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #86efac;border-radius:10px;overflow:hidden;background:#dcfce7">
          <div id="tank-water-feed_edi" style="position:absolute;bottom:0;left:0;right:0;height:0%;background:linear-gradient(180deg,#4ade80,#16a34a);border-radius:0 0 8px 8px;transition:height 1.8s cubic-bezier(.34,1.2,.64,1)"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span id="tank-pct-feed_edi" style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4);filter:none;backface-visibility:hidden;-webkit-font-smoothing:antialiased">—%</span>
          </div>
          <div style="position:absolute;left:0;right:0;bottom:40%;height:1.5px;background:#eab308;opacity:.75;pointer-events:none"></div>
          <div style="position:absolute;left:0;right:0;bottom:15%;height:1.5px;background:#ef4444;opacity:.75;pointer-events:none"></div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
        </div>
        <div id="tank-vol-feed_edi" style="font-size:9px;color:#15803d;font-weight:600;text-align:center">5.800lt / 10.000lt</div>
        <div id="tank-cm-feed_edi" style="font-size:8px;color:#94a3b8;text-align:center">— cm air</div>
        <div id="tank-offline-feed_edi" style="display:none;align-items:center;gap:3px;padding:2px 7px;border-radius:20px;background:#f1f5f9;border:1px solid #e2e8f0;font-size:8px;font-weight:700;color:#94a3b8;letter-spacing:.5px">
          <span style="width:5px;height:5px;border-radius:50%;background:#94a3b8;display:inline-block"></span>OFFLINE
        </div>
        <div style="width:100%;background:#bbf7d0;border-radius:99px;height:5px">
          <div id="tank-bar-feed_edi" style="width:0%;background:#22c55e;border-radius:99px;height:5px;transition:width 1.8s ease"></div>
        </div>
      </div>

      <!-- GRID 2x2: TDS + Hardness + PH + Alkaline -->
      <div style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;gap:8px">
        <div style="background:#f5f3ff;border:1px solid #ddd6fe;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#7c3aed">TDS</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#5b21b6;font-family:'Cascadia Code','Consolas',monospace">48</span>
            <span style="font-size:9px;color:#c4b5fd;font-weight:600">ppm</span>
          </div>
          <div style="margin-top:8px;background:#ddd6fe;border-radius:99px;height:3px">
            <div style="width:16%;background:#8b5cf6;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#eef2ff;border:1px solid #c7d2fe;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#4f46e5">HARDNESS</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#3730a3;font-family:'Cascadia Code','Consolas',monospace">18</span>
            <span style="font-size:9px;color:#a5b4fc;font-weight:600">mg/L</span>
          </div>
          <div style="margin-top:8px;background:#c7d2fe;border-radius:99px;height:3px">
            <div style="width:18%;background:#6366f1;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#fefce8;border:1px solid #fde68a;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#ca8a04">PH</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#a16207;font-family:'Cascadia Code','Consolas',monospace">7.0</span>
          </div>
          <div style="margin-top:8px;background:#fef9c3;border-radius:99px;height:3px">
            <div style="width:50%;background:#eab308;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#059669">ALKALINE</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#065f46;font-family:'Cascadia Code','Consolas',monospace">95</span>
            <span style="font-size:9px;color:#6ee7b7;font-weight:600">mg/L</span>
          </div>
          <div style="margin-top:8px;background:#a7f3d0;border-radius:99px;height:3px">
            <div style="width:48%;background:#10b981;border-radius:99px;height:3px"></div>
          </div>
        </div>
      </div>

    </div>
    <div style="margin-top:12px;display:flex;align-items:center;gap:6px">
      <div style="width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px rgba(34,197,94,.6)"></div>
      <span style="font-size:10px;font-weight:600;color:#16a34a">Normal</span>
      <span style="margin-left:auto;font-size:10px;color:#94a3b8">Data statis</span>
    </div>
  </div>

  <!-- ══ TREAT WATER 1 — full width ══ -->
  <div class="s-card" style="--acc:#6366f1;grid-column:1/-1;position:relative">
    <div class="s-bar"></div>
    <button class="s-detail-btn" onclick="openSensorDetailModal('treatwater1')">Detail</button>
    <div class="s-label" style="font-size:11px;letter-spacing:1.5px;font-weight:700;color:#6366f1">TREAT WATER 1</div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:14px;margin-top:12px;align-items:stretch">


      <!-- SLURY 1 -->
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#16a34a">SLURY 1</div>
        <div id="tank-body-slury_1" style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #86efac;border-radius:10px;overflow:hidden;background:#dcfce7">
          <div id="tank-water-slury_1" style="position:absolute;bottom:0;left:0;right:0;height:0%;background:linear-gradient(180deg,#4ade80,#16a34a);border-radius:0 0 8px 8px;transition:height 1.8s cubic-bezier(.34,1.2,.64,1)"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span id="tank-pct-slury_1" style="font-size:24px;font-weight:900;color:#ffffff;text-shadow:none;letter-spacing:0.5px;filter:none;backface-visibility:hidden;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeSpeed;line-height:1;-webkit-text-stroke:0.3px rgba(255,255,255,0.3)">—%</span>
          </div>
          <div style="position:absolute;left:0;right:0;bottom:40%;height:1.5px;background:#eab308;opacity:.75;pointer-events:none"></div>
          <div style="position:absolute;left:0;right:0;bottom:15%;height:1.5px;background:#ef4444;opacity:.75;pointer-events:none"></div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
        </div>
        <div id="tank-vol-slury_1" style="font-size:9px;color:#15803d;font-weight:600;text-align:center">6.000lt / 10.000lt</div>
        <div id="tank-cm-slury_1" style="font-size:8px;color:#94a3b8;text-align:center">— cm air</div>
        <div id="tank-offline-slury_1" style="display:none;align-items:center;gap:3px;padding:2px 7px;border-radius:20px;background:#f1f5f9;border:1px solid #e2e8f0;font-size:8px;font-weight:700;color:#94a3b8;letter-spacing:.5px">
          <span style="width:5px;height:5px;border-radius:50%;background:#94a3b8;display:inline-block"></span>OFFLINE
        </div>
        <div style="width:100%;background:#bbf7d0;border-radius:99px;height:5px">
          <div id="tank-bar-slury_1" style="width:0%;background:#22c55e;border-radius:99px;height:5px;transition:width 1.8s ease"></div>
        </div>
      </div>


      <!-- SLURY 2 -->
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#16a34a">SLURY 2</div>
        <div id="tank-body-slury_2" style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #86efac;border-radius:10px;overflow:hidden;background:#dcfce7">
          <div id="tank-water-slury_2" style="position:absolute;bottom:0;left:0;right:0;height:0%;background:linear-gradient(180deg,#4ade80,#16a34a);border-radius:0 0 8px 8px;transition:height 1.8s cubic-bezier(.34,1.2,.64,1)"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span id="tank-pct-slury_2" style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4);filter:none;backface-visibility:hidden;-webkit-font-smoothing:antialiased">—%</span>
          </div>
          <div style="position:absolute;left:0;right:0;bottom:40%;height:1.5px;background:#eab308;opacity:.75;pointer-events:none"></div>
          <div style="position:absolute;left:0;right:0;bottom:15%;height:1.5px;background:#ef4444;opacity:.75;pointer-events:none"></div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
        </div>
        <div id="tank-vol-slury_2" style="font-size:9px;color:#15803d;font-weight:600;text-align:center">5.500lt / 10.000lt</div>
        <div id="tank-cm-slury_2" style="font-size:8px;color:#94a3b8;text-align:center">— cm air</div>
        <div id="tank-offline-slury_2" style="display:none;align-items:center;gap:3px;padding:2px 7px;border-radius:20px;background:#f1f5f9;border:1px solid #e2e8f0;font-size:8px;font-weight:700;color:#94a3b8;letter-spacing:.5px">
          <span style="width:5px;height:5px;border-radius:50%;background:#94a3b8;display:inline-block"></span>OFFLINE
        </div>
        <div style="width:100%;background:#bbf7d0;border-radius:99px;height:5px">
          <div id="tank-bar-slury_2" style="width:0%;background:#22c55e;border-radius:99px;height:5px;transition:width 1.8s ease"></div>
        </div>
      </div>


      <!-- FEED SLURY -->
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#16a34a">FEED SLURY</div>
        <div id="tank-body-feed_slury" style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #86efac;border-radius:10px;overflow:hidden;background:#dcfce7">
          <div id="tank-water-feed_slury" style="position:absolute;bottom:0;left:0;right:0;height:0%;background:linear-gradient(180deg,#4ade80,#16a34a);border-radius:0 0 8px 8px;transition:height 1.8s cubic-bezier(.34,1.2,.64,1)"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span id="tank-pct-feed_slury" style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4);filter:none;backface-visibility:hidden;-webkit-font-smoothing:antialiased">—%</span>
          </div>
          <div style="position:absolute;left:0;right:0;bottom:40%;height:1.5px;background:#eab308;opacity:.75;pointer-events:none"></div>
          <div style="position:absolute;left:0;right:0;bottom:15%;height:1.5px;background:#ef4444;opacity:.75;pointer-events:none"></div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
        </div>
        <div id="tank-vol-feed_slury" style="font-size:9px;color:#15803d;font-weight:600;text-align:center">7.000lt / 10.000lt</div>
        <div id="tank-cm-feed_slury" style="font-size:8px;color:#94a3b8;text-align:center">— cm air</div>
        <div id="tank-offline-feed_slury" style="display:none;align-items:center;gap:3px;padding:2px 7px;border-radius:20px;background:#f1f5f9;border:1px solid #e2e8f0;font-size:8px;font-weight:700;color:#94a3b8;letter-spacing:.5px">
          <span style="width:5px;height:5px;border-radius:50%;background:#94a3b8;display:inline-block"></span>OFFLINE
        </div>
        <div style="width:100%;background:#bbf7d0;border-radius:99px;height:5px">
          <div id="tank-bar-feed_slury" style="width:0%;background:#22c55e;border-radius:99px;height:5px;transition:width 1.8s ease"></div>
        </div>
      </div>

      <!-- GRID 2x2: TDS + Hardness + PH + Alkaline -->
      <div style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;gap:8px">
        <div style="background:#eef2ff;border:1px solid #c7d2fe;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#4f46e5">TDS</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#3730a3;font-family:'Cascadia Code','Consolas',monospace">85</span>
            <span style="font-size:9px;color:#a5b4fc;font-weight:600">ppm</span>
          </div>
          <div style="margin-top:8px;background:#c7d2fe;border-radius:99px;height:3px">
            <div style="width:28%;background:#6366f1;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#f5f3ff;border:1px solid #ddd6fe;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#7c3aed">HARDNESS</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#5b21b6;font-family:'Cascadia Code','Consolas',monospace">42</span>
            <span style="font-size:9px;color:#c4b5fd;font-weight:600">mg/L</span>
          </div>
          <div style="margin-top:8px;background:#ddd6fe;border-radius:99px;height:3px">
            <div style="width:42%;background:#8b5cf6;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#fefce8;border:1px solid #fde68a;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#ca8a04">PH</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#a16207;font-family:'Cascadia Code','Consolas',monospace">7.4</span>
          </div>
          <div style="margin-top:8px;background:#fef9c3;border-radius:99px;height:3px">
            <div style="width:53%;background:#eab308;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#059669">ALKALINE</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#065f46;font-family:'Cascadia Code','Consolas',monospace">120</span>
            <span style="font-size:9px;color:#6ee7b7;font-weight:600">mg/L</span>
          </div>
          <div style="margin-top:8px;background:#a7f3d0;border-radius:99px;height:3px">
            <div style="width:60%;background:#10b981;border-radius:99px;height:3px"></div>
          </div>
        </div>
      </div>

    </div>
    <div style="margin-top:12px;display:flex;align-items:center;gap:6px">
      <div style="width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px rgba(34,197,94,.6)"></div>
      <span style="font-size:10px;font-weight:600;color:#16a34a">Normal</span>
      <span style="margin-left:auto;font-size:10px;color:#94a3b8">Data statis</span>
    </div>
  </div>

  <!-- ══ FILTER WATER — full width ══ -->
  <div class="s-card" style="--acc:#0ea5e9;grid-column:1/-1;position:relative">
    <div class="s-bar"></div>
    <button class="s-detail-btn" onclick="openSensorDetailModal('filterwater')">Detail</button>
    <div class="s-label" style="font-size:11px;letter-spacing:1.5px;font-weight:700;color:#0ea5e9">FILTER WATER</div>
    <div style="display:grid;grid-template-columns:1fr auto 1fr 1fr;gap:14px;margin-top:12px;align-items:stretch">

      <!-- AIR PROSES (s1=air_proses) -->
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#16a34a">AIR PROSES</div>
        <div id="tank-body-air_proses" style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #86efac;border-radius:10px;overflow:hidden;background:#dcfce7">
          <div id="tank-water-air_proses" style="position:absolute;bottom:0;left:0;right:0;height:0%;background:linear-gradient(180deg,#4ade80,#16a34a);border-radius:0 0 8px 8px;transition:height 1.8s cubic-bezier(.34,1.2,.64,1)"></div>
          <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px">
            <span id="tank-pct-air_proses" style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4)">—%</span>
            <span id="tank-cm-air_proses" style="font-size:9px;color:rgba(255,255,255,.75)">— cm air</span>
          </div>
          <div id="tank-offline-air_proses" style="display:none;position:absolute;bottom:8px;left:0;right:0;justify-content:center"><span style="background:rgba(0,0,0,.4);color:#fff;font-size:9px;padding:2px 8px;border-radius:99px">Offline</span></div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
        </div>
        <div id="tank-vol-air_proses" style="font-size:9px;color:#15803d;font-weight:600;text-align:center">— lt</div>
        <div style="width:100%;background:#bbf7d0;border-radius:99px;height:5px">
          <div id="tank-bar-air_proses" style="width:0%;background:#22c55e;border-radius:99px;height:5px;transition:width 1.8s ease"></div>
        </div>
      </div>

      <!-- FLOW vertikal -->
      <div style="display:flex;align-items:center;justify-content:center">
        <div style="writing-mode:vertical-rl;text-orientation:mixed;font-size:8px;font-weight:800;letter-spacing:2px;color:#0369a1;background:#e0f2fe;border:1px solid #7dd3fc;border-radius:6px;padding:10px 6px;transform:rotate(180deg)">FLOW</div>
      </div>

      <!-- GROUND TANK A (s9 — belum aktif) -->
      <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#0284c7">GROUND TANK A</div>
        <div id="tank-body-ground_tank_a" style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #7dd3fc;border-radius:10px;overflow:hidden;background:#e0f2fe">
          <div id="tank-water-ground_tank_a" style="position:absolute;bottom:0;left:0;right:0;height:0%;background:linear-gradient(180deg,#38bdf8,#0284c7);border-radius:0 0 8px 8px;transition:height 1.8s cubic-bezier(.34,1.2,.64,1)"></div>
          <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px">
            <span id="tank-pct-ground_tank_a" style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4)">—%</span>
            <span id="tank-cm-ground_tank_a" style="font-size:9px;color:rgba(255,255,255,.75)">— cm air</span>
          </div>
          <div id="tank-offline-ground_tank_a" style="display:flex;position:absolute;bottom:8px;left:0;right:0;justify-content:center"><span style="background:rgba(0,0,0,.35);color:#fff;font-size:9px;padding:2px 10px;border-radius:99px">Sensor belum aktif</span></div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#7dd3fc;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#7dd3fc;border-radius:0 0 4px 4px"></div>
        </div>
        <div id="tank-vol-ground_tank_a" style="font-size:9px;color:#0369a1;font-weight:600;text-align:center">— lt</div>
        <div style="width:100%;background:#bae6fd;border-radius:99px;height:5px">
          <div id="tank-bar-ground_tank_a" style="width:0%;background:#0ea5e9;border-radius:99px;height:5px;transition:width 1.8s ease"></div>
        </div>
      </div>

      <!-- GRID 2x2: TDS + Hardness + PH + Alkaline -->
      <div style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;gap:8px">
        <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#0284c7">TDS</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#0369a1;font-family:'Cascadia Code','Consolas',monospace">72</span>
            <span style="font-size:9px;color:#7dd3fc;font-weight:600">ppm</span>
          </div>
          <div style="margin-top:8px;background:#e0f2fe;border-radius:99px;height:3px">
            <div style="width:24%;background:#0ea5e9;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#16a34a">HARDNESS</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#15803d;font-family:'Cascadia Code','Consolas',monospace">38</span>
            <span style="font-size:9px;color:#86efac;font-weight:600">mg/L</span>
          </div>
          <div style="margin-top:8px;background:#dcfce7;border-radius:99px;height:3px">
            <div style="width:38%;background:#22c55e;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#fefce8;border:1px solid #fde68a;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#ca8a04">PH</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#a16207;font-family:'Cascadia Code','Consolas',monospace">7.2</span>
          </div>
          <div style="margin-top:8px;background:#fef9c3;border-radius:99px;height:3px">
            <div style="width:51%;background:#eab308;border-radius:99px;height:3px"></div>
          </div>
        </div>
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
          <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#059669">ALKALINE</div>
          <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
            <span style="font-size:22px;font-weight:800;color:#065f46;font-family:'Cascadia Code','Consolas',monospace">115</span>
            <span style="font-size:9px;color:#6ee7b7;font-weight:600">mg/L</span>
          </div>
          <div style="margin-top:8px;background:#a7f3d0;border-radius:99px;height:3px">
            <div style="width:58%;background:#10b981;border-radius:99px;height:3px"></div>
          </div>
        </div>
      </div>

    </div>
    <div style="margin-top:12px;display:flex;align-items:center;gap:6px">
      <div style="width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px rgba(34,197,94,.6)"></div>
      <span style="font-size:10px;font-weight:600;color:#16a34a">Normal</span>
      <span style="margin-left:auto;font-size:10px;color:#94a3b8">Data statis</span>
    </div>
  </div>

  <!-- ══ WWTP / LIMBAH — full width ══ -->
  <div class="s-card" style="--acc:#16a34a;grid-column:1/-1;position:relative">
    <div class="s-bar"></div>
    <button class="s-detail-btn" onclick="openSensorDetailModal('wwtp')">Detail</button>
    <div class="s-label" style="font-size:11px;letter-spacing:1.5px;font-weight:700;color:#16a34a">WWTP / LIMBAH</div>
    <div style="display:grid;grid-template-columns:1fr auto 180px 180px;grid-template-rows:1fr 1fr;gap:8px;margin-top:12px;align-items:stretch">

      <!-- GROUND TANK B — span 2 baris di kolom 1 -->
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px;grid-row:span 2">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#16a34a">GROUND TANK B</div>
        <div id="tank-body-ground_tank_b" style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #86efac;border-radius:10px;overflow:hidden;background:#dcfce7">
          <div id="tank-water-ground_tank_b" style="position:absolute;bottom:0;left:0;right:0;height:0%;background:linear-gradient(180deg,#4ade80,#16a34a);border-radius:0 0 8px 8px;transition:height 1.8s cubic-bezier(.34,1.2,.64,1)"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span id="tank-pct-ground_tank_b" style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4);filter:none;backface-visibility:hidden;-webkit-font-smoothing:antialiased">—%</span>
          </div>
          <div style="position:absolute;left:0;right:0;bottom:40%;height:1.5px;background:#eab308;opacity:.75;pointer-events:none"></div>
          <div style="position:absolute;left:0;right:0;bottom:15%;height:1.5px;background:#ef4444;opacity:.75;pointer-events:none"></div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
        </div>
        <div id="tank-vol-ground_tank_b" style="font-size:9px;color:#15803d;font-weight:600;text-align:center">65.000lt / 73.000lt</div>
        <div id="tank-cm-ground_tank_b" style="font-size:8px;color:#94a3b8;text-align:center">— cm air</div>
        <div id="tank-offline-ground_tank_b" style="display:none;align-items:center;gap:3px;padding:2px 7px;border-radius:20px;background:#f1f5f9;border:1px solid #e2e8f0;font-size:8px;font-weight:700;color:#94a3b8;letter-spacing:.5px">
          <span style="width:5px;height:5px;border-radius:50%;background:#94a3b8;display:inline-block"></span>OFFLINE
        </div>
        <div style="width:100%;background:#bbf7d0;border-radius:99px;height:5px">
          <div id="tank-bar-ground_tank_b" style="width:0%;background:#22c55e;border-radius:99px;height:5px;transition:width 1.8s ease"></div>
        </div>
      </div>

      <!-- SEPARATOR — span 2 baris di kolom 2 -->
      <div style="grid-row:span 2;display:flex;align-items:center;justify-content:center">
        <div style="writing-mode:vertical-rl;text-orientation:mixed;font-size:8px;font-weight:800;letter-spacing:2px;color:#15803d;background:#f0fdf4;border:1px solid #86efac;border-radius:6px;padding:10px 6px;transform:rotate(180deg)">WWTP</div>
      </div>

      <!-- COD -->
      <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
        <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#dc2626">COD</div>
        <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
          <span id="wwtp-cod-val" style="font-size:22px;font-weight:800;color:#b91c1c;font-family:'Cascadia Code','Consolas',monospace">472</span>
          <span style="font-size:9px;color:#fca5a5;font-weight:600">ppm</span>
        </div>
        <div style="margin-top:8px;background:#fee2e2;border-radius:99px;height:3px">
          <div id="wwtp-cod-bar" style="width:79%;background:#ef4444;border-radius:99px;height:3px;transition:width 1s ease"></div>
        </div>
      </div>

      <!-- BOD -->
      <div style="background:#fef9ee;border:1px solid #d1fae5;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
        <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#059669">BOD</div>
        <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
          <span id="wwtp-bod-val" style="font-size:22px;font-weight:800;color:#065f46;font-family:'Cascadia Code','Consolas',monospace">236</span>
          <span style="font-size:9px;color:#6ee7b7;font-weight:600">ppm</span>
        </div>
        <div style="margin-top:8px;background:#d1fae5;border-radius:99px;height:3px">
          <div id="wwtp-bod-bar" style="width:39%;background:#10b981;border-radius:99px;height:3px;transition:width 1s ease"></div>
        </div>
      </div>

      <!-- PH -->
      <div style="background:#fefce8;border:1px solid #fde68a;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
        <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#ca8a04">PH</div>
        <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
          <span id="wwtp-ph-val" style="font-size:22px;font-weight:800;color:#a16207;font-family:'Cascadia Code','Consolas',monospace">8.1</span>
        </div>
        <div style="margin-top:8px;background:#fef9c3;border-radius:99px;height:3px">
          <div id="wwtp-ph-bar" style="width:58%;background:#eab308;border-radius:99px;height:3px;transition:width 1s ease"></div>
        </div>
      </div>

      <!-- TDS -->
      <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:8px;padding:12px;display:flex;flex-direction:column;justify-content:space-between">
        <div style="font-size:8px;font-weight:700;letter-spacing:1px;color:#0284c7">TDS</div>
        <div style="display:flex;align-items:baseline;gap:3px;margin-top:6px">
          <span id="wwtp-tds-val" style="font-size:22px;font-weight:800;color:#0369a1;font-family:'Cascadia Code','Consolas',monospace">310</span>
          <span style="font-size:9px;color:#7dd3fc;font-weight:600">ppm</span>
        </div>
        <div style="margin-top:8px;background:#e0f2fe;border-radius:99px;height:3px">
          <div id="wwtp-tds-bar" style="width:52%;background:#0ea5e9;border-radius:99px;height:3px;transition:width 1s ease"></div>
        </div>
      </div>

    </div>
    <div style="margin-top:12px;display:flex;align-items:center;gap:6px">
      <div style="width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px rgba(34,197,94,.6)"></div>
      <span style="font-size:10px;font-weight:600;color:#16a34a">Monitoring</span>
      <span id="wwtp-live-time" style="margin-left:auto;font-size:10px;color:#94a3b8">Data statis</span>
    </div>
  </div>

  <!-- ══ DIESEL OIL — full width ══ -->
  <div class="s-card" style="--acc:#16a34a;grid-column:1/-1;position:relative">
    <div class="s-bar"></div>
    <button class="s-detail-btn" onclick="openSensorDetailModal('dieseloil')">Detail</button>
    <div class="s-label" style="font-size:11px;letter-spacing:1.5px;font-weight:700;color:#16a34a">DIESEL OIL</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:12px;align-items:stretch">

      <!-- TANK -->
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#16a34a">TANK</div>
        <div id="tank-body-diesel_tank" style="position:relative;width:100%;flex:1;min-height:110px;border:2px solid #86efac;border-radius:10px;overflow:hidden;background:#dcfce7">
          <div id="tank-water-diesel_tank" style="position:absolute;bottom:0;left:0;right:0;height:0%;background:linear-gradient(180deg,#4ade80,#16a34a);border-radius:0 0 8px 8px;transition:height 1.8s cubic-bezier(.34,1.2,.64,1)"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span id="tank-pct-diesel_tank" style="font-size:24px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4);filter:none;backface-visibility:hidden;-webkit-font-smoothing:antialiased">—%</span>
          </div>
          <div style="position:absolute;left:0;right:0;bottom:40%;height:1.5px;background:#eab308;opacity:.75;pointer-events:none"></div>
          <div style="position:absolute;left:0;right:0;bottom:15%;height:1.5px;background:#ef4444;opacity:.75;pointer-events:none"></div>
        </div>
        <div style="display:flex;gap:30px">
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
          <div style="width:6px;height:14px;background:#86efac;border-radius:0 0 4px 4px"></div>
        </div>
        <div id="tank-vol-diesel_tank" style="font-size:9px;color:#15803d;font-weight:600;text-align:center">3.900lt / 5.000lt</div>
        <div id="tank-cm-diesel_tank" style="font-size:8px;color:#94a3b8;text-align:center">— cm air</div>
        <div id="tank-offline-diesel_tank" style="display:none;align-items:center;gap:3px;padding:2px 7px;border-radius:20px;background:#f1f5f9;border:1px solid #e2e8f0;font-size:8px;font-weight:700;color:#94a3b8;letter-spacing:.5px">
          <span style="width:5px;height:5px;border-radius:50%;background:#94a3b8;display:inline-block"></span>OFFLINE
        </div>
        <div style="width:100%;background:#bbf7d0;border-radius:99px;height:5px">
          <div id="tank-bar-diesel_tank" style="width:0%;background:#22c55e;border-radius:99px;height:5px;transition:width 1.8s ease"></div>
        </div>
      </div>

      <!-- GENSET + TANK GENSET -->
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:10px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#15803d">GENSET</div>
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:10px 14px;display:flex;align-items:center;gap:10px">
          <div style="font-size:28px">⚡</div>
          <div>
            <div style="font-size:10px;font-weight:700;color:#15803d">STATUS</div>
            <div id="genset-status-val" style="font-size:14px;font-weight:800;color:#16a34a">STANDBY</div>
          </div>
        </div>
        <div style="font-size:9px;font-weight:700;letter-spacing:1px;color:#15803d;margin-top:4px">TANK GENSET</div>
        <div id="tank-body-diesel_genset" style="position:relative;width:100%;height:70px;border:2px solid #86efac;border-radius:10px;overflow:hidden;background:#dcfce7">
          <div id="tank-water-diesel_genset" style="position:absolute;bottom:0;left:0;right:0;height:0%;background:linear-gradient(180deg,#4ade80,#16a34a);border-radius:0 0 8px 8px;transition:height 1.8s cubic-bezier(.34,1.2,.64,1)"></div>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
            <span id="tank-pct-diesel_genset" style="font-size:18px;font-weight:800;color:white;text-shadow:0 1px 3px rgba(0,0,0,.4);filter:none;backface-visibility:hidden;-webkit-font-smoothing:antialiased">—%</span>
          </div>
          <div style="position:absolute;left:0;right:0;bottom:40%;height:1.5px;background:#eab308;opacity:.75;pointer-events:none"></div>
          <div style="position:absolute;left:0;right:0;bottom:15%;height:1.5px;background:#ef4444;opacity:.75;pointer-events:none"></div>
        </div>
        <div id="tank-vol-diesel_genset" style="font-size:9px;color:#15803d;font-weight:600;text-align:center">310lt / 500lt</div>
        <div id="tank-cm-diesel_genset" style="font-size:8px;color:#94a3b8;text-align:center">— cm</div>
        <div id="tank-offline-diesel_genset" style="display:none;align-items:center;gap:3px;padding:2px 7px;border-radius:20px;background:#f1f5f9;border:1px solid #e2e8f0;font-size:8px;font-weight:700;color:#94a3b8;letter-spacing:.5px">
          <span style="width:5px;height:5px;border-radius:50%;background:#94a3b8;display:inline-block"></span>OFFLINE
        </div>
        <div style="width:100%;background:#bbf7d0;border-radius:99px;height:4px">
          <div id="tank-bar-diesel_genset" style="width:0%;background:#22c55e;border-radius:99px;height:4px;transition:width 1.8s ease"></div>
        </div>
      </div>

    </div>
    <div style="margin-top:12px;display:flex;align-items:center;gap:6px">
      <div style="width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px rgba(34,197,94,.6)"></div>
      <span style="font-size:10px;font-weight:600;color:#16a34a">Monitoring</span>
      <span id="diesel-live-time" style="margin-left:auto;font-size:10px;color:#94a3b8">Data statis</span>
    </div>
  </div>


  </div>
`;
}

// ══ SENSOR DETAIL MODAL ════════════════════════════
function openSensorDetailModal(sensorType) {
  const modalId = 'sensor-detail-modal-' + sensorType;
  let modal = document.getElementById(modalId);
  if (modal) { modal.remove(); }

  const sensorData = {
    treatwater2: {
      title: 'TREAT WATER 2 — Detail Data',
      color: '#8b5cf6',
      tanks: ['tanu_edi', 'feed_edi'],
      params: ['TDS', 'HARDNESS', 'PH', 'ALKALINE'],
      recordColumns: ['TANU EDI (CM AIR)', 'FEED EDI (CM AIR)']
    },
    treatwater1: {
      title: 'TREAT WATER 1 — Detail Data',
      color: '#6366f1',
      tanks: ['slury_1', 'slury_2', 'feed_slury'],
      params: ['TDS', 'HARDNESS', 'PH', 'ALKALINE'],
      recordColumns: ['SLURY 1 (CM AIR)', 'SLURY 2 (CM AIR)', 'FEED SLURY (CM AIR)']
    },
    filterwater: {
      title: 'FILTER WATER — Detail Data',
      color: '#0ea5e9',
      tanks: ['air_proses', 'ground_tank_a'],
      params: ['TDS', 'HARDNESS', 'PH', 'ALKALINE'],
      recordColumns: ['AIR PROSES (CM AIR)', 'GROUND TANK A (CM AIR)']
    },
    wwtp: {
      title: 'WWTP / LIMBAH — Detail Data',
      color: '#16a34a',
      tanks: ['ground_tank_b'],
      params: ['COD', 'BOD'],
      recordColumns: ['GROUND TANK B (CM AIR)']
    },
    dieseloil: {
      title: 'DIESEL OIL — Detail Data',
      color: '#16a34a',
      tanks: ['diesel_tank', 'diesel_genset'],
      params: [],
      recordColumns: ['DIESEL TANK (CM AIR)', 'DIESEL GENSET (CM AIR)']
    }
  };

  const info = sensorData[sensorType] || sensorData.treatwater2;

  // Buat modal wrapper
  modal = document.createElement('div');
  modal.id = modalId;
  modal.style.cssText = `
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,.4);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10000;
  `;

  // Buat konten modal
  const content = document.createElement('div');
  content.style.cssText = `
    background: white;
    border-radius: 12px;
    box-shadow: 0 20px 60px rgba(0,0,0,.3);
    max-width: 900px;
    width: 95vw;
    max-height: 85vh;
    overflow-y: auto;
    animation: modalSlideIn .3s cubic-bezier(.34,1.2,.64,1);
  `;

  // Header
  let headerHTML = `
    <div style="background: ${info.color}; color: white; padding: 16px 20px; border-radius: 12px 12px 0 0; display: flex; align-items: center; justify-content: space-between;">
      <h2 style="margin: 0; font-size: 14px; font-weight: 700; letter-spacing: 0.5px;">${info.title}</h2>
      <button onclick="document.getElementById('${modalId}').remove()" style="background: rgba(255,255,255,.2); border: none; color: white; width: 28px; height: 28px; border-radius: 6px; cursor: pointer; font-size: 16px; display: grid; place-items: center;">×</button>
    </div>`;

  // Body dengan data tank
  let bodyHTML = '<div style="padding: 20px; font-family: var(--font-sans);">';
  
  // Tampilkan data tank current
  bodyHTML += '<div style="margin-bottom: 20px;">';
  bodyHTML += '<h3 style="font-size: 11px; font-weight: 700; color: var(--txt3); text-transform: uppercase; letter-spacing: 0.8px; margin: 0 0 12px 0;">Current Water Level</h3>';
  
  info.tanks.forEach(tankId => {
    const pctEl = document.getElementById('tank-pct-' + tankId);
    const volEl = document.getElementById('tank-vol-' + tankId);
    const cmEl = document.getElementById('tank-cm-' + tankId);
    const pct = pctEl ? pctEl.textContent : '—';
    const vol = volEl ? volEl.textContent : '—';
    const cm = cmEl ? cmEl.textContent : '—';
    
    bodyHTML += `
      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px 14px; margin-bottom: 12px;">
        <div style="font-size: 11px; font-weight: 700; color: var(--txt3); text-transform: uppercase; letter-spacing: 0.8px; margin-bottom: 8px;">${tankId.toUpperCase()}</div>
        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px;">
          <div>
            <div style="font-size: 9px; color: var(--txt3); margin-bottom: 3px;">Level</div>
            <div style="font-size: 18px; font-weight: 800; color: ${info.color}; font-family: 'DM Mono', monospace;">${pct}</div>
          </div>
          <div>
            <div style="font-size: 9px; color: var(--txt3); margin-bottom: 3px;">Volume</div>
            <div style="font-size: 11px; font-weight: 700; color: var(--txt2); font-family: 'DM Mono', monospace;">${vol}</div>
          </div>
          <div>
            <div style="font-size: 9px; color: var(--txt3); margin-bottom: 3px;">Height (cm)</div>
            <div style="font-size: 11px; font-weight: 700; color: var(--txt2); font-family: 'DM Mono', monospace;">${cm}</div>
          </div>
        </div>
      </div>`;
  });
  
  bodyHTML += '</div>';

  // Tampilkan parameter kalau ada
  if (info.params.length > 0) {
    bodyHTML += `<div style="margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid #e2e8f0;">
      <h3 style="font-size: 11px; font-weight: 700; color: var(--txt3); text-transform: uppercase; letter-spacing: 0.8px; margin: 0 0 12px 0;">Parameter Monitoring</h3>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">`;
    
    info.params.forEach(param => {
      const paramKey = param.toLowerCase().replace(/\s+/g, '_');
      const paramEl = document.querySelector(`[id*="${paramKey}"][id*="-val"]`);
      const paramVal = paramEl ? paramEl.textContent : '—';
      bodyHTML += `
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; text-align: center;">
          <div style="font-size: 9px; font-weight: 700; color: var(--txt3); margin-bottom: 6px;">${param}</div>
          <div style="font-size: 16px; font-weight: 800; color: ${info.color}; font-family: 'DM Mono', monospace;">${paramVal}</div>
        </div>`;
    });
    bodyHTML += '</div></div>';
  }

  // Recent Records Table (History Data)
  bodyHTML += `
    <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #e2e8f0;">
      <h3 style="font-size: 11px; font-weight: 700; color: var(--txt3); text-transform: uppercase; letter-spacing: 0.8px; margin: 0 0 10px 0;">Recent Records (10)</h3>
      <div style="overflow-x: auto; border-radius: 8px; border: 1px solid #e2e8f0;">
        <table style="width: 100%; border-collapse: collapse; font-size: 11px; font-family: 'DM Mono', monospace;">
          <thead>
            <tr style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
              <th style="padding: 8px 10px; text-align: left; font-weight: 700; color: var(--txt3); white-space: nowrap; border-right: 1px solid #e2e8f0;">ID</th>
              <th style="padding: 8px 10px; text-align: center; font-weight: 700; color: var(--txt3); white-space: nowrap; border-right: 1px solid #e2e8f0;">WAKTU</th>`;
  
  // Add column headers
  info.recordColumns.forEach(colName => {
    bodyHTML += `<th style="padding: 8px 10px; text-align: center; font-weight: 700; color: var(--txt3); white-space: nowrap; border-right: 1px solid #e2e8f0;">${colName}</th>`;
  });
  
  bodyHTML += `
            </tr>
          </thead>
          <tbody>`;
  
  // Generate dummy recent records (in real app, fetch from API)
  // Gunakan waktu dari last water level data jika ada
  const lastDataTime = window._lastWLData?.created_at ? new Date(window._lastWLData.created_at) : new Date();
  console.log('📋 Last Water Level Data Time:', lastDataTime);
  
  for (let i = 0; i < 10; i++) {
    const recordId = 210000 + i;
    
    // Generate time mundur ke belakang dari latest data (i*5 menit sebelumnya)
    const recordTime = new Date(lastDataTime.getTime() - (i * 5 * 60 * 1000)); // i*5 menit sebelumnya
    const hour = String(recordTime.getHours()).padStart(2, '0');
    const minute = String(recordTime.getMinutes()).padStart(2, '0');
    const second = String(recordTime.getSeconds()).padStart(2, '0');
    const date = String(recordTime.getDate()).padStart(2, '0');
    const month = String(recordTime.getMonth() + 1).padStart(2, '0');
    const year = recordTime.getFullYear();
    const time = `${date}/${month} ${hour}:${minute}:${second}`;
    
    bodyHTML += `<tr style="border-bottom: 1px solid #e2e8f0;">
      <td style="padding: 8px 10px; border-right: 1px solid #e2e8f0;">
        <span style="color: var(--blue); cursor: pointer; text-decoration: underline;">#${recordId}</span>
      </td>
      <td style="padding: 8px 10px; text-align: center; border-right: 1px solid #e2e8f0; color: var(--txt3); font-weight: 600; font-size: 10px;">${time}</td>`;
    
    // Add sensor heights (cm) for each tank
    info.recordColumns.forEach((col, idx) => {
      const height = Math.floor(Math.random() * 150) + 30; // Random 30-180 cm
      bodyHTML += `<td style="padding: 8px 10px; text-align: center; border-right: 1px solid #e2e8f0; color: var(--txt2);">${height}</td>`;
    });
    
    bodyHTML += `</tr>`;
  }
  
  bodyHTML += `
          </tbody>
        </table>
      </div>
    </div>
  `;

  // Footer dengan timestamp
  bodyHTML += `
    <div style="margin-top: 16px; padding-top: 12px; border-top: 1px solid #e2e8f0; font-size: 9px; color: var(--txt3);">
      <span>⏱ Last updated: <strong>${new Date().toLocaleTimeString('id-ID')}</strong></span>
      <span style="margin-left: 20px; opacity: 0.7;">Data auto-refresh setiap 5 detik</span>
    </div>
  </div>`;

  content.innerHTML = headerHTML + bodyHTML;
  modal.appendChild(content);
  document.body.appendChild(modal);

  // Close ketika klik di luar
  modal.addEventListener('click', (e) => {
    if (e.target === modal) { modal.remove(); }
  });

  // Close dengan Escape key
  const closeOnEscape = (e) => {
    if (e.key === 'Escape') { modal.remove(); document.removeEventListener('keydown', closeOnEscape); }
  };
  document.addEventListener('keydown', closeOnEscape);
}
window.openSensorDetailModal = openSensorDetailModal;