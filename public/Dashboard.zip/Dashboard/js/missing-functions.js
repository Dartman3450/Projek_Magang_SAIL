// ═══════════════════════════════════════════════════════════════
// MISSING FUNCTIONS — tambahkan ke file yang sesuai
// Semua fungsi ini hilang dan menyebabkan ReferenceError
// ═══════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────
// 1. FUNGSI UNTUK nav.js — setActive
// ─────────────────────────────────────────────────────────────
function setActive(el) {
  document.querySelectorAll('.nav-item, .nav-sub-item').forEach(n => n.classList.remove('active'));
  if (el) el.classList.add('active');
}
window.setActive = setActive;

// ─────────────────────────────────────────────────────────────
// 2. FUNGSI UNTUK reports.js — switchReportTab, changeReportSort,
//    clearDateFilters, getTabLabel
// ─────────────────────────────────────────────────────────────
function switchReportTab(tab, el) {
  _activeReportTab = tab;
  document.querySelectorAll('.report-tab').forEach(t => t.classList.remove('active'));
  if (el) el.classList.add('active');
  renderHarianReports();
}
window.switchReportTab = switchReportTab;

function changeReportSort(val) {
  _reportSortBy = val;
  renderHarianReports();
}
window.changeReportSort = changeReportSort;

function clearDateFilters() {
  const from = document.getElementById('report-date-from');
  const to   = document.getElementById('report-date-to');
  if (from) from.value = '';
  if (to)   to.value   = '';
  renderHarianReports();
}
window.clearDateFilters = clearDateFilters;

function getTabLabel(tab) {
  const labels = { lab: 'Laboratorium', utility: 'Utility', limbah: 'Limbah' };
  return labels[tab] || tab;
}
window.getTabLabel = getTabLabel;

// ─────────────────────────────────────────────────────────────
// 3. FUNGSI UNTUK surat-jalan.js — editSuratJalan, deleteSuratJalan
// ─────────────────────────────────────────────────────────────
function editSuratJalan(idx) {
  openSuratJalanForm(idx);
}
window.editSuratJalan = editSuratJalan;

function deleteSuratJalan(idx) {
  if (!confirm('Hapus surat jalan ini?')) return;
  const data = gSJ();

  // Hapus auto-debit kartu stok jika ada
  if (typeof gSCTxn === 'function' && typeof sSCTxn === 'function') {
    const sj = data[idx];
    const autoIds = sj?._autoDebitIds || [];
    if (autoIds.length) {
      const txns = gSCTxn().filter(t => !autoIds.includes(t.id));
      sSCTxn(txns);
    }
  }

  data.splice(idx, 1);
  sSJ(data);
  renderSuratJalan();
}
window.deleteSuratJalan = deleteSuratJalan;

// ─────────────────────────────────────────────────────────────
// 4. FUNGSI UNTUK surat-jalan.js — checkVacuum, handlePhotoUpload
//    (placeholder — di-assign ke window tapi tidak pernah dibuat)
// ─────────────────────────────────────────────────────────────
function checkVacuum() {
  // placeholder — belum diimplementasi
}
window.checkVacuum = checkVacuum;

function handlePhotoUpload(input, key) {
  const file = input?.files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const preview = document.getElementById(key + '-photo-preview');
    if (preview) {
      preview.src = e.target.result;
      preview.style.display = 'block';
    }
  };
  reader.readAsDataURL(file);
}
window.handlePhotoUpload = handlePhotoUpload;

// ─────────────────────────────────────────────────────────────
// 5. FUNGSI UNTUK data-entry.js — initDataEntryForm, submitLimbah,
//    buildPhotoUpload, showQuickToast
// ─────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────
// 6. OVERRIDE calcLimbahTotal — fix readOnly tidak mau diisi
// ─────────────────────────────────────────────────────────────
function calcLimbahTotal(key) {
  const volEl   = document.getElementById(key + '-vol');
  const awalEl  = document.getElementById(key + '-awal');
  const akhirEl = document.getElementById(key + '-akhir');
  if (!volEl || !awalEl || !akhirEl) return;

  const awalStr  = awalEl.value  || '';
  const akhirStr = akhirEl.value || '';

  if (awalStr !== '' || akhirStr !== '') {
    const awal  = parseFloat(awalStr)  || 0;
    const akhir = parseFloat(akhirStr) || 0;
    const total = akhir - awal;
    // Force override readOnly dan semua CSS inline
    volEl.removeAttribute('readonly');
    volEl.value = total.toFixed(2);
    volEl.setAttribute('readonly', 'true');
    volEl.style.cssText = 'background:#f0f7ff !important;color:var(--blue);font-weight:700;border-color:#bae6fd;cursor:not-allowed;';
  } else {
    volEl.removeAttribute('readonly');
    volEl.value = '';
    volEl.setAttribute('readonly', 'true');
    volEl.style.cssText = 'background:#f3f4f6;color:var(--txt3);font-weight:normal;';
  }
}
window.calcLimbahTotal = calcLimbahTotal;

// ─────────────────────────────────────────────────────────────
// 7. OVERRIDE submitLimbah — setelah save, awal/akhir/vol TIDAK dihapus
// ─────────────────────────────────────────────────────────────
function resetDEAfterSave(key) {
  // Kosongkan hanya field yang tidak perlu dipertahankan
  ['cod','bod','tss','ph','temp','notes',
   'steam','fgtemp','fwtemp','airp','sout','cond','sbd'].forEach(f => {
    const el = document.getElementById(key + '-' + f); if (el) el.value = '';
  });
  // Reload dari DB agar Awal/Akhir/Total tetap tampil (mode minimal — tidak timpa field yang baru dikosongkan)
  if (key === 'limbah') _loadLastLimbahFromDB(key, 'minimal');
}
window.resetDEAfterSave = resetDEAfterSave;

function initDataEntryForm(key) {
  const dateEl = document.getElementById(key + '-date');
  if (dateEl && !dateEl.value) dateEl.value = new Date().toISOString().split('T')[0];

  const dtEl = document.getElementById('de-dt-' + key);
  if (dtEl) dtEl.textContent = new Date().toLocaleString('id-ID');

  if (key === 'limbah') {
    const sel = document.getElementById('limbah-proj-sel');
    if (sel) {
      const projs = gPJ('ongoing');
      sel.innerHTML = '<option value="">-- Tidak ditautkan ke project (Simpan ke Laporan Harian) --</option>';
      projs.forEach((p, i) => {
        sel.innerHTML += `<option value="${i}">${p.name}</option>`;
      });

      // Saat ganti project → kosongkan form lalu load data project itu
      sel.onchange = () => {
        // Reset semua field dulu
        ['awal','akhir','vol','cod','bod','tss','ph','notes'].forEach(f => {
          const el = document.getElementById(key + '-' + f);
          if (el) { el.removeAttribute('readonly'); el.value = ''; }
        });
        // Reset vol ke readOnly lagi kalau ada project
        const volEl = document.getElementById(key + '-vol');
        toggleLimbahVolumeMode(key);
        calcLimbahTotal(key);
        // Load data project/harian yang dipilih
        _loadLastLimbahFromDB(key, 'full');
      };

      // Load data terakhir saat form pertama dibuka
      _loadLastLimbahFromDB(key, 'full');
    }
    toggleLimbahVolumeMode(key);
  }
}
window.initDataEntryForm = initDataEntryForm;

// Load data limbah terakhir dari DB dan pre-fill form
// mode: 'full' = isi semua field, 'minimal' = hanya awal/akhir/vol/project
async function _loadLastLimbahFromDB(key, mode = 'full') {
  try {
    const today = new Date().toISOString().split('T')[0];

    // Ambil project yang sedang dipilih di dropdown
    const sel      = document.getElementById('limbah-proj-sel');
    const projIdx  = sel?.value ?? '';
    const projs    = gPJ('ongoing');
    const projName = projIdx !== '' ? (projs[+projIdx]?.name || null) : null;

    // Filter by tanggal DAN project_name (atau tipe=harian jika tidak ada project)
    let url = `/api/dataentry/limbah?tanggal=${today}&limit=1`;
    if (projName) {
      url += `&project_name=${encodeURIComponent(projName)}`;
    } else {
      // Laporan harian — filter tipe=harian saja, tapi API belum support filter tipe
      // Kita ambil semua hari ini lalu filter manual
    }

    const res  = await fetch(url);
    const json = await res.json();
    if (!json.success || !json.data?.length) return;

    // Filter manual: pastikan project_name cocok
    const rows = json.data.filter(r => {
      if (projName) return r.project_name === projName;
      return !r.project_name || r.tipe === 'harian';
    });
    if (!rows.length) return;

    const last = rows[0];

    const fill = (id, val) => {
      const el = document.getElementById(id);
      if (el && val != null && val !== '') el.value = val;
    };

    fill(key + '-date',  last.tanggal);
    fill(key + '-awal',  last.awal);
    fill(key + '-akhir', last.akhir);

    if (mode === 'full') {
      fill(key + '-cod',   last.cod);
      fill(key + '-bod',   last.bod);
      fill(key + '-tss',   last.tss);
      fill(key + '-ph',    last.ph);
      fill(key + '-notes', last.notes);
    }

    // Tampilkan field awal/akhir dan hitung total
    if (last.awal != null || last.akhir != null) {
      const awalWrap  = document.getElementById(key + '-awal-wrap');
      const akhirWrap = document.getElementById(key + '-akhir-wrap');
      if (awalWrap)  awalWrap.style.display  = '';
      if (akhirWrap) akhirWrap.style.display = '';
      calcLimbahTotal(key);
    } else if (last.volume != null) {
      const volEl = document.getElementById(key + '-vol');
      if (volEl) { volEl.removeAttribute('readonly'); volEl.value = last.volume; }
    }

    if (mode === 'full') {
      showDESt(key, 'success', `✅ Data terakhir dimuat: ${last.tanggal}${projName ? ' — ' + projName : ''}`);
      setTimeout(() => {
        const bar = document.getElementById(key + '-sb');
        if (bar) bar.style.display = 'none';
      }, 2000);
    }

  } catch (err) {
    console.warn('_loadLastLimbahFromDB:', err.message);
  }
}
window._loadLastLimbahFromDB = _loadLastLimbahFromDB;

async function submitLimbah(key) {
  const g = id => document.getElementById(id)?.value?.trim() ?? '';
  const date    = g(key + '-date');
  const awal    = g(key + '-awal');
  const akhir   = g(key + '-akhir');
  const vol     = g(key + '-vol');
  const cod     = g(key + '-cod');
  const bod     = g(key + '-bod');
  const tss     = g(key + '-tss');
  const ph      = g(key + '-ph');
  const notes   = g(key + '-notes');

  const projSel  = document.getElementById('limbah-proj-sel');
  const projIdx  = projSel?.value ?? '';
  const projs    = gPJ('ongoing');
  const projName = projIdx !== '' ? (projs[+projIdx]?.name || null) : null;

  if (!date) { showDESt(key, 'error', '❌ Tanggal wajib diisi!'); return; }

  showDESt(key, 'loading', '⏳ Menyimpan data...');

  try {
    // Ambil data Jar Test jika ada (disimpan sementara di window._tmpJar)
    const jar = window._tmpJar || null;

    const body = {
      tanggal:      date,
      project_name: projName,
      tipe:         projName ? 'project' : 'harian',
      awal:         awal  || null,
      akhir:        akhir || null,
      vol_m3:       vol   || null,
      cod:          cod   || null,
      bod:          bod   || null,
      tss:          tss   || null,
      ph:           ph    || null,
      notes:        notes || null,
      jar_alum:     jar ? (Number(jar.alum)  || null) : null,
      jar_total:    jar ? (Number(jar.total) || null) : null,
    };

    const fetchRes = await fetch('/api/dataentry/limbah', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(body),
    });
    const json = await fetchRes.json();
    if (!json.success) throw new Error(json.error || 'Gagal simpan');

    showDESt(key, 'success', '✅ Data limbah berhasil disimpan!' + (jar ? ' (+ Jar Test ✅)' : ''));
    window._tmpJar = null; // Clear jar data setelah berhasil disimpan

    // Kosongkan hanya COD/BOD/TSS/pH/Notes
    ['cod','bod','tss','ph','temp','notes'].forEach(f => {
      const el = document.getElementById(key + '-' + f); if (el) el.value = '';
    });
    
    // Reset badge Jar Test jika ada
    const jarBadge = document.getElementById(key + '-jar-badge');
    if (jarBadge) jarBadge.textContent = '';

    // Reload Awal/Akhir/Total dari DB sesuai project yang dipilih
    // Pakai sedikit delay agar DB commit selesai dulu
    setTimeout(() => _loadLastLimbahFromDB(key, 'minimal'), 400);

  } catch (err) {
    console.error('submitLimbah error:', err);
    showDESt(key, 'error', '❌ Gagal: ' + err.message);
  }
}
window.submitLimbah = submitLimbah;

function showDESt(key, type, msg) {
  const bar = document.getElementById(key + '-sb');
  const txt = document.getElementById(key + '-sm');
  if (!bar || !txt) return;
  bar.style.display = 'flex';
  bar.className = 'de-status-bar de-status-' + type;
  txt.textContent = msg;
  if (type === 'success') setTimeout(() => { bar.style.display = 'none'; }, 3500);
}
window.showDESt = showDESt;

function buildPhotoUpload(key) {
  return `
    <div class="de-field de-full">
      <label class="de-label" style="color:#111;">FOTO (opsional)</label>
      <input type="file" accept="image/*" class="de-input" style="padding:6px;"
        onchange="handlePhotoUpload(this, '${key}')">
      <img id="${key}-photo-preview" src="" alt="preview"
        style="display:none;margin-top:8px;max-width:200px;border-radius:8px;border:1px solid var(--border)">
    </div>`;
}
window.buildPhotoUpload = buildPhotoUpload;

function showQuickToast(msg) {
  let toast = document.getElementById('_quick_toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = '_quick_toast';
    toast.style.cssText = `
      position:fixed;bottom:24px;right:24px;z-index:99999;
      background:#1e293b;color:#fff;padding:12px 20px;
      border-radius:10px;font-size:13px;font-weight:600;
      box-shadow:0 4px 20px rgba(0,0,0,.3);
      transition:opacity .3s;pointer-events:none;`;
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.style.opacity = '1';
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => { toast.style.opacity = '0'; }, 2800);
}
window.showQuickToast = showQuickToast;