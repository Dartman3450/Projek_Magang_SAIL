// ══════════════════════════════════════════════════════════════════
//  ORGANOLEPTIC TEST PANEL — js/organoleptic.js
//  v2.0 — Multi-attribute, cross-device, category-aware
//  API endpoint required: /api/organoleptic (GET, POST, PUT /:id, DELETE /:id)
//  Falls back to localStorage if API unavailable
// ══════════════════════════════════════════════════════════════════

// ── Storage Layer (API-first, localStorage fallback) ────────────────
const ORG_LS_KEY = 'organoleptic_tests_v2';
const ORG_CAT_KEY = 'org_custom_categories';
const ORG_DEL_CAT_KEY = 'org_deleted_default_categories';
let _orgUseAPI = true;  // will be set false if API 404s

async function orgApiCall(path = '', method = 'GET', body = null) {
  try {
    const opts = { method, headers: { 'Content-Type': 'application/json' } };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch('/api/organoleptic' + path, opts);
    if (res.status === 404 || res.status === 501) { _orgUseAPI = false; return null; }
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  } catch (e) {
    _orgUseAPI = false;
    return null;
  }
}

async function orgGetAll() {
  if (_orgUseAPI) {
    const data = await orgApiCall();
    if (data && Array.isArray(data)) return data;
  }
  try { return JSON.parse(localStorage.getItem(ORG_LS_KEY) || '[]'); }
  catch { return []; }
}

async function orgSave(test) {
  if (_orgUseAPI) {
    const res = test._id
      ? await orgApiCall('/' + test._id, 'PUT', test)
      : await orgApiCall('', 'POST', test);
    if (res) return res;
  }
  // localStorage fallback
  const all = JSON.parse(localStorage.getItem(ORG_LS_KEY) || '[]');
  if (test._id) {
    const i = all.findIndex(t => t._id === test._id);
    if (i >= 0) all[i] = test; else all.push(test);
  } else {
    test._id = 'local_' + Date.now();
    all.push(test);
  }
  localStorage.setItem(ORG_LS_KEY, JSON.stringify(all));
  return test;
}

async function orgDelete(id) {
  if (_orgUseAPI) await orgApiCall('/' + id, 'DELETE');
  const all = JSON.parse(localStorage.getItem(ORG_LS_KEY) || '[]');
  localStorage.setItem(ORG_LS_KEY, JSON.stringify(all.filter(t => t._id !== id)));
}

// ── Category Definitions ────────────────────────────────────────────
const ORG_DEFAULT_CATS = [
  { value: 'teh-hijau',       label: '🍵 Teh Hijau',                  type: 'teh' },
  { value: 'oolong',          label: '🍵 Oolong',                      type: 'teh' },
  { value: 'black-tea',       label: '🍵 Black Tea',                   type: 'teh' },
  { value: 'roasted-jasmine', label: '🍵 Roasted Green Tea Jasmine',   type: 'teh' },
  { value: 'robusta',         label: '☕ Kopi Robusta',                 type: 'kopi' },
  { value: 'arabika',         label: '☕ Kopi Arabika',                 type: 'kopi' },
];

function orgGetCats() {
  const deleted = JSON.parse(localStorage.getItem(ORG_DEL_CAT_KEY) || '[]');
  const custom  = JSON.parse(localStorage.getItem(ORG_CAT_KEY) || '[]');
  return [
    ...ORG_DEFAULT_CATS.filter(c => !deleted.includes(c.value)),
    ...custom,
  ];
}

function orgGetCatType(value) {
  const all = orgGetCats();
  return (all.find(c => c.value === value) || {}).type || 'kopi';
}

function orgGetCatLabel(value) {
  const all = orgGetCats();
  return (all.find(c => c.value === value) || { label: value }).label;
}

// ── Attribute Definitions ───────────────────────────────────────────
const ORG_ATTRS = {
  kopi: [
    { key: 'bitterness', label: 'Bitterness', icon: '☕', hint: 'Tingkat kepahitan' },
    { key: 'sweet',      label: 'Sweet',       icon: '🍬', hint: 'Tingkat kemanisan' },
    { key: 'sour',       label: 'Sour',        icon: '🍋', hint: 'Tingkat keasaman' },
    { key: 'body',       label: 'Body',        icon: '💪', hint: 'Kekentalan & tekstur' },
    { key: 'aroma',      label: 'Aroma',       icon: '👃', hint: 'Intensitas aroma' },
    { key: 'overall',    label: 'Overall',     icon: '⭐', hint: 'Kesan keseluruhan' },
  ],
  teh: [
    { key: 'flavourAroma', label: 'Flavour Aroma',   icon: '🌸', hint: 'Intensitas aroma rasa',  header: 'Aroma' },
    { key: 'smokyAroma',   label: 'Smoky Aroma',     icon: '💨', hint: 'Intensitas aroma asap',  header: 'Aroma' },
    { key: 'rasa',         label: 'Rasa',            icon: '', hint: 'Penilaian rasa teh',     header: 'Rasa' },
    { key: 'astringent',   label: 'Level Astringent',icon: '🌿', hint: 'Tingkat sepet/astringen', header: 'Level Astringent' },
  ],
};

// ── Sample Number Generator ─────────────────────────────────────────
function orgGenSampleNo(all) {
  const now    = new Date();
  const dd     = String(now.getDate()).padStart(2, '0');
  const mm     = String(now.getMonth() + 1).padStart(2, '0');
  const yyyy   = now.getFullYear();
  const suffix = `${dd}${mm}${yyyy}`;
  const today  = (all || []).filter(t => (t.sampleNo || '').endsWith('-' + suffix));
  const seq    = String(today.length + 1).padStart(3, '0');
  return `${seq}-${suffix}`;
}

// ── HTML Escape ─────────────────────────────────────────────────────
function orgEsc(str) {
  return String(str || '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ── Active tab ──────────────────────────────────────────────────────
let _orgTab = 'panel';
let _orgPollTimer = null;

// ══════════════════════════════════════════════════════════════════
//  1. MAIN PAGE HTML
// ══════════════════════════════════════════════════════════════════
function getOrganolepticHTML() {
  return `
<div class="de-wrap" id="org-wrap">

  <!-- Header -->
  <div class="de-header">
    <div>
      <h2 class="de-title">Organoleptic Test Panel</h2>
      <p class="de-sub">SAIL / QC / Organoleptic</p>
    </div>
    <button class="de-btn de-btn-primary" onclick="orgOpenAddModal()"
      style="display:flex;align-items:center;gap:8px;padding:10px 20px;font-size:13px;font-weight:700;white-space:nowrap;">
      ＋ Tambah Tes
    </button>
  </div>

  <!-- Sub-tabs -->
  <div style="display:flex;gap:0;margin-bottom:20px;border-bottom:2px solid var(--border);overflow-x:auto;">
    <button id="org-tab-panel"   class="org-tab active" onclick="orgSwitchTab('panel')">🧪 Tes Panel</button>
    <button id="org-tab-summary" class="org-tab"        onclick="orgSwitchTab('summary')">📊 Summary</button>
  </div>

  <div id="org-panel-content"><div id="org-panel-list"></div></div>
  <div id="org-summary-content" style="display:none;"><div id="org-summary-body"></div></div>

</div>

<style>
/* ── Tab ─────────────────────── */
.org-tab {
  padding: 10px 22px; background: transparent; border: none;
  border-bottom: 3px solid transparent; color: var(--txt3);
  font-size: 13px; font-weight: 700; cursor: pointer; transition: all .2s;
  white-space: nowrap; display: flex; align-items: center; gap: 6px; margin-bottom: -2px;
}
.org-tab:hover  { color:var(--txt); background:var(--surface); border-radius:8px 8px 0 0; }
.org-tab.active { color:var(--blue); border-bottom-color:var(--blue); background:var(--surface); border-radius:8px 8px 0 0; }

/* ── Card ────────────────────── */
.org-card {
  background:var(--surface); border:1px solid var(--border); border-radius:12px;
  padding:16px 18px; margin-bottom:12px; position:relative; transition:all .2s; overflow:hidden;
}
.org-card:hover { border-color:var(--blue); box-shadow:0 4px 16px rgba(43,125,233,.09); }
.org-card-accent { position:absolute;top:0;left:0;bottom:0;width:4px;border-radius:12px 0 0 12px; }
.org-card-header { display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:10px; }
.org-sample-name { font-size:15px;font-weight:800;color:var(--txt);line-height:1.2;margin-bottom:3px; }
.org-sample-no   { font-family:'DM Mono',monospace;font-size:10px;font-weight:700;color:var(--txt3);
                   background:var(--bg);border:1px solid var(--border);border-radius:5px;padding:2px 7px; }
.org-status-badge{ font-size:10px;font-weight:700;padding:3px 9px;border-radius:5px;white-space:nowrap; }
.org-progress-wrap{ background:var(--bg);border-radius:99px;height:5px;overflow:hidden;margin:8px 0 4px; }
.org-progress-bar { height:100%;border-radius:99px;transition:width .4s; }
.org-actions { display:flex;gap:8px;margin-top:10px;flex-wrap:wrap; }

/* ── Panel dots ──────────────── */
.org-dot-row { display:flex;gap:5px;flex-wrap:wrap;margin:6px 0; }
.org-dot {
  width:24px;height:24px;border-radius:50%;border:2px solid var(--border);
  background:var(--bg);display:flex;align-items:center;justify-content:center;
  font-size:9px;font-weight:700;color:var(--txt3);transition:all .2s;
}
.org-dot.done    { background:var(--green);border-color:var(--green);color:#fff; }
.org-dot.current { background:var(--blue);border-color:var(--blue);color:#fff;box-shadow:0 0 0 3px rgba(43,125,233,.2); }

/* ── Modal ───────────────────── */
.org-modal-overlay {
  position:fixed;inset:0;background:rgba(0,0,0,.52);display:flex;
  align-items:center;justify-content:center;z-index:9999;padding:16px;
  animation:orgFadeIn .15s ease;
}
@keyframes orgFadeIn  { from{opacity:0}   to{opacity:1} }
@keyframes orgSlideUp { from{transform:translateY(18px);opacity:0} to{transform:translateY(0);opacity:1} }
.org-modal {
  background:var(--surface);border-radius:16px;width:100%;max-width:480px;
  max-height:92vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.28);
  animation:orgSlideUp .2s ease;
}
.org-modal-lg { max-width:560px; }
.org-modal-head {
  display:flex;align-items:center;justify-content:space-between;
  padding:18px 22px 0;margin-bottom:16px;
}
.org-modal-title { font-size:16px;font-weight:800;color:var(--txt); }
.org-modal-close {
  width:30px;height:30px;border:none;background:var(--bg);border-radius:7px;
  cursor:pointer;font-size:15px;color:var(--txt3);display:flex;align-items:center;justify-content:center;
}
.org-modal-close:hover { background:var(--border);color:var(--txt); }
.org-modal-body { padding:0 22px 22px; }

/* ── Compact rating ──────────── */
.org-attr-block {
  background:var(--bg);border:1px solid var(--border);border-radius:10px;
  padding:12px 14px;margin-bottom:10px;
}
.org-attr-header {
  display:flex;align-items:center;gap:7px;margin-bottom:8px;
}
.org-attr-label { font-size:12px;font-weight:700;color:var(--txt); }
.org-attr-hint  { font-size:10px;color:var(--txt3);margin-left:auto; }
.org-rating-row-compact {
  display:flex;gap:4px;margin-bottom:8px;
}
.org-rb {
  flex:1;padding:6px 0;border:1.5px solid var(--border);border-radius:6px;
  background:var(--surface);font-size:11px;font-weight:700;color:var(--txt3);
  cursor:pointer;transition:all .12s;text-align:center;min-width:0;
}
.org-rb:hover   { border-color:var(--blue);background:#ebf2fd;color:var(--blue); }
.org-rb.sel     { border-color:var(--blue);background:var(--blue);color:#fff;
                  box-shadow:0 2px 8px rgba(43,125,233,.35); }
.org-rb.sel-red    { border-color:#ef4444;background:#ef4444;color:#fff; }
.org-rb.sel-orange { border-color:#f97316;background:#f97316;color:#fff; }
.org-rb.sel-yellow { border-color:#eab308;background:#eab308;color:#fff; }
.org-rb.sel-green  { border-color:#22c55e;background:#22c55e;color:#fff; }
.org-rb.sel-blue   { border-color:#3b82f6;background:#3b82f6;color:#fff; }
.org-rb.sel-purple { border-color:#8b5cf6;background:#8b5cf6;color:#fff; }
.org-notes-input {
  width:100%;box-sizing:border-box;border:1.5px solid var(--border);border-radius:7px;
  background:var(--surface);color:var(--txt);font-size:11px;padding:6px 10px;
  resize:vertical;min-height:48px;outline:none;transition:border-color .15s;
  font-family:inherit;
}
.org-notes-input:focus { border-color:var(--blue); }
.org-section-header {
  font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.8px;
  color:var(--txt3);margin:14px 0 8px;padding:0 2px;display:flex;align-items:center;gap:6px;
}
.org-section-header::after { content:'';flex:1;height:1px;background:var(--border); }

/* ── Summary card ────────────── */
.org-sum-card { background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:18px;margin-bottom:14px; }
.org-sum-title { font-size:14px;font-weight:800;color:var(--txt);margin-bottom:3px; }
.org-sum-meta  { font-size:10px;color:var(--txt3);margin-bottom:14px;font-family:'DM Mono',monospace; }
.org-sum-attr { margin-bottom:12px; }
.org-sum-attr-label { font-size:11px;font-weight:700;color:var(--txt2);margin-bottom:5px; }
.org-sum-bar-row { display:flex;align-items:center;gap:8px;margin-bottom:3px; }
.org-sum-bar-label { font-size:10px;color:var(--txt3);width:52px;text-align:right;flex-shrink:0; }
.org-sum-bar-wrap  { flex:1;background:var(--bg);border-radius:99px;height:8px;overflow:hidden; }
.org-sum-bar       { height:100%;border-radius:99px;transition:width .5s; }
.org-sum-bar-val   { font-size:10px;font-weight:700;color:var(--txt);width:36px;flex-shrink:0; }

/* ── Share chip ──────────────── */
.org-share-chip {
  display:inline-flex;align-items:center;gap:6px;padding:5px 12px;
  background:var(--bg);border:1px solid var(--border);border-radius:99px;
  font-size:11px;font-weight:700;color:var(--txt2);cursor:pointer;transition:.15s;
}
.org-share-chip:hover { background:var(--blue);color:#fff;border-color:var(--blue); }

/* ── Category manager ────────── */
.org-cat-row {
  display:flex;align-items:center;gap:6px;padding:5px 8px;border-radius:7px;
  font-size:12px;margin-bottom:4px;background:var(--bg);border:1px solid var(--border);
}
.org-cat-type-badge {
  font-size:9px;font-weight:700;padding:2px 6px;border-radius:99px;
}

/* ── Empty state ─────────────── */
.org-empty { text-align:center;padding:50px 20px;color:var(--txt3); }
.org-empty-ico { font-size:44px;margin-bottom:10px; }
.org-empty-txt { font-size:13px;font-weight:700; }
.org-empty-sub { font-size:11px;margin-top:4px; }

/* ── Status bar ──────────────── */
.org-sb { display:none;padding:9px 13px;border-radius:7px;margin-bottom:12px;font-size:12px;font-weight:600; }

/* ── Panelist entry page ─────── */
.org-entry-page {
  min-height:100vh;background:var(--bg);display:flex;flex-direction:column;
  align-items:center;justify-content:flex-start;padding:20px 16px 40px;
}
.org-entry-card {
  width:100%;max-width:480px;background:var(--surface);border-radius:16px;
  box-shadow:0 8px 32px rgba(0,0,0,.12);overflow:hidden;
}
.org-entry-header {
  background:var(--blue);color:#fff;padding:20px 22px;
}
.org-entry-body { padding:20px 22px; }

@media(max-width:400px){
  .org-rb { font-size:10px;padding:5px 0; }
  .org-modal-head { padding:14px 16px 0; }
  .org-modal-body { padding:0 16px 16px; }
}
</style>
`;
}
window.getOrganolepticHTML = getOrganolepticHTML;

// ══════════════════════════════════════════════════════════════════
//  2. INIT — detects ?panel_entry= param for cross-device
// ══════════════════════════════════════════════════════════════════
async function initOrganoleptic() {
  _orgTab = 'panel';
  orgRenderTab('panel');

  // Check for panelist entry URL param
  const params = new URLSearchParams(window.location.search);
  const entryId = params.get('panel_entry');
  if (entryId) {
    await orgOpenPanelistEntryPage(entryId);
    return;
  }

  await orgRenderPanelList();

  // Auto-poll every 15s for live cross-device updates
  if (_orgPollTimer) clearInterval(_orgPollTimer);
  _orgPollTimer = setInterval(async () => {
    if (_orgTab === 'panel') await orgRenderPanelList();
  }, 15000);
}
window.initOrganoleptic = initOrganoleptic;

// ══════════════════════════════════════════════════════════════════
//  3. TAB SWITCHING
// ══════════════════════════════════════════════════════════════════
async function orgSwitchTab(tab) {
  _orgTab = tab;
  orgRenderTab(tab);
  if (tab === 'panel')   await orgRenderPanelList();
  if (tab === 'summary') await orgRenderSummary();
}
window.orgSwitchTab = orgSwitchTab;

function orgRenderTab(active) {
  ['panel', 'summary'].forEach(t => {
    const btn = document.getElementById('org-tab-' + t);
    const con = document.getElementById('org-' + t + '-content');
    if (!btn || !con) return;
    btn.classList.toggle('active', t === active);
    con.style.display = t === active ? '' : 'none';
  });
}

// ══════════════════════════════════════════════════════════════════
//  4. RENDER PANEL LIST
// ══════════════════════════════════════════════════════════════════
async function orgRenderPanelList() {
  const container = document.getElementById('org-panel-list');
  if (!container) return;
  container.innerHTML = `<div style="text-align:center;padding:30px;color:var(--txt3);font-size:12px;">⏳ Memuat…</div>`;

  const all = await orgGetAll();
  if (!all.length) {
    container.innerHTML = `
      <div class="org-empty">
        <div class="org-empty-ico">🧪</div>
        <div class="org-empty-txt">Belum ada Tes Panel</div>
        <div class="org-empty-sub">Klik <b>＋ Tambah Tes</b> untuk memulai.</div>
      </div>`;
    return;
  }
  container.innerHTML = [...all].reverse().map(test => orgCardHTML(test)).join('');
}

function orgCardHTML(test) {
  const done      = (test.assessments || []).length;
  const total     = test.panelCount || 4;
  const completed = done >= total;
  const pct       = total > 0 ? Math.round((done / total) * 100) : 0;
  const catLabel  = orgGetCatLabel(test.category);
  const catType   = orgGetCatType(test.category);
  const catBadgeColor = catType === 'kopi' ? '#92400e' : '#166534';
  const catBadgeBg    = catType === 'kopi' ? '#fff7ed' : '#f0fdf4';

  const accentColor = completed ? 'var(--green)' : (done > 0 ? 'var(--orange)' : 'var(--border)');
  const statusBg    = completed ? '#f0fdf4' : (done > 0 ? '#fff7ed' : '#f8fafc');
  const statusColor = completed ? '#166534' : (done > 0 ? '#92400e' : '#555');
  const statusText  = completed ? '✅ Selesai' : (done > 0 ? `⏳ ${done}/${total}` : '🔴 Belum Diisi');
  const barColor    = completed ? 'var(--green)' : (done > 0 ? 'var(--orange)' : 'var(--border)');

  const dots = Array.from({ length: total }, (_, i) => {
    const n = i + 1;
    const isDone = (test.assessments || []).some(a => a.panelNo === n);
    return `<div class="org-dot ${isDone ? 'done' : ''}" title="Panel ${n}">${n}</div>`;
  }).join('');

  const shareUrl = `${window.location.origin}${window.location.pathname}?panel_entry=${test._id}`;

  return `
  <div class="org-card">
    <div class="org-card-accent" style="background:${accentColor};"></div>
    <div style="padding-left:8px;">
      <div class="org-card-header">
        <div>
          <div class="org-sample-name">${orgEsc(test.sampleName)}</div>
          <div style="font-size:11px;color:var(--txt3);margin-top:2px;">
            <span style="background:${catBadgeBg};color:${catBadgeColor};padding:2px 7px;border-radius:5px;font-size:10px;font-weight:700;">${orgEsc(catLabel)}</span>
            &nbsp;·&nbsp;👥 ${done}/${total} panelis
          </div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:5px;">
          <span class="org-sample-no">${orgEsc(test.sampleNo)}</span>
          <span class="org-status-badge" style="background:${statusBg};color:${statusColor};">${statusText}</span>
        </div>
      </div>

      <div class="org-progress-wrap">
        <div class="org-progress-bar" style="width:${pct}%;background:${barColor};"></div>
      </div>
      <div class="org-dot-row">${dots}</div>

      <div class="org-actions">
        ${!completed ? `
        <button class="de-btn de-btn-primary" onclick="orgOpenFillModal('${orgEsc(test._id)}')"
          style="font-size:12px;padding:7px 14px;gap:5px;">
          ✏️ Isi Penilaian
        </button>
        <span class="org-share-chip" onclick="orgCopyShareLink('${orgEsc(test._id)}', '${orgEsc(shareUrl)}')"
          title="Bagikan link ke panelis lain">
          🔗 Bagikan
        </span>` : `
        <button class="de-btn" onclick="orgSwitchTab('summary')"
          style="font-size:12px;padding:7px 14px;background:var(--bg);border-color:var(--green);color:#166534;">
          📊 Lihat Summary
        </button>`}
        <button class="de-btn" onclick="orgConfirmDelete('${orgEsc(test._id)}')"
          style="font-size:12px;padding:7px 12px;background:var(--bg);border-color:var(--border);color:var(--txt3);">
          🗑️
        </button>
      </div>
    </div>
  </div>`;
}

// ── Copy share link ─────────────────────────────────────────────────
function orgCopyShareLink(id, url) {
  navigator.clipboard?.writeText(url).then(() => {
    orgShowToast('🔗 Link disalin! Bagikan ke panelis lain.', '#1e40af');
  }).catch(() => {
    prompt('Salin link ini dan bagikan ke panelis:', url);
  });
}
window.orgCopyShareLink = orgCopyShareLink;

// ══════════════════════════════════════════════════════════════════
//  5. ADD TEST MODAL (with category management)
// ══════════════════════════════════════════════════════════════════
async function orgOpenAddModal() {
  document.getElementById('org-add-modal')?.remove();
  const all = await orgGetAll();
  const previewNo = orgGenSampleNo(all);
  const cats = orgGetCats();
  const catOptions = cats.map(c =>
    `<option value="${orgEsc(c.value)}">${orgEsc(c.label)}</option>`
  ).join('');

  const overlay = document.createElement('div');
  overlay.id = 'org-add-modal';
  overlay.className = 'org-modal-overlay';
  overlay.innerHTML = `
    <div class="org-modal org-modal-lg">
      <div class="org-modal-head">
        <div class="org-modal-title">➕ Tambah Tes Panel Baru</div>
        <button class="org-modal-close" onclick="document.getElementById('org-add-modal').remove()">✕</button>
      </div>
      <div class="org-modal-body">

        <!-- Sample No preview -->
        <div style="background:var(--bg);border:1px solid var(--border);border-radius:9px;padding:10px 14px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;">
          <div>
            <div style="font-size:9px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px;">No. Sample (Auto)</div>
            <div style="font-family:'DM Mono',monospace;font-size:15px;font-weight:800;color:var(--blue);">${previewNo}</div>
          </div>
          <span style="font-size:22px;">🔖</span>
        </div>

        <!-- Nama Sample -->
        <div style="margin-bottom:12px;">
          <label style="font-size:11px;font-weight:700;color:var(--txt2);text-transform:uppercase;letter-spacing:.4px;display:block;margin-bottom:5px;">NAMA SAMPLE <span style="color:var(--red)">*</span></label>
          <input class="de-input" type="text" id="org-add-name" placeholder="Contoh: Arabika Batch-07"
            style="width:100%;box-sizing:border-box;">
        </div>

        <!-- Kategori -->
        <div style="margin-bottom:6px;">
          <label style="font-size:11px;font-weight:700;color:var(--txt2);text-transform:uppercase;letter-spacing:.4px;display:block;margin-bottom:5px;">KATEGORI <span style="color:var(--red)">*</span></label>
          <select class="de-input de-select" id="org-add-cat" style="width:100%;box-sizing:border-box;" onchange="orgUpdateCatPreview()">
            <option value="">-- Pilih kategori --</option>
            ${catOptions}
          </select>
          <div id="org-cat-type-preview" style="margin-top:5px;font-size:11px;color:var(--txt3);"></div>
        </div>

        <!-- Category Manager -->
        <div style="margin-bottom:16px;">
          <button onclick="orgToggleCatManager()" style="font-size:11px;font-weight:600;color:var(--blue);background:none;border:none;cursor:pointer;padding:0;display:flex;align-items:center;gap:4px;">
            ⚙️ Kelola Kategori
          </button>
          <div id="org-cat-manager" style="display:none;margin-top:10px;border:1px solid var(--border);border-radius:9px;padding:12px;">
            <div style="font-size:11px;font-weight:700;color:var(--txt2);margin-bottom:8px;">Daftar Kategori</div>
            <div id="org-cat-list">${orgCatManagerHTML()}</div>
            <div style="display:flex;gap:6px;margin-top:10px;">
              <input class="de-input" type="text" id="org-new-cat-name" placeholder="Nama kategori baru…" style="flex:1;font-size:12px;padding:7px 10px;">
              <select class="de-input de-select" id="org-new-cat-type" style="font-size:12px;padding:7px 10px;">
                <option value="teh">Teh</option>
                <option value="kopi">Kopi</option>
              </select>
              <button class="de-btn de-btn-primary" onclick="orgAddCategory()" style="font-size:12px;padding:7px 12px;white-space:nowrap;">＋ Tambah</button>
            </div>
          </div>
        </div>

        <!-- Jumlah Panel -->
        <div style="margin-bottom:18px;">
          <label style="font-size:11px;font-weight:700;color:var(--txt2);text-transform:uppercase;letter-spacing:.4px;display:block;margin-bottom:5px;">JUMLAH PANELIS <span style="color:var(--red)">*</span></label>
          <input class="de-input" type="number" id="org-add-count" value="4" min="1" max="20"
            style="width:100%;box-sizing:border-box;">
          <div style="font-size:10px;color:var(--txt3);margin-top:3px;">💡 Sesi ditutup otomatis setelah semua panelis mengisi.</div>
        </div>

        <div id="org-add-sb" class="org-sb"></div>

        <div style="display:flex;gap:10px;justify-content:flex-end;">
          <button class="de-btn" onclick="document.getElementById('org-add-modal').remove()"
            style="padding:9px 18px;background:var(--bg);border-color:var(--border);color:var(--txt3);">Batal</button>
          <button class="de-btn de-btn-primary" onclick="orgSaveNewTest()" style="padding:9px 22px;font-weight:700;">💾 Buat Sesi</button>
        </div>

      </div>
    </div>`;
  document.body.appendChild(overlay);
  setTimeout(() => document.getElementById('org-add-name')?.focus(), 80);
}
window.orgOpenAddModal = orgOpenAddModal;

function orgUpdateCatPreview() {
  const val = document.getElementById('org-add-cat')?.value;
  const el  = document.getElementById('org-cat-type-preview');
  if (!el) return;
  if (!val) { el.textContent = ''; return; }
  const type = orgGetCatType(val);
  el.innerHTML = type === 'kopi'
    ? '<span style="background:#fff7ed;color:#92400e;padding:2px 8px;border-radius:99px;font-size:10px;font-weight:700;">☕ Kopi — akan menilai: Bitterness, Sweet, Sour, Body, Aroma, Overall</span>'
    : '<span style="background:#f0fdf4;color:#166534;padding:2px 8px;border-radius:99px;font-size:10px;font-weight:700;">🍵 Teh — akan menilai: Flavour Aroma, Smoky Aroma, Rasa, Astringent</span>';
}
window.orgUpdateCatPreview = orgUpdateCatPreview;

function orgCatManagerHTML() {
  const deleted = JSON.parse(localStorage.getItem(ORG_DEL_CAT_KEY) || '[]');
  const custom  = JSON.parse(localStorage.getItem(ORG_CAT_KEY) || '[]');
  let html = '';
  ORG_DEFAULT_CATS.forEach(c => {
    const isDeleted = deleted.includes(c.value);
    const color = c.type === 'kopi' ? '#92400e' : '#166534';
    const bg    = c.type === 'kopi' ? '#fff7ed' : '#f0fdf4';
    html += `<div class="org-cat-row" style="${isDeleted ? 'opacity:.4;' : ''}">
      <span style="flex:1;font-size:12px;${isDeleted ? 'text-decoration:line-through;' : ''}">${orgEsc(c.label)}</span>
      <span class="org-cat-type-badge" style="background:${bg};color:${color};">${c.type}</span>
      ${isDeleted
        ? `<button onclick="orgRestoreDefaultCat('${c.value}')" style="font-size:10px;background:var(--green);color:#fff;border:none;border-radius:4px;padding:2px 7px;cursor:pointer;">Pulihkan</button>`
        : `<button onclick="orgDeleteDefaultCat('${c.value}')" style="font-size:10px;background:var(--bg);color:var(--txt3);border:1px solid var(--border);border-radius:4px;padding:2px 7px;cursor:pointer;">🗑️</button>`
      }
    </div>`;
  });
  custom.forEach((c, i) => {
    const color = c.type === 'kopi' ? '#92400e' : '#166534';
    const bg    = c.type === 'kopi' ? '#fff7ed' : '#f0fdf4';
    html += `<div class="org-cat-row">
      <span style="flex:1;font-size:12px;">📌 ${orgEsc(c.label)}</span>
      <span class="org-cat-type-badge" style="background:${bg};color:${color};">${c.type}</span>
      <button onclick="orgDeleteCustomCat(${i})" style="font-size:10px;background:var(--bg);color:var(--txt3);border:1px solid var(--border);border-radius:4px;padding:2px 7px;cursor:pointer;">🗑️</button>
    </div>`;
  });
  return html || '<div style="font-size:11px;color:var(--txt3);">Tidak ada kategori.</div>';
}

function orgToggleCatManager() {
  const el = document.getElementById('org-cat-manager');
  if (el) el.style.display = el.style.display === 'none' ? '' : 'none';
}
window.orgToggleCatManager = orgToggleCatManager;

function orgDeleteDefaultCat(value) {
  const deleted = JSON.parse(localStorage.getItem(ORG_DEL_CAT_KEY) || '[]');
  if (!deleted.includes(value)) deleted.push(value);
  localStorage.setItem(ORG_DEL_CAT_KEY, JSON.stringify(deleted));
  orgRefreshCatManager();
}
window.orgDeleteDefaultCat = orgDeleteDefaultCat;

function orgRestoreDefaultCat(value) {
  const deleted = JSON.parse(localStorage.getItem(ORG_DEL_CAT_KEY) || '[]');
  localStorage.setItem(ORG_DEL_CAT_KEY, JSON.stringify(deleted.filter(v => v !== value)));
  orgRefreshCatManager();
}
window.orgRestoreDefaultCat = orgRestoreDefaultCat;

function orgDeleteCustomCat(idx) {
  const custom = JSON.parse(localStorage.getItem(ORG_CAT_KEY) || '[]');
  custom.splice(idx, 1);
  localStorage.setItem(ORG_CAT_KEY, JSON.stringify(custom));
  orgRefreshCatManager();
}
window.orgDeleteCustomCat = orgDeleteCustomCat;

function orgAddCategory() {
  const nameEl = document.getElementById('org-new-cat-name');
  const typeEl = document.getElementById('org-new-cat-type');
  const name   = nameEl?.value?.trim();
  const type   = typeEl?.value || 'teh';
  if (!name) { nameEl?.focus(); return; }
  const custom = JSON.parse(localStorage.getItem(ORG_CAT_KEY) || '[]');
  const icon   = type === 'kopi' ? '☕' : '🍵';
  custom.push({ value: 'custom_' + Date.now(), label: `${icon} ${name}`, type });
  localStorage.setItem(ORG_CAT_KEY, JSON.stringify(custom));
  if (nameEl) nameEl.value = '';
  orgRefreshCatManager();
}
window.orgAddCategory = orgAddCategory;

function orgRefreshCatManager() {
  const listEl = document.getElementById('org-cat-list');
  if (listEl) listEl.innerHTML = orgCatManagerHTML();
  // Refresh the category dropdown
  const sel  = document.getElementById('org-add-cat');
  const cats = orgGetCats();
  if (sel) {
    const curVal = sel.value;
    sel.innerHTML = '<option value="">-- Pilih kategori --</option>' +
      cats.map(c => `<option value="${orgEsc(c.value)}" ${curVal === c.value ? 'selected' : ''}>${orgEsc(c.label)}</option>`).join('');
  }
}

async function orgSaveNewTest() {
  const name  = document.getElementById('org-add-name')?.value?.trim();
  const cat   = document.getElementById('org-add-cat')?.value;
  const count = parseInt(document.getElementById('org-add-count')?.value);
  const sb    = document.getElementById('org-add-sb');

  if (!name)         { orgShowSb(sb, '⚠️ Nama sample wajib diisi.', '#fff7ed', '#92400e'); return; }
  if (!cat)          { orgShowSb(sb, '⚠️ Pilih kategori terlebih dahulu.', '#fff7ed', '#92400e'); return; }
  if (!count || count < 1) { orgShowSb(sb, '⚠️ Jumlah panelis minimal 1.', '#fff7ed', '#92400e'); return; }

  const all = await orgGetAll();
  const newTest = {
    sampleNo:    orgGenSampleNo(all),
    sampleName:  name,
    category:    cat,
    categoryType: orgGetCatType(cat),
    panelCount:  count,
    assessments: [],
    status:      'open',
    createdAt:   Date.now(),
  };

  orgShowSb(sb, '⏳ Menyimpan…', '#eff6ff', '#1e40af');
  const saved = await orgSave(newTest);
  if (!saved) { orgShowSb(sb, '❌ Gagal menyimpan. Coba lagi.', '#fef2f2', '#b91c1c'); return; }

  orgShowSb(sb, '✅ Sesi berhasil dibuat!', '#f0fdf4', '#166534');
  setTimeout(() => {
    document.getElementById('org-add-modal')?.remove();
    orgSwitchTab('panel');
  }, 600);
}
window.orgSaveNewTest = orgSaveNewTest;

// ══════════════════════════════════════════════════════════════════
//  6. FILL PENILAIAN MODAL (inline form, all attributes at once)
// ══════════════════════════════════════════════════════════════════
let _orgFillTestId  = null;
let _orgFillPanel   = 1;
let _orgFillRatings = {};   // { attrKey: { score, notes } }

async function orgOpenFillModal(testId) {
  const all  = await orgGetAll();
  const test = all.find(t => t._id === testId);
  if (!test) return;
  if ((test.assessments || []).length >= test.panelCount) {
    orgShowToast('✅ Semua panelis sudah mengisi.', '#166534'); return;
  }

  _orgFillTestId = testId;
  _orgFillRatings = {};

  // Next unfilled panel number
  const filledNos = (test.assessments || []).map(a => a.panelNo);
  let next = 1;
  for (let i = 1; i <= test.panelCount; i++) {
    if (!filledNos.includes(i)) { next = i; break; }
  }
  _orgFillPanel = next;

  orgRenderFillModal(test);
}
window.orgOpenFillModal = orgOpenFillModal;

function orgRenderFillModal(test) {
  document.getElementById('org-fill-modal')?.remove();
  const catType = test.categoryType || orgGetCatType(test.category);
  const attrs   = ORG_ATTRS[catType] || ORG_ATTRS.kopi;
  const done    = (test.assessments || []).length;
  const total   = test.panelCount;

  const overlay = document.createElement('div');
  overlay.id = 'org-fill-modal';
  overlay.className = 'org-modal-overlay';
  overlay.innerHTML = `
    <div class="org-modal org-modal-lg">
      <div class="org-modal-head">
        <div>
          <div class="org-modal-title">✏️ Penilaian Panel #${_orgFillPanel}</div>
          <div style="font-size:10px;color:var(--txt3);margin-top:2px;font-family:'DM Mono',monospace;">${orgEsc(test.sampleNo)} — ${orgEsc(test.sampleName)}</div>
        </div>
        <button class="org-modal-close" onclick="orgCloseFill()">✕</button>
      </div>
      <div class="org-modal-body">

        <!-- Progress -->
        <div style="background:var(--bg);border-radius:99px;height:4px;overflow:hidden;margin-bottom:6px;">
          <div style="height:100%;border-radius:99px;background:var(--blue);width:${Math.round((done/total)*100)}%;"></div>
        </div>
        <div style="font-size:10px;color:var(--txt3);text-align:right;margin-bottom:14px;font-family:'DM Mono',monospace;">${done}/${total} panelis</div>

        <!-- Panel ID -->
        <div style="background:linear-gradient(135deg,var(--blue),#3b82f6);color:#fff;border-radius:10px;padding:10px 14px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;">
          <div>
            <div style="font-size:9px;font-weight:700;opacity:.8;text-transform:uppercase;letter-spacing:.5px;">Penilaian oleh</div>
            <div style="font-size:16px;font-weight:800;">Panel #${_orgFillPanel}</div>
          </div>
          <span style="font-size:26px;">👤</span>
        </div>

        <!-- Attribute blocks -->
        ${orgBuildAttrBlocks(attrs, catType)}

        <div id="org-fill-sb" class="org-sb"></div>

        <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:4px;">
          <button class="de-btn" onclick="orgCloseFill()"
            style="padding:9px 18px;background:var(--bg);border-color:var(--border);color:var(--txt3);">Tutup</button>
          <button class="de-btn de-btn-primary" onclick="orgSubmitFill('${orgEsc(test._id)}')"
            style="padding:9px 22px;font-weight:700;">Simpan & Lanjut →</button>
        </div>

      </div>
    </div>`;
  document.body.appendChild(overlay);
}

function orgBuildAttrBlocks(attrs, catType) {
  let html = '';
  let lastHeader = null;

  attrs.forEach(attr => {
    // Section header (for teh)
    if (attr.header && attr.header !== lastHeader) {
      lastHeader = attr.header;
      const headerIcons = { 'Aroma': '👃', 'Rasa': '👅', 'Level Astringent': '🌿' };
      html += `<div class="org-section-header">${headerIcons[attr.header] || '📋'} ${orgEsc(attr.header)}</div>`;
    }

    // Build rating buttons 1-10
    const btns = Array.from({ length: 10 }, (_, i) => i + 1).map(r =>
      `<button class="org-rb" id="org-rb-${attr.key}-${r}" onclick="orgSelectAttrRating('${attr.key}',${r})">${r}</button>`
    ).join('');

    html += `
    <div class="org-attr-block">
      <div class="org-attr-header">
        <span style="font-size:16px;">${attr.icon}</span>
        <span class="org-attr-label">${orgEsc(attr.label)}</span>
        <span class="org-attr-hint">${orgEsc(attr.hint)}</span>
      </div>
      <div class="org-rating-row-compact">${btns}</div>
      <div id="org-rating-val-${attr.key}" style="font-size:10px;color:var(--txt3);text-align:center;margin-bottom:6px;min-height:14px;"></div>
      <textarea class="org-notes-input" id="org-notes-${attr.key}" placeholder="Catatan (opsional)…"></textarea>
    </div>`;
  });
  return html;
}

// Rating color by score
function orgRatingClass(r) {
  if (r <= 2) return 'sel-red';
  if (r <= 4) return 'sel-orange';
  if (r <= 5) return 'sel-yellow';
  if (r <= 7) return 'sel-green';
  if (r <= 9) return 'sel-blue';
  return 'sel-purple';
}
function orgRatingLabel(r) {
  if (r <= 2) return '😞 Sangat Buruk';
  if (r <= 4) return '😐 Kurang';
  if (r <= 5) return '🙂 Cukup';
  if (r <= 7) return '😊 Baik';
  if (r <= 9) return '🌟 Sangat Baik';
  return '🏆 Sempurna';
}

function orgSelectAttrRating(key, r) {
  // Store in temp object
  if (!_orgFillRatings[key]) _orgFillRatings[key] = {};
  _orgFillRatings[key].score = r;

  // Update button styles
  for (let i = 1; i <= 10; i++) {
    const btn = document.getElementById(`org-rb-${key}-${i}`);
    if (!btn) continue;
    btn.className = 'org-rb' + (i === r ? ' ' + orgRatingClass(r) : '');
  }

  // Update label
  const lbl = document.getElementById(`org-rating-val-${key}`);
  if (lbl) {
    lbl.style.color = 'var(--txt2)';
    lbl.textContent = `${r}/10 — ${orgRatingLabel(r)}`;
  }
}
window.orgSelectAttrRating = orgSelectAttrRating;

async function orgSubmitFill(testId) {
  const sb  = document.getElementById('org-fill-sb');
  const all = await orgGetAll();
  const test = all.find(t => t._id === testId);
  if (!test) return;

  const catType = test.categoryType || orgGetCatType(test.category);
  const attrs   = ORG_ATTRS[catType] || ORG_ATTRS.kopi;

  // Validate all attributes rated
  const missing = attrs.filter(a => !_orgFillRatings[a.key]?.score);
  if (missing.length > 0) {
    orgShowSb(sb, `⚠️ Lengkapi penilaian: ${missing.map(a => a.label).join(', ')}`, '#fff7ed', '#92400e');
    // Scroll to first missing attr block
    const firstMissing = document.getElementById(`org-rb-${missing[0].key}-1`);
    firstMissing?.closest('.org-attr-block')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }

  // Collect notes
  const ratings = {};
  attrs.forEach(attr => {
    ratings[attr.key] = {
      score: _orgFillRatings[attr.key].score,
      notes: document.getElementById(`org-notes-${attr.key}`)?.value?.trim() || '',
    };
  });

  // Remove duplicate panelNo if any, then push
  test.assessments = (test.assessments || []).filter(a => a.panelNo !== _orgFillPanel);
  test.assessments.push({
    panelNo: _orgFillPanel,
    ratings,
    ts: Date.now(),
  });

  const newDone = test.assessments.length;
  const isComplete = newDone >= test.panelCount;
  if (isComplete) {
    test.status = 'closed';
    test.completedAt = Date.now();
  }

  orgShowSb(sb, '⏳ Menyimpan…', '#eff6ff', '#1e40af');
  const saved = await orgSave(test);
  if (!saved) { orgShowSb(sb, '❌ Gagal menyimpan.', '#fef2f2', '#b91c1c'); return; }

  if (isComplete) {
    document.getElementById('org-fill-modal')?.remove();
    orgShowToast(`✅ Penilaian <b>${orgEsc(test.sampleName)}</b> selesai! Semua ${test.panelCount} panelis telah mengisi.`, '#166534');
    await orgRenderPanelList();
    setTimeout(() => orgSwitchTab('summary'), 900);
  } else {
    // Move to next unfilled panel
    const filledNos = test.assessments.map(a => a.panelNo);
    let next = 1;
    for (let i = 1; i <= test.panelCount; i++) {
      if (!filledNos.includes(i)) { next = i; break; }
    }
    _orgFillPanel   = next;
    _orgFillRatings = {};
    document.getElementById('org-fill-modal')?.remove();
    orgRenderFillModal(test);
  }
}
window.orgSubmitFill = orgSubmitFill;

function orgCloseFill() {
  document.getElementById('org-fill-modal')?.remove();
  orgRenderPanelList();
}
window.orgCloseFill = orgCloseFill;

// ══════════════════════════════════════════════════════════════════
//  7. CROSS-DEVICE PANELIST ENTRY (standalone form via URL param)
// ══════════════════════════════════════════════════════════════════
async function orgOpenPanelistEntryPage(testId) {
  const wrap = document.getElementById('org-wrap');
  if (!wrap) return;

  // Show loading
  wrap.innerHTML = `<div style="text-align:center;padding:60px 20px;color:var(--txt3);">⏳ Memuat sesi penilaian…</div>`;

  const all  = await orgGetAll();
  const test = all.find(t => t._id === testId);

  if (!test) {
    wrap.innerHTML = `
      <div class="org-empty" style="padding-top:60px;">
        <div class="org-empty-ico">❌</div>
        <div class="org-empty-txt">Sesi tidak ditemukan</div>
        <div class="org-empty-sub">Link mungkin sudah expired atau ID salah.</div>
      </div>`;
    return;
  }

  const done  = (test.assessments || []).length;
  const total = test.panelCount;

  if (done >= total || test.status === 'closed') {
    wrap.innerHTML = `
      <div class="org-empty" style="padding-top:60px;">
        <div class="org-empty-ico">🔒</div>
        <div class="org-empty-txt">Sesi sudah ditutup</div>
        <div class="org-empty-sub">Semua ${total} panelis sudah mengisi. Terima kasih!</div>
        <div style="margin-top:20px;">
          <div style="font-size:24px;font-weight:900;color:var(--green);">${done}/${total}</div>
          <div style="font-size:11px;color:var(--txt3);">Panelis telah mengisi</div>
        </div>
      </div>`;
    return;
  }

  // Next panel number
  const filledNos = (test.assessments || []).map(a => a.panelNo);
  let panelNo = 1;
  for (let i = 1; i <= total; i++) {
    if (!filledNos.includes(i)) { panelNo = i; break; }
  }
  _orgFillTestId = testId;
  _orgFillPanel  = panelNo;
  _orgFillRatings = {};

  const catType = test.categoryType || orgGetCatType(test.category);
  const attrs   = ORG_ATTRS[catType] || ORG_ATTRS.kopi;
  const catLabel = orgGetCatLabel(test.category);

  wrap.innerHTML = `
    <div style="max-width:520px;margin:0 auto;padding:16px 0 40px;">
      <!-- Header card -->
      <div style="background:linear-gradient(135deg,var(--blue),#3b82f6);color:#fff;border-radius:14px;padding:18px 20px;margin-bottom:16px;">
        <div style="font-size:10px;font-weight:700;opacity:.8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;">Organoleptic Test Panel</div>
        <div style="font-size:18px;font-weight:800;margin-bottom:2px;">${orgEsc(test.sampleName)}</div>
        <div style="font-size:11px;opacity:.85;">${orgEsc(test.sampleNo)} &nbsp;·&nbsp; ${orgEsc(catLabel)}</div>
        <div style="margin-top:10px;background:rgba(255,255,255,.18);border-radius:99px;height:4px;overflow:hidden;">
          <div style="height:100%;border-radius:99px;background:#fff;width:${Math.round((done/total)*100)}%;"></div>
        </div>
        <div style="font-size:10px;opacity:.8;margin-top:4px;">${done}/${total} panelis sudah mengisi</div>
      </div>

      <!-- Panel badge -->
      <div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:12px 16px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;">
        <div>
          <div style="font-size:10px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.4px;">Anda adalah</div>
          <div style="font-size:20px;font-weight:800;color:var(--txt);">Panel #${panelNo}</div>
        </div>
        <span style="font-size:32px;">👤</span>
      </div>

      <!-- Attribute blocks -->
      ${orgBuildAttrBlocks(attrs, catType)}

      <div id="org-entry-sb" class="org-sb"></div>

      <button class="de-btn de-btn-primary" onclick="orgSubmitEntryPage('${orgEsc(testId)}')"
        style="width:100%;padding:13px;font-size:14px;font-weight:800;border-radius:10px;justify-content:center;">
        ✅ Kirim Penilaian Saya
      </button>

      <div style="text-align:center;font-size:10px;color:var(--txt3);margin-top:12px;">
        SAIL Organoleptic System &nbsp;·&nbsp; Panel #${panelNo} dari ${total}
      </div>
    </div>`;
}

async function orgSubmitEntryPage(testId) {
  const sb  = document.getElementById('org-entry-sb');
  const all = await orgGetAll();
  const test = all.find(t => t._id === testId);
  if (!test) return;

  const catType = test.categoryType || orgGetCatType(test.category);
  const attrs   = ORG_ATTRS[catType] || ORG_ATTRS.kopi;

  const missing = attrs.filter(a => !_orgFillRatings[a.key]?.score);
  if (missing.length > 0) {
    orgShowSb(sb, `⚠️ Lengkapi semua penilaian: ${missing.map(a => a.label).join(', ')}`, '#fff7ed', '#92400e');
    document.getElementById(`org-rb-${missing[0].key}-1`)
      ?.closest('.org-attr-block')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }

  const ratings = {};
  attrs.forEach(attr => {
    ratings[attr.key] = {
      score: _orgFillRatings[attr.key].score,
      notes: document.getElementById(`org-notes-${attr.key}`)?.value?.trim() || '',
    };
  });

  test.assessments = (test.assessments || []).filter(a => a.panelNo !== _orgFillPanel);
  test.assessments.push({ panelNo: _orgFillPanel, ratings, ts: Date.now() });

  const newDone    = test.assessments.length;
  const isComplete = newDone >= test.panelCount;
  if (isComplete) { test.status = 'closed'; test.completedAt = Date.now(); }

  orgShowSb(sb, '⏳ Mengirim penilaian…', '#eff6ff', '#1e40af');
  const saved = await orgSave(test);
  if (!saved) { orgShowSb(sb, '❌ Gagal mengirim.', '#fef2f2', '#b91c1c'); return; }

  // Show thank you
  const wrap = document.getElementById('org-wrap');
  if (wrap) {
    wrap.innerHTML = `
      <div class="org-empty" style="padding-top:60px;">
        <div class="org-empty-ico">🎉</div>
        <div class="org-empty-txt" style="color:var(--green);font-size:18px;">Terima Kasih!</div>
        <div class="org-empty-sub" style="font-size:13px;margin-top:8px;">
          Penilaian Panel #${_orgFillPanel} untuk <b>${orgEsc(test.sampleName)}</b> berhasil disimpan.
        </div>
        ${isComplete
          ? `<div style="margin-top:20px;padding:14px;background:#f0fdf4;border-radius:10px;color:#166534;font-size:12px;font-weight:700;">🔒 Semua ${test.panelCount} panelis sudah mengisi. Sesi ditutup.</div>`
          : `<div style="margin-top:16px;font-size:12px;color:var(--txt3);">${newDone} dari ${test.panelCount} panelis telah mengisi.</div>`
        }
      </div>`;
  }
}
window.orgSubmitEntryPage = orgSubmitEntryPage;

// ══════════════════════════════════════════════════════════════════
//  8. DELETE
// ══════════════════════════════════════════════════════════════════
async function orgConfirmDelete(id) {
  const all  = await orgGetAll();
  const test = all.find(t => t._id === id);
  if (!test) return;
  if (!confirm(`Hapus tes panel "${test.sampleName}"?\nTindakan ini tidak bisa dibatalkan.`)) return;
  await orgDelete(id);
  await orgRenderPanelList();
  await orgRenderSummary();
}
window.orgConfirmDelete = orgConfirmDelete;

// ══════════════════════════════════════════════════════════════════
//  9. SUMMARY TAB
// ══════════════════════════════════════════════════════════════════
async function orgRenderSummary() {
  const container = document.getElementById('org-summary-body');
  if (!container) return;
  const all  = await orgGetAll();
  const data = all.filter(t => (t.assessments || []).length > 0);

  if (!data.length) {
    container.innerHTML = `
      <div class="org-empty">
        <div class="org-empty-ico">📊</div>
        <div class="org-empty-txt">Belum ada data summary</div>
        <div class="org-empty-sub">Isi penilaian terlebih dahulu.</div>
      </div>`;
    return;
  }

  const ratingColor = r => {
    const c = ['','#ef4444','#ef4444','#f97316','#f97316','#eab308','#eab308','#22c55e','#22c55e','#3b82f6','#8b5cf6'];
    return c[r] || '#aaa';
  };

  container.innerHTML = [...data].reverse().map(test => {
    const done     = test.assessments.length;
    const total    = test.panelCount;
    const complete = done >= total;
    const catType  = test.categoryType || orgGetCatType(test.category);
    const attrs    = ORG_ATTRS[catType] || ORG_ATTRS.kopi;
    const catLabel = orgGetCatLabel(test.category);
    const dateStr  = new Date(test.createdAt).toLocaleDateString('id-ID', { day:'2-digit', month:'short', year:'numeric' });

    const statusBadge = complete
      ? `<span style="font-size:10px;font-weight:700;background:#f0fdf4;color:#166534;padding:3px 8px;border-radius:5px;">✅ Selesai</span>`
      : `<span style="font-size:10px;font-weight:700;background:#fff7ed;color:#92400e;padding:3px 8px;border-radius:5px;">⏳ ${done}/${total}</span>`;

    // Build per-attribute summary
    let lastHeader = null;
    const attrSummaries = attrs.map(attr => {
      const scores = test.assessments.map(a => a.ratings?.[attr.key]?.score).filter(Boolean);
      if (!scores.length) return '';
      const avg = (scores.reduce((s, v) => s + v, 0) / scores.length).toFixed(1);
      const allNotes = test.assessments
        .map(a => a.ratings?.[attr.key]?.notes)
        .filter(n => n && n.trim());

      // Distribution bar (each score 1-10)
      const max = Math.max(...Array.from({ length: 10 }, (_, i) => scores.filter(s => s === i + 1).length), 1);
      const bars = Array.from({ length: 10 }, (_, i) => {
        const score = i + 1;
        const count = scores.filter(s => s === score).length;
        const pct   = Math.round((count / max) * 100);
        if (!count) return '';
        return `
          <div class="org-sum-bar-row">
            <div class="org-sum-bar-label">${score}</div>
            <div class="org-sum-bar-wrap">
              <div class="org-sum-bar" style="width:${pct}%;background:${ratingColor(score)};"></div>
            </div>
            <div class="org-sum-bar-val">${count}×</div>
          </div>`;
      }).join('');

      let headerHtml = '';
      if (attr.header && attr.header !== lastHeader) {
        lastHeader = attr.header;
        headerHtml = `<div class="org-section-header">${orgEsc(attr.header)}</div>`;
      }

      return `${headerHtml}
        <div class="org-sum-attr">
          <div class="org-sum-attr-label">${attr.icon} ${orgEsc(attr.label)}
            <span style="font-weight:400;color:var(--txt3);"> — rata-rata </span>
            <span style="color:${ratingColor(Math.round(parseFloat(avg)))};">${avg}/10</span>
          </div>
          ${bars}
          ${allNotes.length ? `
            <div style="margin-top:6px;padding:8px 10px;background:var(--bg);border-radius:7px;border-left:3px solid var(--border);">
              <div style="font-size:9px;font-weight:700;color:var(--txt3);margin-bottom:4px;">CATATAN PANELIS:</div>
              ${allNotes.map((n, i) => `<div style="font-size:11px;color:var(--txt2);margin-bottom:3px;">• ${orgEsc(n)}</div>`).join('')}
            </div>` : ''}
        </div>`;
    }).join('');

    // Overall average (across all attributes)
    const allScores = test.assessments.flatMap(a =>
      Object.values(a.ratings || {}).map(r => r.score).filter(Boolean)
    );
    const grandAvg = allScores.length
      ? (allScores.reduce((s, v) => s + v, 0) / allScores.length).toFixed(2)
      : '—';

    return `
      <div class="org-sum-card">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:4px;">
          <div class="org-sum-title">${orgEsc(test.sampleName)}</div>
          ${statusBadge}
        </div>
        <div class="org-sum-meta">
          ${orgEsc(test.sampleNo)} &nbsp;·&nbsp; ${orgEsc(catLabel)} &nbsp;·&nbsp;
          ${dateStr} &nbsp;·&nbsp; Grand Avg: <b>${grandAvg}/10</b> &nbsp;·&nbsp; ${done} panelis
        </div>
        ${attrSummaries}
        ${!complete ? `
          <button class="de-btn de-btn-primary" onclick="orgOpenFillModal('${orgEsc(test._id)}')"
            style="width:100%;margin-top:12px;font-size:12px;padding:8px;justify-content:center;">
            ✏️ Lanjut Isi Penilaian (${done}/${total})
          </button>` : ''}
      </div>`;
  }).join('');
}
window.orgRenderSummary = orgRenderSummary;

// ══════════════════════════════════════════════════════════════════
//  10. HELPERS
// ══════════════════════════════════════════════════════════════════
function orgShowSb(el, msg, bg, color) {
  if (!el) return;
  el.style.display = 'block';
  el.style.background = bg;
  el.style.color = color;
  el.style.border = `1px solid ${color}33`;
  el.textContent = msg;
}

function orgShowToast(html, bgColor = '#166534') {
  const t = document.createElement('div');
  t.style.cssText = `
    position:fixed;bottom:24px;right:24px;z-index:99999;
    background:${bgColor};color:#fff;padding:12px 18px;border-radius:10px;
    font-size:13px;font-weight:700;box-shadow:0 8px 24px rgba(0,0,0,.2);
    animation:orgFadeIn .3s ease;max-width:300px;line-height:1.4;`;
  t.innerHTML = html;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

// ══════════════════════════════════════════════════════════════════
//  11. WINDOW EXPORTS
// ══════════════════════════════════════════════════════════════════
window.getOrganolepticHTML = getOrganolepticHTML;
window.initOrganoleptic    = initOrganoleptic;